# Confidential Algorithm 5.2 — Clean Windows Build

This build uses Baileys over a direct WebSocket transport. It does not use Puppeteer, Chromium, or whatsapp-web.js, so the browser-frame error class (`Attempted to use detached Frame`) is not part of the WhatsApp transport.

## Installation

1. Extract this ZIP into a completely new folder.
2. Do not copy `node_modules`, `package-lock.json`, or old WhatsApp authentication data from an earlier build.
3. Double-click `START-COPILOT.cmd`.
4. The installer uses the npm registry and verifies Baileys + libsignal after installation. Git is not required.
5. The dashboard opens at `http://localhost:3010`.

## AI response timing

The main Analyze + draft path makes exactly one Ollama generation call and has a hard **240-second (4-minute)** model timeout. The browser waits 245 seconds. There is no automatic second LLM retry. Analyze-selected-text has its own **900-second (15-minute)** limit instead — it's a deliberate deep read, not something on the send path. Both numbers are served from the backend at runtime so the browser timer can never disagree with what the server actually enforces. A **Stop** button cancels either request (including the in-flight Ollama call, not just the browser wait), and the timer shows a rolling average of your past run times before you start a new one.

## AI behavior

The response lab supports the user's exact one-off request, persistent per-chat instructions, demonstrated writing style, prior feedback, sarcasm/humour signals, likely textual attitude/intent, evidence, communication/psychology interpretation, risks, strategy, alternatives, temporal context, and user corrections.

Psychology sections describe communication signals and plausible interpretations; they are not diagnoses or claims of hidden mental states.
