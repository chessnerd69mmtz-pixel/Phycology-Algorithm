# Confidential Algorithm 8.17 — Evidence-Calibrated Analysis

This build keeps the existing WhatsApp transport, 1,500-word Text Analysis ceiling, 120-second Text Analysis budget, 5,000-message Deep Analysis ceiling, 8-part Deep Analysis, and 20-tone taxonomy.

## Fixed analysis issues
- Removed the previous behavior where the model's repeated/default percentage could become the final confidence for every category.
- Deep-analysis confidence is now evidence-first and independently calibrated per category using verified quotes, evidence quality, section-specific observable signals, limited model confidence, and counter-evidence penalties.
- A section with no verified evidence now receives 0 confidence rather than a fabricated/default percentage.
- One weak quote cannot produce an artificially high confidence score.
- Different categories use different measurable signals, so identical model percentages no longer force identical final category scores.

## Evidence requirements
- Every Deep Analysis category must have at least one verified quote when text is available.
- Quotes are checked against the actual selected text using strict character matching.
- If the model supplies an invalid/paraphrased quote, the system attempts to replace it with an exact source line relevant to the claim.
- Each evidence item includes a justification and a psychological/communication principle.
- Indirect evidence must identify the observable cue and remains explicitly labeled as indirect.
- The system does not diagnose mental disorders, personality disorders, attachment styles, or hidden motives.

## UI
- Analyze Text result points now show the conclusion plus the first supporting direct quote, why it supports the conclusion, and the principle used.
- The full 8-part Deep Analysis continues to show evidence, justification, evidence type, and principle for each category.

## Model
- The default Ary AI model remains `llama3.2`; no silent switch to `llama3.1` or a larger model was introduced.


## 8.18 Ary AI timeout/stability fix
- Generic Ary AI primary timeout: 90 seconds.
- Generic Ary AI recovery attempt: 25 seconds with a compact prompt.
- Generic Ary AI browser budget: 123 seconds.
- WhatsApp-aware Ary AI remains on its separate 295-second budget.
- This prevents the browser from aborting the request before the server recovery attempt can run.


## Superseded by 8.19
8.19 fixes the remaining client/server timeout mismatch: the client no longer derives its timeout as only server primary timeout + 3 seconds, which previously reduced it to 58 seconds. It now reserves the compact recovery window.
