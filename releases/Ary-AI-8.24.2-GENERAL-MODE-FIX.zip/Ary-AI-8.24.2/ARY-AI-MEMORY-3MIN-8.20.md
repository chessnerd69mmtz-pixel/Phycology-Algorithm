# Ary AI 8.20 — Memory + 3-Minute Response Window

- Generic Ary AI has a 3-minute server budget.
- Primary generation uses most of the budget; a compact recovery call and deterministic local fallback prevent avoidable timeout/error bubbles.
- Generic requests no longer require optional context. Missing context is explicitly treated as permission to answer generally.
- Browser UI displays a live response timer.
- Browser-side Ary AI memory persists the most recent 30 messages locally and sends the most recent 12 prior messages to the model.
- Existing evidence-calibrated analysis, Text Analysis 1500-word/120-second mode, Deep Analysis, Professional Mode, contacts, reports, and WhatsApp transport are retained.
- Default model remains llama3.2.
