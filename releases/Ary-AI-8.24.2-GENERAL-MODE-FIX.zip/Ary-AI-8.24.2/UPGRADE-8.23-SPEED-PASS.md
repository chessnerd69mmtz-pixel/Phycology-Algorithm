# 8.23 — Speed pass across all modes (Ary AI, Deep Analysis, Text Analysis, Relationship Mode)

Same models throughout (`llama3.2`, unchanged), same accuracy safeguards
(evidence verification, self-checks) — this pass targets wasted round trips
and redundant reprocessing that were adding latency without adding quality.

## What was actually making things slow
Deep Analysis, Text Analysis, and Relationship Mode all work by splitting a
conversation into batches and sending each one to the model separately. Every
one of those batch calls re-sends the same ~1.5-2K tokens of fixed
instructions (the analysis protocol, evidence rules, JSON schema) before it
ever gets to the actual conversation content for that batch. On a long
conversation that gets split into many small batches, that fixed cost gets
paid over and over for no added value — it's the single biggest source of
avoidable time in these three modes.

Separately, every analysis call and the WhatsApp-aware branch of Ary AI's
generic model selection each hit Ollama's `/api/tags` endpoint just to check
"is it running" and "what's installed" — before doing any real work, every
single time, even for the fifth question in a row in the same session.

## What changed (server/llm.js)
1. **Bigger batches, fewer round trips.** Batch size went from 11,000 chars /
   210 messages per batch to 14,000 chars / 280 messages per batch — roughly
   30% more content per batch, meaning roughly 30% fewer batches for the same
   conversation, and the fixed instruction text gets reprocessed that many
   fewer times. The context window used for these calls was raised from 8,192
   to 12,288 tokens alongside this specifically so the larger prompt plus its
   full reserved output space still fits with headroom — this was checked
   with real arithmetic (batch text + instructions + JSON schema + reserved
   output all comfortably under the new ceiling), not just increased and
   hoped for.
2. **Cached the two health/setup checks.** `ollamaReady()` (used once per
   Deep Analysis / Text Analysis / Relationship Mode call) and
   `pickAryGenericModel()` (used on every generic Ary AI question) now cache
   their result — 20 seconds for the health check, 5 minutes for the model
   list, since installed models essentially never change mid-session. A
   second question asked shortly after the first skips a network round trip
   it didn't need. Verified live: two consecutive generic Ary AI questions
   now produce exactly one `/api/tags` call instead of two.
3. **Timeouts scaled with the bigger batches** (batch timeout 45s→55s, retry
   timeout 30s→38s) so the larger per-batch workload doesn't start tripping
   timeouts that were sized for the smaller batches. The existing 15-minute
   total-selection safety ceiling is unchanged and still the real backstop.

## Verified, not assumed
- Ran the actual `scripts/verify-build.js` regression check — passes.
- Live-tested `pickAryGenericModel` caching with a mock Ollama server: two
  generic Ary AI questions in a row produced 1 `/api/tags` call, not 2.
- Live-tested the same for the WhatsApp-data-intent Ary AI path.
- Checked every one of the 12 batch/synthesis call sites got the larger
  context window, not just some of them.
- Confirmed prompt-size arithmetic (batch text + fixed instructions + JSON
  schema + reserved output) leaves real headroom under the new 12,288-token
  ceiling rather than just barely fitting.

## What this does not change
- No model swap — still `llama3.2` everywhere it was before.
- No change to any accuracy safeguard from the 8.21/8.22 passes (evidence
  verification, self-checks, quote validation).
- Ary AI's conversation persistence (new chat / history) from 8.22 is
  untouched.
- If a chat is short enough to fit in one batch already, this pass changes
  nothing about it — the benefit scales with conversation length, which is
  also where the old per-batch overhead was worst.
