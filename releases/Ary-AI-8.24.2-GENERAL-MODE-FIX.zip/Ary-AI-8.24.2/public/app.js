window.__CA_UI_VERSION="2026.09.10-ARY-AI-TIMEOUT-FIX";
/* -------------------------------------------------------------------------
   FIRST-RESPONSE NAVIGATION GUARD
   Register this before any async work or optional feature initialization.
   If a later feature throws an error, the five main pages must still open.
   ------------------------------------------------------------------------- */
(function installNavigationGuard(){
  const navigate=(pageId, requestedMode=null)=>{
    const pages=[...document.querySelectorAll('.page')];
    const target=document.getElementById(pageId);
    if(!target) return false;
    pages.forEach(p=>p.classList.toggle('active-page',p===target));
    document.querySelectorAll('.nav-tab').forEach(t=>t.classList.toggle('active',t.dataset.page===pageId));
    document.body.dataset.page=pageId;
    document.body.classList.remove('page-history','page-ary-ai','page-corporate','page-conversation','page-text','page-deep','page-contacts','page-reports');
    document.body.classList.add('page-'+pageId.replace(/-page$/,''));
    window.scrollTo({top:0,behavior:'smooth'});
    return true;
  };
  window.__CA_NAV=navigate;
  document.addEventListener('click',(ev)=>{
    const nav=ev.target.closest?.('.nav-tab');
    if(nav){
      ev.preventDefault();
      const pageId=nav.dataset.page;
      if(pageId){
        if(typeof window.goToPage==='function') window.goToPage(pageId,null);
        else navigate(pageId);
      }
      return;
    }
    const go=ev.target.closest?.('[data-go]');
    if(go && !go.closest('.nav-tab')){
      const pageId=go.dataset.go;
      if(pageId){
        ev.preventDefault();
        if(typeof window.goToPage==='function') window.goToPage(pageId,null);
        else navigate(pageId);
      }
    }
  },true);
})();
const $ = id => document.getElementById(id);
const qrScreen=$('qr-screen'), qrImg=$('qr-img'), qrStatus=$('qr-status'), newQrBtn=$('new-qr-btn'), app=$('app'), chatList=$('chat-list'), threadName=$('thread-name'), messages=$('messages');
const userGender=$('user-gender'), userAge=$('user-age'), saveProfile=$('save-profile'), profileSaveStatus=$('profile-save-status'), sync=$('conversation-sync'), syncStatus=$('conversation-sync-status'), digest=$('digest-btn'), modal=$('digest-modal'), digestBody=$('digest-body');
const selectionBtn=$('selection-btn'), statsBtn=$('stats-btn'), reportBtn=$('report-btn'), selectionRequest=$('selection-request'), conversationAnalyzeBtn=$('conversation-analyze-btn'), deepAnalysisCount=$('deep-analysis-count');
const relationshipRun=$('relationship-run'), relationshipStop=$('relationship-stop'), relationshipTimer=$('relationship-timer'), relationshipChats=$('relationship-chats'), relationshipStatus=$('relationship-status'), relationshipObjective=$('relationship-objective');
const conversationStartDate=$('conversation-start-date'), conversationEndDate=$('conversation-end-date'), conversationSelectRange=$('conversation-select-range'), conversationDateStatus=$('conversation-date-status'), conversationSummaryBtn=$('conversation-summary-btn');
let relationshipResult=null, relationshipTimerHandle=null, relationshipTimerStarted=0;
const analysisTimer=$('analysis-timer');
const insights=$('insights'), analysisCards=$('analysis-cards'), deepOpen=$('deep-open'), deepBack=$('deep-back'), deepTabs=$('deep-tabs'), deepBody=$('deep-body'), analysisDashboard=$('analysis-dashboard'), analysisDeep=$('analysis-deep');
const insightsTabs=deepTabs, insightsBody=deepBody;
const counterfactualOpen=$('counterfactual-open'), counterfactualClose=$('counterfactual-close'), counterfactualPanel=$('counterfactual-panel'), counterfactualTarget=$('counterfactual-target'), counterfactualText=$('counterfactual-text'), counterfactualObjective=$('counterfactual-objective'), counterfactualRun=$('counterfactual-run'), counterfactualStatus=$('counterfactual-status'), counterfactualResult=$('counterfactual-result');
let activeChatId=null, activeChat=null, lastSuggestion=null, connected=false;
window.activeChatId=null;
let selectedMessageIds=new Set(), messageCache=[];
// Selection analysis uses the configured deep-analysis timeout.
// Analyze-selected-text is a deliberate, user-triggered deep read, so it gets 15 minutes.
// These are the single source of truth for both limits; they sync from the
// server's actual configured timeouts (via /api/status) so the UI can never
// drift out of sync with what the server will really enforce.
const MAX_ANALYSIS_MESSAGES=5000;
const MAX_TEXT_ANALYSIS_WORDS=1500;
let SELECTION_LIMIT_MS=900000, SELECTION_UI_TIMEOUT_MS=905000;
let TEXT_ANALYSIS_LIMIT_MS=120000, TEXT_ANALYSIS_UI_TIMEOUT_MS=125000;
function syncLimitsFromServer(s){
  if(Number.isFinite(s?.selection_timeout_ms) && s.selection_timeout_ms>0){ SELECTION_LIMIT_MS=s.selection_timeout_ms; SELECTION_UI_TIMEOUT_MS=SELECTION_LIMIT_MS+5000; }
  if(Number.isFinite(s?.text_analysis_timeout_ms) && s.text_analysis_timeout_ms>0){ TEXT_ANALYSIS_LIMIT_MS=s.text_analysis_timeout_ms; TEXT_ANALYSIS_UI_TIMEOUT_MS=TEXT_ANALYSIS_LIMIT_MS+5000; }
  updateEstimateDisplay();
}
let timerHandle=null, timerStartedAt=0, timerMode='', timerLimitMs=SELECTION_LIMIT_MS;
function formatTimer(ms){const sec=Math.max(0,Math.ceil(ms/1000));return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`;}
function stopAnalysisTimer(finalText){if(timerHandle){clearInterval(timerHandle);timerHandle=null;} if(analysisTimer){analysisTimer.classList.remove('running','warning');analysisTimer.innerHTML=finalText||estimateDisplayHtml();} if(stopBtn)stopBtn.classList.add('hidden');}
function startAnalysisTimer(mode,limitMs){if(timerHandle)clearInterval(timerHandle); timerStartedAt=Date.now(); timerMode=mode; timerLimitMs=limitMs; if(analysisTimer){analysisTimer.classList.add('running');analysisTimer.classList.remove('warning');} if(stopBtn)stopBtn.classList.remove('hidden'); const tick=()=>{const elapsed=Date.now()-timerStartedAt, remain=timerLimitMs-elapsed; if(analysisTimer)analysisTimer.textContent=`Running: ${formatTimer(elapsed)} elapsed · ${formatTimer(Math.max(0,remain))} left of ${formatTimer(limitMs)} max`; if(remain<=30000 && analysisTimer)analysisTimer.classList.add('warning'); if(remain<=0){if(analysisTimer)analysisTimer.textContent=`Stopping — reached the ${formatTimer(limitMs)} max`; clearInterval(timerHandle); timerHandle=null;}}; tick(); timerHandle=setInterval(tick,250);}

/* ---- time estimate, learned from this device's own past runs ---- */
const TIMING_KEY='copilot_timing_history_v1';
function loadTimingHistory(){ try{ return JSON.parse(localStorage.getItem(TIMING_KEY)||'{}'); }catch(_){ return {}; } }
function recordTiming(mode, ms){
  const hist=loadTimingHistory(); const arr=Array.isArray(hist[mode])?hist[mode]:[];
  arr.push(ms); while(arr.length>8) arr.shift();
  hist[mode]=arr; try{ localStorage.setItem(TIMING_KEY, JSON.stringify(hist)); }catch(_){}
  updateEstimateDisplay();
}
function estimateFor(mode){
  const arr=loadTimingHistory()[mode];
  if(!Array.isArray(arr) || !arr.length) return null;
  return { avgMs: Math.round(arr.reduce((a,b)=>a+b,0)/arr.length), count: arr.length };
}
function estimateLine(mode, limitMs, label){
  const est=estimateFor(mode);
  return est
    ? `${label}: usually ~${formatTimer(est.avgMs)} (avg of last ${est.count}) · max ${formatTimer(limitMs)}`
    : `${label}: no history yet on this device · max ${formatTimer(limitMs)}`;
}
function estimateDisplayHtml(){
  return `${esc(estimateLine('selection',SELECTION_LIMIT_MS,'Analyze selected text'))}`;
}
function updateEstimateDisplay(){ if(!timerHandle && analysisTimer) analysisTimer.innerHTML=estimateDisplayHtml(); }
updateEstimateDisplay();

/* ---- cancellable AI requests: "Stop" aborts both the browser wait and the server-side Ollama call ---- */
const stopBtn=$('stop-btn');
let currentRequestId=null, currentAbortController=null;
function genRequestId(){ return (window.crypto?.randomUUID) ? crypto.randomUUID() : `req-${Date.now()}-${Math.random().toString(16).slice(2)}`; }
function beginCancellableRequest(){
  currentRequestId=genRequestId();
  currentAbortController=new AbortController();
  return currentRequestId;
}
function combinedSignalFor(uiTimeoutMs){
  const timeoutSignal=AbortSignal.timeout(uiTimeoutMs);
  return (window.AbortSignal?.any) ? AbortSignal.any([currentAbortController.signal, timeoutSignal]) : currentAbortController.signal;
}
async function cancelCurrentRequest(){
  const id=currentRequestId;
  if(currentAbortController) currentAbortController.abort();
  if(id){ try{ await fetch(`/api/cancel/${encodeURIComponent(id)}`,{method:'POST'}); }catch(_){} }
}
stopBtn.onclick=async()=>{
  stopBtn.disabled=true; stopBtn.textContent='Stopping…';
  await cancelCurrentRequest();
  stopAnalysisTimer('Stopped by you.');
  setTimeout(()=>{stopBtn.disabled=false; stopBtn.textContent='Stop'; stopBtn.classList.add('hidden');},600);
};

// Keep the dashboard live while analysis is running. The server pushes each
// newly received/sent message over SSE, so we don't wait for the 15-minute
// history sync or for an AI request to finish.
let liveSource=null;
function startLiveSync(){
  if(liveSource) liveSource.close();
  if(!window.EventSource) return;
  liveSource=new EventSource('/api/live');
  liveSource.onmessage=async(ev)=>{
    try{
      const d=JSON.parse(ev.data);
      if(d.type!=='message') return;
      await loadChats();
      if(activeChatId && d.message?.chat_id===activeChatId) await renderMessages();
    }catch(_){}
  };
  liveSource.onerror=()=>{};
}
startLiveSync();

function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

async function poll(){
  try{
    const s=await fetch('/api/status').then(r=>r.json());
    if(s.status==='ready'){
      if(!connected){connected=true; qrScreen.classList.add('hidden'); app.classList.remove('hidden'); await loadChats();}
      syncLimitsFromServer(s);
      const x=s.sync||{};
      if(x.running){
        const total=Number(x.totalChats||0), done=Number(x.completedChats||0);
        const pct=total?Math.min(100,Math.round(done/total*100)):0;
        const mode=x.mode==='initial'?'First full history sync':'Incremental sync';
        syncStatus.textContent=`${mode}: ${done}/${total} chats (${pct}%) · ${Number(x.messages||0).toLocaleString()} messages · ${x.currentChat||'working…'}`;
      } else if(x.phase==='paused') {
        syncStatus.textContent=`Sync paused safely — ${x.detail||'will resume automatically.'}`;
      } else if(x.phase==='complete') {
        syncStatus.textContent=x.detail||'Sync complete.';
      } else {
        syncStatus.textContent='';
      }
    }else if(connected){
      // Never throw the user back to the QR screen because of a temporary
      // navigation/disconnect. The supervisor and whatsapp.js retry in the background.
      qrScreen.classList.add('hidden'); app.classList.remove('hidden');
      const x=s.sync||{};
      syncStatus.textContent=s.status==='disconnected'
        ? 'WhatsApp connection is recovering… your local data is safe.'
        : (x.running?'Syncing in the background…':'Waiting for WhatsApp to reconnect…');
    }else{
      app.classList.add('hidden'); qrScreen.classList.remove('hidden');
      qrStatus.textContent=s.qr?'Scan with your phone…':(s.status==='starting'?'Starting WhatsApp connection…':'Waiting for QR code…');
      if(s.qr) qrImg.src=s.qr;
    }
  }catch(e){
    if(connected){qrScreen.classList.add('hidden'); app.classList.remove('hidden'); syncStatus.textContent='Server reconnecting…';}
    else qrStatus.textContent='Starting Ary AI…';
  }
}
setInterval(poll,2000); poll();

// Classic QR-only reconnect flow. This deliberately does not request or display
// a phone-number pairing code. It clears stale Baileys auth and waits for a
// brand-new WhatsApp QR so the phone can scan the normal Linked Devices code.
newQrBtn?.addEventListener('click', async()=>{
  if(newQrBtn.disabled) return;
  newQrBtn.disabled=true;
  newQrBtn.textContent='Generating fresh QR…';
  qrImg.removeAttribute('src');
  qrStatus.textContent='Resetting the previous login attempt and requesting a fresh QR…';
  try{
    const r=await fetch('/api/whatsapp/new-qr',{method:'POST'});
    const d=await r.json().catch(()=>({}));
    if(!r.ok) throw new Error(d.error||'Could not generate a fresh QR.');
    qrStatus.textContent='Waiting for the fresh QR…';
  }catch(e){
    qrStatus.textContent=`Could not generate a fresh QR: ${e.message}`;
  }finally{
    setTimeout(()=>{newQrBtn.disabled=false; newQrBtn.textContent='↻ Generate a fresh QR';},1200);
  }
});

let renamingChatId=null; // guards the periodic chat-list refresh while an inline rename input is open
let latestChatList=[];
async function loadChats(){
  if(renamingChatId) return; // don't blow away an in-progress rename edit
  const cs=await fetch('/api/chats').then(r=>r.json());
  latestChatList=Array.isArray(cs)?cs:[];
  refreshTextContactOptions();
  chatList.innerHTML=cs.length?'':'<div class="empty-list">No chats yet. Click Sync now after WhatsApp connects.</div>';
  cs.forEach(c=>{
    const displayName=c.display_name||c.name||c.id;
    const d=document.createElement('div'); d.className='chat-item'+(c.id===activeChatId?' active':'');
    const whatsappNamed=!c.custom_name && (c.whatsapp_name||c.whatsapp_pushname);
    const nameSource=whatsappNamed ? `<span class="name-source" title="Name supplied by WhatsApp">WhatsApp</span>` : '';
    d.innerHTML=`<div class="top"><span class="chat-name-wrap"><span class="chat-name">${esc(displayName)}</span>${nameSource}<button class="rename-btn" title="Rename this chat">✎</button><button class="delete-btn" title="Remove from this algorithm only">×</button></span>${c.unread_from_them>0?`<b>${c.unread_from_them}</b>`:''}</div><div class="preview">${esc(c.last_body||'')}</div><div class="contact-actions"><button class="contact-open-btn primary" type="button">View conversation →</button></div>`;
    d.onclick=()=>openChat(c);
    d.querySelector('.rename-btn').onclick=(ev)=>{ ev.stopPropagation(); startRename(d, c, displayName); };
    d.querySelector('.delete-btn').onclick=(ev)=>{ ev.stopPropagation(); deleteChatFromAlgorithm(c); };
    d.querySelector('.contact-open-btn').onclick=(ev)=>{ ev.stopPropagation(); openChat(c); };
    chatList.appendChild(d);
  });
}
function refreshTextContactOptions(){
  const select=$('text-contact-select');
  if(!select) return;
  const previous=select.value;
  select.innerHTML='<option value="">Choose a contact…</option>'+latestChatList.map(c=>`<option value="${esc(c.id)}">${esc(c.display_name||c.name||c.id)}</option>`).join('');
  if(previous && latestChatList.some(c=>String(c.id)===String(previous))) select.value=previous;
  else if(activeChatId && latestChatList.some(c=>String(c.id)===String(activeChatId))) select.value=activeChatId;
}
setInterval(()=>{if(connected)loadChats();},8000);


// Turns a chat item's name into an editable field. Saves via POST
// /api/chats/:id/name; sending an empty value clears the override and
// reverts to whatever WhatsApp reported (a raw phone number, group JID, etc.).
function startRename(itemEl, chat, currentDisplayName){
  if(renamingChatId) return;
  renamingChatId=chat.id;
  const wrap=itemEl.querySelector('.chat-name-wrap');
  wrap.innerHTML=`<input class="rename-input" type="text" maxlength="120" value="${esc(currentDisplayName)}">`;
  const input=wrap.querySelector('.rename-input');
  input.focus(); input.select();
  let done=false;
  const finish=async(save)=>{
    if(done)return; done=true;
    const newName=input.value.trim();
    renamingChatId=null;
    if(save && newName && newName!==currentDisplayName){
      try{
        const r=await fetch(`/api/chats/${encodeURIComponent(chat.id)}/name`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:newName})});
        const d=await r.json(); if(!r.ok)throw Error(d.error||'Rename failed');
        if(activeChatId===chat.id && activeChat){ activeChat.display_name=d.display_name; threadName.textContent=d.display_name; }
      }catch(e){ alert(e.message); }
    }
    loadChats();
  };
  input.onkeydown=(ev)=>{ if(ev.key==='Enter'){ev.preventDefault();finish(true);} else if(ev.key==='Escape'){ev.preventDefault();finish(false);} };
  input.onblur=()=>finish(true);
}


async function deleteChatFromAlgorithm(chat){
  const name=chat.display_name||chat.name||chat.id;
  const ok=confirm(`Remove “${name}” from Ary AI?\n\nThis permanently removes its conversation data, analyses, and local contact entry from this algorithm. It does NOT delete, archive, block, or modify anything in WhatsApp.`);
  if(!ok)return;
  try{
    const r=await fetch(`/api/chats/${encodeURIComponent(chat.id)}`,{method:'DELETE'});
    const d=await r.json(); if(!r.ok)throw Error(d.error||'Could not remove contact');
    if(activeChatId===chat.id){ activeChatId=null; window.activeChatId=null; activeChat=null; goToPage('contacts-page'); }
    await loadChats();
  }catch(e){alert(e.message);}
}

async function openChat(c){
  activeChatId=c.id;
  window.activeChatId=c.id;
  activeChat=c; lastSuggestion=null; selectedMessageIds=new Set(); messageCache=[];
  if(conversationStartDate)conversationStartDate.value='';if(conversationEndDate)conversationEndDate.value='';if(conversationDateStatus)conversationDateStatus.textContent='';
  threadName.textContent=c.display_name||c.name||c.id;
  updateCurrentConversationHeader();
  goToPage('conversation-page');
  if(messages){
    messages.innerHTML='<div class="loading">Loading the complete conversation…</div>';
    try{await renderMessages();}catch(e){messages.innerHTML=`<div class="error">${esc(e.message||'Could not load conversation')}<br><small>Try Sync from this conversation and open it again.</small></div>`;}
  }
}
async function renderMessages(){
  const r=await fetch(`/api/chats/${encodeURIComponent(activeChatId)}/messages`);
  const payload=await r.json().catch(()=>({}));
  if(!r.ok) throw Error(payload.error||'Could not load conversation');
  const ms=Array.isArray(payload)?payload:(Array.isArray(payload.messages)?payload.messages:[]);
  messageCache=ms;
  refreshConversationDateBounds();
  let lastDay='';
  if(!ms.length){messages.innerHTML='<div class="empty-list">No messages are stored for this conversation yet. Click Sync to import the WhatsApp history, then reopen this conversation.</div>';updateSelectionChip();return;}
  messages.innerHTML=ms.map(m=>{ const d=new Date(m.timestamp||0); const dayKey=Number.isFinite(d.getTime())?d.toLocaleDateString(undefined,{year:'numeric',month:'long',day:'numeric'}):'Unknown date'; const separator=dayKey!==lastDay?(lastDay=dayKey,`<div class="day-separator"><span>${esc(dayKey)}</span></div>`):''; const body=String(m.body??'').trim() || '[Non-text message / no text content stored]'; const sender=m.from_me?'YOU':(m.sender_name||m.sender||'THEM'); return separator+`<div class="msg ${m.from_me?'me':''}" data-message-id="${esc(String(m.id))}"><label class="msg-select"><input type="checkbox" class="message-check" data-id="${esc(String(m.id))}" ${selectedMessageIds.has(String(m.id))?'checked':''} title="Select this message"></label><span>${esc(sender)} · ${Number.isFinite(d.getTime())?d.toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'}):''}</span><p>${esc(body)}</p></div>`; }).join('');
  messages.querySelectorAll('.message-check').forEach(cb=>cb.onchange=()=>{if(cb.checked)selectedMessageIds.add(String(cb.dataset.id));else selectedMessageIds.delete(String(cb.dataset.id));updateSelectionChip();});
  updateSelectionChip(); messages.scrollTop=messages.scrollHeight;
}
function updateSelectionChip(){const chip=$('selection-chip');if(chip)chip.textContent=`${selectedMessageIds.size} selected`;}
function selectedConversationText(){return messageCache.filter(m=>selectedMessageIds.has(String(m.id))).map(m=>{const d=new Date(m.timestamp||0);const ts=Number.isFinite(d.getTime())?`[${d.toISOString()}] `:'';return `${ts}${m.from_me?'ME':'THEM'}: ${String(m.body??'').trim()}`;}).filter(x=>!/: $/.test(x)).join('\n');}

function localDateKey(value){
  const d=new Date(value||0);if(!Number.isFinite(d.getTime()))return '';
  const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');
  return `${y}-${m}-${day}`;
}
function refreshConversationDateBounds(){
  if(!conversationStartDate||!conversationEndDate)return;
  const keys=messageCache.map(m=>localDateKey(m.timestamp)).filter(Boolean).sort();
  if(!keys.length){conversationStartDate.removeAttribute('min');conversationStartDate.removeAttribute('max');conversationEndDate.removeAttribute('min');conversationEndDate.removeAttribute('max');return;}
  const min=keys[0],max=keys[keys.length-1];
  for(const el of [conversationStartDate,conversationEndDate]){el.min=min;el.max=max;}
  if(conversationDateStatus)conversationDateStatus.textContent=`Available: ${min} to ${max}`;
}
function dateSpanDays(start,end){const a=new Date(`${start}T00:00:00`),b=new Date(`${end}T00:00:00`);return Math.round((b-a)/86400000)+1;}
function selectConversationDateRange(){
  const start=String(conversationStartDate?.value||''),end=String(conversationEndDate?.value||'');
  if(!start||!end){alert('Enter both a start date and an end date.');return;}
  if(end<start){alert('End date must be on or after the start date.');return;}
  if(dateSpanDays(start,end)>2){alert('Date-range selection is limited to 2 calendar days. Choose a shorter range.');return;}
  const matching=messageCache.filter(m=>{const key=localDateKey(m.timestamp);return key&&key>=start&&key<=end;});
  const limited=matching.slice(-MAX_ANALYSIS_MESSAGES);
  selectedMessageIds.clear();limited.forEach(m=>selectedMessageIds.add(String(m.id)));
  messages?.querySelectorAll('.message-check').forEach(cb=>{cb.checked=selectedMessageIds.has(String(cb.dataset.id));});
  updateSelectionChip();
  if(conversationDateStatus)conversationDateStatus.textContent=matching.length?`${matching.length.toLocaleString()} messages found. ${limited.length.toLocaleString()} selected from ${start} through ${end} (inclusive)${matching.length>MAX_ANALYSIS_MESSAGES?' — limited to the 5,000 most recent in this range.':''}`:`No stored messages fall between ${start} and ${end}.`;
  if(limited.length){const first=messages?.querySelector(`.message-check[data-id="${CSS.escape(String(limited[0].id))}"]`)?.closest('.msg');first?.scrollIntoView({behavior:'smooth',block:'center'});}
}


async function loadUserProfile(){try{const p=await fetch('/api/profile').then(r=>r.json());if(userGender)userGender.value=p.gender||'';if(userAge)userAge.value=p.age||'';}catch(_){} }
loadUserProfile();
loadRecentActivity();
saveProfile?.addEventListener('click',async()=>{try{const r=await fetch('/api/profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({gender:userGender?.value||'',age:userAge?.value||''})});const d=await r.json();if(!r.ok)throw Error(d.error||'Could not save profile');if(profileSaveStatus) profileSaveStatus.textContent='Saved locally'; setTimeout(()=>{if(profileSaveStatus) profileSaveStatus.textContent='';},1600);}catch(e){alert(e.message);}});

$('thread-rename-btn').onclick=async()=>{
  if(!activeChatId)return;
  const current=threadName.textContent||'';
  const next=prompt('Rename this chat (leave blank to reset to the WhatsApp name/number):', current);
  if(next===null)return; // cancelled
  try{
    const r=await fetch(`/api/chats/${encodeURIComponent(activeChatId)}/name`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:next})});
    const d=await r.json(); if(!r.ok)throw Error(d.error||'Rename failed');
    threadName.textContent=d.display_name; if(activeChat) activeChat.display_name=d.display_name;
    loadChats();
  }catch(e){ alert(e.message); }
};

$('thread-delete-btn').onclick=async()=>{ if(activeChatId && activeChat) await deleteChatFromAlgorithm(activeChat); };


/* ========================================================================== 
   DEEP ANALYSIS DASHBOARD — eight fixed categories with evidence trails.
   ========================================================================== */
const DEEP_DEFS=[{id:'overall',label:'Overall Interpretation',icon:'▣',className:'blue'},{id:'attitude',label:'Likely Attitude',icon:'☺',className:'green'},{id:'sarcasm_humour',label:'Sarcasm & Humour',icon:'☻',className:'orange'},{id:'psychology',label:'Psychology / Communication',icon:'✤',className:'purple'},{id:'risks',label:'Risks',icon:'△',className:'pink'},{id:'evidence',label:'Evidence',icon:'▤',className:'cyan'},{id:'strategy',label:'Strategy',icon:'◎',className:'teal'},{id:'alternatives',label:'Alternatives',icon:'↔',className:'indigo'}];
let latestAnalysis=null, deepActiveId='overall';

function renderCounterfactualResult(d){
  if(!counterfactualResult)return;
  const t=d?.target_message||{}; const ch=d?.change_analysis||{};
  const branches=Array.isArray(d?.branches)?d.branches:[];
  counterfactualResult.innerHTML=`<div class="cf-summary"><div class="cf-real"><b>REAL MESSAGE</b><blockquote>“${esc(t.real_text||'')}”</blockquote></div><div class="cf-arrow">→</div><div class="cf-hypo"><b>HYPOTHETICAL</b><blockquote>“${esc(t.hypothetical_text||'')}”</blockquote></div></div><div class="cf-change-grid"><div><b>What changed</b><p>${esc(ch.what_changed||'')}</p></div><div><b>Communication effect</b><p>${esc(ch.communication_effect||'')}</p></div><div><b>Risk change</b><p>${esc(ch.risk_change||'')}</p></div><div><b>Simulation confidence</b><p>${Number(ch.confidence||0)}% — confidence in the comparative interpretation, not certainty about a future event.</p></div></div><h3>Plausible downstream branches</h3><div class="cf-branches">${branches.map((b,i)=>`<article class="cf-branch"><div class="cf-branch-head"><b>${esc(b.name||`Branch ${i+1}`)}</b><span>${Number(b.likelihood_percent||0)}% plausibility</span></div><p><b>Likely next response pattern:</b> ${esc(b.likely_next_response_pattern||'')}</p><p><b>Downstream effect:</b> ${esc(b.downstream_effect||'')}</p><p><b>Why plausible:</b> ${esc(b.why_plausible||'')}</p>${Array.isArray(b.supporting_real_quotes)&&b.supporting_real_quotes.length?`<div class="cf-evidence"><b>Real conversation evidence</b>${b.supporting_real_quotes.map(q=>`<blockquote>“${esc(q.quote)}”<small>${esc(q.why||'')}</small></blockquote>`).join('')}</div>`:''}${Array.isArray(b.uncertainties)&&b.uncertainties.length?`<div class="cf-uncertainty"><b>Uncertainties</b><ul>${b.uncertainties.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`:''}</article>`).join('')}</div><div class="cf-guidance"><b>Decision guidance</b><p>${esc(d.decision_guidance||'')}</p></div>${Array.isArray(d.alternative_hypotheticals)&&d.alternative_hypotheticals.length?`<div class="cf-alts"><h3>Other hypothetical versions to test</h3>${d.alternative_hypotheticals.map(x=>`<div><blockquote>“${esc(x.message)}”</blockquote><p>${esc(x.expected_effect)}</p></div>`).join('')}</div>`:''}<div class="cf-limits"><b>Simulation limits</b><ul>${(Array.isArray(d.simulation_limits)?d.simulation_limits:[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`;
}
async function populateCounterfactualTargets(){
  if(!counterfactualTarget||!activeChatId)return;
  try{
    const r=await fetch(`/api/chats/${encodeURIComponent(activeChatId)}/messages?limit=80`); const ms=await r.json();
    if(!r.ok)throw Error(ms.error||'Could not load messages');
    const preferred=Array.isArray(latestAnalysis?.selected_messages)?latestAnalysis.selected_messages:[];
    const rows=(preferred.length?preferred:ms).slice(-60).reverse();
    counterfactualTarget.innerHTML=rows.length?rows.map(m=>`<option value="${esc(String(m.id))}">${esc(new Date(m.timestamp||0).toLocaleString())} · ${m.from_me?'ME':'THEM'} · ${esc(String(m.body||'').slice(0,120))}</option>`).join(''):'<option value="">No messages available</option>';
  }catch(e){counterfactualTarget.innerHTML=`<option value="">${esc(e.message||'Could not load messages')}</option>`;}
}
async function runCounterfactual(){
  if(!activeChatId)return alert('Open a conversation first.');
  const target=counterfactualTarget?.value||''; const hypothetical=counterfactualText?.value.trim()||''; const objective=counterfactualObjective?.value.trim()||'';
  if(!target)return alert('Choose the message to replace.'); if(!hypothetical)return alert('Enter the hypothetical replacement message.');
  const requestId=beginCancellableRequest(); if(counterfactualRun)counterfactualRun.disabled=true; if(counterfactualStatus)counterfactualStatus.textContent='Simulating plausible branches…'; startAnalysisTimer('counterfactual',SELECTION_LIMIT_MS);
  try{const r=await fetch(`/api/chats/${encodeURIComponent(activeChatId)}/counterfactual`,{method:'POST',headers:{'Content-Type':'application/json','x-analysis-request-id':requestId},body:JSON.stringify({request_id:requestId,target_message_id:target,hypothetical_text:hypothetical,objective}),signal:combinedSignalFor(SELECTION_UI_TIMEOUT_MS)});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Counterfactual simulation failed.');renderCounterfactualResult(d);if(counterfactualStatus)counterfactualStatus.textContent='Simulation complete. Results saved to history.';recordTiming('selection',Date.now()-timerStartedAt);}
  catch(e){if(String(e.message)==='CANCELLED_BY_USER'||String(e.message)==='Stopped by user.') {if(counterfactualStatus)counterfactualStatus.textContent='Stopped by you.';} else {if(counterfactualStatus)counterfactualStatus.textContent=e.message||'Simulation failed.';}}
  finally{stopAnalysisTimer(counterfactualStatus?.textContent||'Ready.');if(counterfactualRun)counterfactualRun.disabled=false;currentRequestId=null;currentAbortController=null;}
}
function resetInsights(){latestAnalysis=null;insights.classList.remove('hidden');analysisDashboard.classList.remove('hidden');analysisDeep.classList.add('hidden');analysisCards.innerHTML='<div class="insights-placeholder"><b>Your 8-part AI analysis appears here.</b><br>Run Analyze + Generate to populate the evidence cards.</div>';deepTabs.innerHTML='';deepBody.innerHTML='';history.replaceState(null,'',location.pathname+location.search);}
function evidenceCard(title,item,{noteLabel='justification',extraNote=''}={}){item=item||{};const pct=Number.isFinite(Number(item.percent))?Math.max(0,Math.min(100,Math.round(Number(item.percent)))):null;const quote=String(item.quote||'').trim();const note=String(item[noteLabel]||item.explanation||item.interpretation||item.point||extraNote||'').trim();const principle=String(item.principle||'').trim();const type=String(item.evidence_type||'direct').toLowerCase()==='indirect'?'Indirect hint':'Direct evidence';const cue=String(item.cue||item.change||'').trim();const prev=String(item.previous_quote||'').trim();return `<div class="evidence-item"><div class="evidence-head"><b>${esc(title)}</b><span class="evidence-type ${type.startsWith('Indirect')?'indirect':''}">${type}</span>${pct==null?'':`<span class="confidence">${pct}% confidence</span>`}</div>${pct==null?'':`<div class="confidence-bar"><i style="width:${pct}%"></i></div>`}${quote?`<blockquote>“${esc(quote)}”</blockquote>`:`<blockquote class="missing">No verified quote was available for this claim.</blockquote>`}${prev?`<div class="previous-quote"><b>Compared with:</b> “${esc(prev)}”</div>`:''}${cue?`<div class="indirect-cue"><b>Observable cue:</b> ${esc(cue)}</div>`:''}${principle?`<div class="evidence-principle"><b>Psychological / communication principle:</b> ${esc(principle)}</div>`:''}${note?`<p>${esc(note)}</p>`:''}</div>`;}
function evidenceList(items,titleFn=(x)=>'Evidence'){if(!Array.isArray(items)||!items.length)return '<div class="no-evidence">No verified direct or indirect evidence was available for this conclusion.</div>';return items.map((x,i)=>evidenceCard(titleFn(x,i),x,{noteLabel:'justification'})).join('');}
function normalizeDeepForUI(d){if(d?.deep_analysis)return d.deep_analysis;const sig=d?.signals||{},ev=d?.evidence||[],att=d?.likely_attitude||{},psych=d?.psychology_lenses||[];const risk=(d?.risks||[]).map(r=>typeof r==='string'?{conclusion:r,evidence:[]}:r);const alts=(d?.alternatives||[]).map(a=>typeof a==='string'?{response:a,evidence:[]}:a);const strat=d?.strategy&&typeof d.strategy==='object'?d.strategy:{conclusion:d?.strategy||'',evidence:[]};return {overall:{conclusion:d?.psychology_summary||d?.intent?.summary||'Overall interpretation from the conversation.',percent:d?.confidence_overall?.percent??0,evidence:ev.slice(0,4)},attitude:{conclusion:att.summary||'Likely textual attitude.',percent:att.percent??0,evidence:[att].filter(x=>x.quote)},sarcasm_humour:{conclusion:`Sarcasm: ${sig.sarcasm?.detected?'detected':'not strongly detected'}; humour: ${sig.humor?.detected?'detected':'not strongly detected'}.`,percent:Math.max(sig.sarcasm?.percent??0,sig.humor?.percent??0),evidence:[sig.sarcasm,sig.humor].filter(x=>x?.quote)},psychology:{conclusion:d?.psychology_summary||'Communication patterns interpreted from observable text.',percent:Math.round(psych.reduce((a,x)=>a+(x.percent||0),0)/Math.max(1,psych.length)),evidence:psych},risks:{conclusion:risk.map(x=>x.conclusion).filter(Boolean).join(' · ')||'No major text-supported risk identified.',percent:risk.length?Math.max(...risk.map(x=>x.percent||0)):25,evidence:risk.flatMap(x=>x.evidence||[]).slice(0,6)},evidence:{conclusion:'The strongest direct excerpts supporting the analysis.',percent:ev.length?85:15,evidence:ev},strategy:{conclusion:strat.conclusion||'Match the response to the strongest observable signals.',percent:strat.percent??0,evidence:strat.evidence||ev.slice(0,2),steps:strat.steps||[]},alternatives:{conclusion:alts.map(x=>x.response).filter(Boolean).join(' · ')||'Generate alternatives only when supported by the conversation.',percent:alts.length?Math.min(85,40+alts.length*8):0,evidence:alts.flatMap(x=>x.evidence||[]).slice(0,6),options:alts.map(x=>x.response).filter(Boolean)}};}
function deepSectionHtml(id){
  const all=normalizeDeepForUI(latestAnalysis),s=all[id]||{},def=DEEP_DEFS.find(x=>x.id===id)||DEEP_DEFS[0];
  let extra='';
  if(id==='psychology'&&latestAnalysis?.psychology_lenses?.length) extra=`<div class="principle-list"><h4>Principles used</h4>${latestAnalysis.psychology_lenses.map(x=>`<span>${esc(x.principle)}</span>`).join('')}</div>`;
  if(id==='sarcasm_humour'&&latestAnalysis?.signals) extra=`<div class="signal-grid">${Object.entries(latestAnalysis.signals).map(([k,v])=>evidenceCard(k.replace(/^./,c=>c.toUpperCase()),v,{noteLabel:'explanation'})).join('')}</div>`;
  if(id==='strategy'&&s.steps?.length) extra+=`<h4>Recommended steps</h4><ol class="steps">${s.steps.map(x=>`<li>${esc(x)}</li>`).join('')}</ol>`;
  if(id==='alternatives'&&(s.options?.length||latestAnalysis?.candidate_responses?.length)) extra+=`<h4>Alternative response paths</h4><div class="alternative-list">${(s.options||latestAnalysis.candidate_responses?.map(x=>x.response)||[]).map((x,i)=>`<div><b>${i+1}</b>${esc(typeof x==='string'?x:x.response||'')}</div>`).join('')}</div>`;
  const counter=Array.isArray(s.counter_evidence)?s.counter_evidence:[];
  if(counter.length) extra+=`<div class="counter-panel"><div class="evidence-panel-title"><h3>Counter-evidence</h3><span>Signals that reduce certainty or support another interpretation</span></div>${evidenceList(counter,(x,i)=>`Counter-evidence ${i+1}`)}</div>`;
  const baseline=latestAnalysis?.contact_baseline;
  const baselineHtml=(id==='attitude'||id==='overall')&&baseline?.sample_size?`<div class="baseline-box"><b>Contact-specific baseline</b><span>Compared against ${Number(baseline.sample_size).toLocaleString()} prior messages from THEM. Typical message length: ${baseline.typical_length||'—'} words; typical questions: ${baseline.typical_questions??'—'}.</span>${Array.isArray(baseline.dominant_tones)?`<small>Usual tones: ${baseline.dominant_tones.map(x=>esc(x.label)).join(', ')}</small>`:''}</div>`:'';
  const comparison=id==='overall'&&Array.isArray(latestAnalysis?.tone_comparison)&&latestAnalysis.tone_comparison.length?`<div class="comparison-panel"><div class="evidence-panel-title"><h3>Competing interpretations</h3><span>The algorithm compares alternatives before deciding</span></div>${latestAnalysis.tone_comparison.map((x,i)=>`<div class="comparison-row"><b>${i+1}. ${esc(x.tone||'Interpretation')}</b><span>${Number.isFinite(Number(x.percent))?Math.round(Number(x.percent))+'%':''}</span><p>${esc(x.supporting_reason||'')}</p>${x.supporting_quote?`<blockquote>“${esc(x.supporting_quote)}”</blockquote>`:''}${x.contradicting_quote?`<small>Counter-signal: “${esc(x.contradicting_quote)}” — ${esc(x.contradicting_reason||'')}</small>`:''}</div>`).join('')}</div>`:'';
  return `<div class="deep-section-head"><div class="deep-icon ${def.className}">${def.icon}</div><div><span class="section-kicker">CATEGORY ${DEEP_DEFS.findIndex(x=>x.id===id)+1} OF 8</span><h2>${esc(def.label)}</h2></div>${Number.isFinite(Number(s.percent))?`<span class="deep-confidence">${Math.round(Number(s.percent))}% confidence</span>`:''}</div><div class="conclusion-box"><b>Conclusion</b><p>${esc(s.conclusion||'No conclusion returned.')}</p></div>${baselineHtml}${comparison}<div class="evidence-panel"><div class="evidence-panel-title"><h3>How the AI reached this conclusion</h3><span>Direct evidence + justification + principle</span></div>${evidenceList(s.evidence||[],(x,i)=>`Evidence ${i+1}`)}</div>${extra}<div class="analysis-feedback"><b>Help improve this analysis</b><span>Feedback is stored locally and used as a correction for future analyses.</span><div><button class="tiny feedback-action" data-feedback-kind="wrong_conclusion">✕ Wrong conclusion</button><button class="tiny feedback-action" data-feedback-kind="wrong_tone">◌ Wrong tone</button><button class="tiny feedback-action" data-feedback-kind="bad_evidence">▤ Evidence doesn't support it</button><button class="tiny feedback-action" data-feedback-kind="correct">✓ Looks right</button></div></div>`;
}
function renderDeepTabs(openId='overall'){deepTabs.innerHTML=DEEP_DEFS.map(d=>`<button class="deep-tab ${d.id===openId?'active':''}" data-deep-tab="${d.id}">${esc(d.label)}</button>`).join('');deepTabs.querySelectorAll('[data-deep-tab]').forEach(b=>b.onclick=()=>openDeepAnalysis(b.dataset.deepTab));}
function openDeepAnalysis(id='overall'){if(!latestAnalysis)return;deepActiveId=DEEP_DEFS.some(x=>x.id===id)?id:'overall';analysisDashboard.classList.add('hidden');analysisDeep.classList.remove('hidden');insights.classList.remove('hidden');renderDeepTabs(deepActiveId);deepBody.innerHTML=deepSectionHtml(deepActiveId);history.replaceState(null,'',location.pathname+location.search+'#deep-analysis-'+deepActiveId);deepBody.scrollTop=0;}
function wireFeatureExplorer(){
  deepBody.querySelectorAll('[data-explorer]').forEach(b=>b.onclick=()=>openDeepAnalysis(b.dataset.explorer));
}
function closeDeepAnalysis(){analysisDeep.classList.add('hidden');analysisDashboard.classList.remove('hidden');history.replaceState(null,'',location.pathname+location.search);}
async function submitAnalysisFeedback(kind){
  if(!activeChatId||!latestAnalysis)return;
  const labels={wrong_conclusion:'The conclusion is wrong or too strong.',wrong_tone:'The detected tone is wrong.',bad_evidence:'The cited evidence does not justify the conclusion.',correct:'This analysis looks correct.'};
  const detail=prompt('Optional correction for the AI:\n\n'+(labels[kind]||'Feedback')+'\n\nTell it what should be different:',kind==='correct'?'Looks correct.':'');
  if(detail===null)return;
  const note=(detail||labels[kind]||'User feedback').trim();
  try{const r=await fetch(`/api/chats/${encodeURIComponent(activeChatId)}/analysis-feedback`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind,note})});if(!r.ok)throw Error((await r.json()).error||'Could not save feedback');alert('Saved. Future analyses for this contact will consider this correction.');}catch(e){alert(e.message);}
}
if(deepOpen)deepOpen.onclick=()=>openDeepAnalysis('overall');if(deepBack)deepBack.onclick=closeDeepAnalysis;if(counterfactualOpen)counterfactualOpen.onclick=async()=>{counterfactualPanel?.classList.remove('hidden');await populateCounterfactualTargets();counterfactualText?.focus();};if(counterfactualClose)counterfactualClose.onclick=()=>counterfactualPanel?.classList.add('hidden');if(counterfactualRun)counterfactualRun.onclick=runCounterfactual;if(deepBody)deepBody.onclick=(ev)=>{const b=ev.target.closest('.feedback-action');if(b)submitAnalysisFeedback(b.dataset.feedbackKind);};
window.addEventListener('hashchange',()=>{const m=location.hash.match(/^#deep-analysis-(.+)$/);if(m&&latestAnalysis)openDeepAnalysis(m[1]);else if(!m)closeDeepAnalysis();});
const TONE_DISPLAY={warm:'Warm',affectionate:'Affectionate',friendly:'Friendly',playful:'Playful',humorous:'Humorous',sarcastic:'Sarcastic',flirty:'Flirty',casual:'Casual',curious:'Curious',enthusiastic:'Enthusiastic',excited:'Excited',confident:'Confident',direct:'Direct',professional:'Professional',formal:'Formal',serious:'Serious',reassuring:'Reassuring',concerned:'Concerned',frustrated:'Frustrated',neutral:'Neutral / matter-of-fact'};
function make20TonePie(values){
  const ids=Object.keys(TONE_DISPLAY);const rows=ids.map(id=>[id,Math.max(0,Number(values?.[id])||0)]);const total=rows.reduce((a,[,v])=>a+v,0)||1;let cursor=0;
  const positive=rows.filter(([,v])=>v>0);const stops=positive.map(([id,v])=>{const a=cursor/total*360;cursor+=v;const b=cursor/total*360;return `var(--c-${Math.abs(hashCode(id))%8}) ${a}deg ${b}deg`;}).join(',');
  const legend=rows.map(([id,v])=>`<div class="pie-legend"><span class="swatch sw-${Math.abs(hashCode(id))%8}"></span><span>${esc(TONE_DISPLAY[id])}</span><b>${v.toFixed(1)}%</b></div>`).join('');
  return `<div class="tone-pie-card"><div class="tone-pie-copy"><h3>20-feeling distribution</h3><span>Every selected message contributes. Percentages are normalized to 100% across the 20 applicable textual tone signals.</span></div><div class="pie-wrap twenty"><div class="pie tone-pie" style="background:${stops?`conic-gradient(${stops})`:'#eef1f6'}"></div><div class="pie-legend-list twenty">${legend}</div></div></div>`;
}
function visualBaselineHtml(){
  const v=latestAnalysis?.analysis_visuals||{}; const b=v.baseline||{}, c=v.current||{};
  if(!b.sample_size||!c.sample_size) return `<div class="feature-panel baseline-feature"><div class="feature-head"><div><span class="feature-kicker">01 · PERSONAL BASELINE</span><h3>Baseline + Change Detection</h3><p>What is normal for this person, and what changed?</p></div><button class="feature-open" data-feature-tab="baseline_change">Open detailed view →</button></div><div class="feature-empty">Not enough prior incoming messages are available to build a reliable personal baseline yet.</div></div>`;
  const metric=(label,bv,cv,unit='')=>{const max=Math.max(Number(bv)||0,Number(cv)||0,1);return `<div class="baseline-metric"><div class="baseline-metric-head"><b>${esc(label)}</b><span>${Number(bv).toFixed(1)} → ${Number(cv).toFixed(1)}${unit?' '+unit:''}</span></div><div class="dual-bar"><i style="width:${Math.max(3,Math.min(100,(Number(bv)||0)/max*100))}%"></i><b style="width:${Math.max(3,Math.min(100,(Number(cv)||0)/max*100))}%"></b></div><small>Usual <strong>${Number(bv).toFixed(1)}</strong> · Selected <strong>${Number(cv).toFixed(1)}</strong></small></div>`};
  const changes=(v.changes||[]).map(x=>`<div class="change-pill ${x.direction||'stable'}"><b>${esc(x.metric)}</b><span>${x.direction==='changed'?'changed':x.direction==='up'?'↑ increased':x.direction==='down'?'↓ decreased':'→ stable'}${x.change_percent!=null?` · ${Math.abs(Number(x.change_percent)).toFixed(0)}%`:''}</span></div>`).join('');
  const tones=(v.tone_changes||[]).slice(0,5).map(x=>`<div class="tone-change-row"><span>${esc(x.label)}</span><b class="${x.delta>0?'up':x.delta<0?'down':'stable'}">${x.delta>0?'+':''}${Number(x.delta).toFixed(1)} pts</b></div>`).join('');
  return `<div class="feature-panel baseline-feature"><div class="feature-head"><div><span class="feature-kicker">01 · PERSONAL BASELINE</span><h3>Baseline + Change Detection</h3><p>Compared with ${Number(b.sample_size).toLocaleString()} prior incoming messages.</p></div><button class="feature-open" data-feature-tab="baseline_change">Open detailed view →</button></div><div class="baseline-grid">${metric('Average message length',b.avg_words,c.avg_words,'words')}${metric('Questions per message',b.avg_questions,c.avg_questions)}${metric('Exclamations per message',b.avg_exclamations,c.avg_exclamations)}</div><div class="change-pills">${changes||'<span class="muted">No material change detected by these observable metrics.</span>'}</div><div class="tone-change-box"><b>Tone movement vs personal baseline</b>${tones||'<span class="muted">No strong tone movement detected.</span>'}</div></div>`;
}
function explorerRows(){
  const deep=normalizeDeepForUI(latestAnalysis); return DEEP_DEFS.map(d=>{const s=deep[d.id]||{};const ev=Array.isArray(s.evidence)?s.evidence:[], counter=Array.isArray(s.counter_evidence)?s.counter_evidence:[];return `<button class="explorer-row" data-explorer="${d.id}"><span class="explorer-icon">${d.icon}</span><span><b>${esc(d.label)}</b><small>${esc(String(s.conclusion||'').slice(0,180))}</small></span><strong>${Number.isFinite(Number(s.percent))?Math.round(Number(s.percent))+'%':''}</strong><em>${ev.length} support · ${counter.length} counter</em></button>`;}).join('');
}
function evidenceExplorerHtml(){return `<div class="feature-panel evidence-explorer-feature"><div class="feature-head"><div><span class="feature-kicker">02 · ACCOUNTABILITY</span><h3>Evidence Explorer</h3><p>Every conclusion is traceable: conclusion → supporting messages → counter-evidence → alternatives → confidence.</p></div><button class="feature-open" data-feature-tab="evidence_explorer">Open full explorer →</button></div><div class="explorer-list">${explorerRows()}</div><div class="feature-note">Click any conclusion to open its full evidence trail. Direct evidence and indirect hints are explicitly labelled.</div></div>`;}
function timelineHtml(){
  const v=latestAnalysis?.analysis_visuals||{}, rows=v.timeline||[], turns=v.turning_points||[];
  if(!rows.length) return `<div class="feature-panel timeline-feature"><div class="feature-head"><div><span class="feature-kicker">03 · CHRONOLOGY</span><h3>Conversation Timeline</h3><p>Tone → engagement → relationship signals, with turning points highlighted.</p></div><button class="feature-open" data-feature-tab="timeline">Open detailed view →</button></div><div class="feature-empty">Timeline data will appear after a conversation analysis is completed.</div></div>`;
  const line=rows.map((x,i)=>`<div class="timeline-segment ${turns.some(t=>Number(t.segment)===Number(x.index))?'turning':''}"><div class="timeline-dot"></div><div class="timeline-card"><div class="timeline-head"><b>Segment ${x.index}</b><span>${new Date(x.start).toLocaleDateString()} · ${x.message_count} messages</span></div><div class="timeline-main"><strong>${esc(x.dominant_tone_label)}</strong><span>Engagement ${x.engagement}%</span></div><div class="timeline-bar"><i style="width:${x.engagement}%"></i></div><div class="timeline-meta"><span>YOU ${x.outgoing} · THEM ${x.incoming}</span><span>${x.relationship_signals?.length?esc(x.relationship_signals.join(' · ')):'No strong relationship-signal shift'}</span></div></div></div>`).join('');
  const turning=turns.length?`<div class="turning-points"><h4>Turning points</h4>${turns.slice(0,8).map((t,i)=>`<div class="turning-point"><span>${i+1}</span><div><b>${esc(t.tone||'Interaction shift')}</b><p>${esc(t.reason||'Observable change across adjacent timeline segments.')}</p>${t.quote?`<blockquote>“${esc(t.quote)}”</blockquote>`:''}</div></div>`).join('')}</div>`:'<div class="feature-note">No strong turning point crossed the visual threshold. Small changes may still be present in the underlying evidence.</div>';
  return `<div class="feature-panel timeline-feature"><div class="feature-head"><div><span class="feature-kicker">03 · CHRONOLOGY</span><h3>Conversation Timeline</h3><p>Chronological view of tone, emotional intensity proxies, engagement and relationship signals.</p></div><button class="feature-open" data-feature-tab="timeline">Open full timeline →</button></div><div class="timeline-track">${line}</div>${turning}</div>`;
}
function featureTabs(){
  upsertTab('baseline_change','Baseline + Change',visualBaselineHtml());
  upsertTab('evidence_explorer','Evidence Explorer',evidenceExplorerHtml());
  upsertTab('timeline','Conversation Timeline',timelineHtml());
}
function renderDashboard(){const deep=normalizeDeepForUI(latestAnalysis);const toneScores=latestAnalysis?.tone_distribution||latestAnalysis?.tone_scores||{};const ranked=Object.entries(toneScores).sort((a,b)=>Number(b[1])-Number(a[1])).slice(0,5);const coverage=latestAnalysis?.analysis_scope;const coveragePanel=coverage?`<div class="coverage-panel"><b>Selection coverage: ${Number(coverage.coverage_percent??100).toFixed(0)}%</b><span>${Number(coverage.messages_considered||coverage.selected_messages||0).toLocaleString()} / ${Number(coverage.selected_messages||0).toLocaleString()} selected messages considered · ${Number(coverage.batches_completed||0)} bounded AI batches</span></div>`:'';const tonePanel=make20TonePie(toneScores)+`<div class="tone-profile-panel"><div><h3>Strongest tone signals</h3><span>Direct wording + indirect hints + changes across the selected sequence</span></div><div class="tone-bars">${ranked.map(([id,v])=>`<div><span>${esc(TONE_DISPLAY[id]||id.replace(/_/g,' '))}</span><i><b style="width:${Math.max(2,Math.min(100,Number(v)||0))}%"></b></i><em>${Number(v||0).toFixed(1)}%</em></div>`).join('')}</div></div>`;featureTabs();analysisCards.innerHTML=coveragePanel+tonePanel+`<div class="analysis-feature-grid">${visualBaselineHtml()}${evidenceExplorerHtml()}${timelineHtml()}</div>`+DEEP_DEFS.map(d=>{const s=deep[d.id]||{},ev=Array.isArray(s.evidence)?s.evidence:[],pct=Number.isFinite(Number(s.percent))?Math.round(Number(s.percent)):null;return `<button class="analysis-card ${d.className}" data-card="${d.id}"><span class="card-icon">${d.icon}</span><span class="card-copy"><b>${esc(d.label)}</b><small>${esc(String(s.conclusion||'Analysis pending').slice(0,105))}</small></span>${pct==null?'':`<span class="card-confidence">${pct}%</span>`}<span class="card-evidence">${ev.length} evidence ${ev.length===1?'item':'items'}</span></button>`;}).join('');analysisCards.querySelectorAll('[data-card]').forEach(b=>b.onclick=()=>openDeepAnalysis(b.dataset.card));analysisCards.querySelectorAll('[data-explorer]').forEach(b=>b.onclick=()=>openDeepAnalysis(b.dataset.explorer));analysisCards.querySelectorAll('[data-feature-tab]').forEach(b=>{b.onclick=(ev)=>{ev.stopPropagation();showTab(b.dataset.featureTab);}});}


if(selectionBtn) selectionBtn.onclick=async()=>{const sel=window.getSelection()?.toString().trim();if(!activeChatId){alert('Open a chat first.');return;}if(!sel){alert('Highlight/select the message text you want analyzed, then click this button.');return;}selectionBtn.disabled=true;selectionBtn.textContent='Analyzing…';insights.classList.remove('hidden');analysisCards.innerHTML='<div class="loading">Analyzing the selected text and checking nearby context… <small>Large selections are analyzed in safe batches; the server remains responsive while Ollama processes each batch.</small></div>';const requestId=beginCancellableRequest();startAnalysisTimer('selection',SELECTION_LIMIT_MS);try{const r=await fetch(`/api/chats/${encodeURIComponent(activeChatId)}/analyze-selection`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:sel,instruction:selectionRequest.value,request_id:requestId}),signal:combinedSignalFor(SELECTION_UI_TIMEOUT_MS)});const d=await r.json();if(!r.ok)throw Error(d.error||'Selection analysis failed');latestAnalysis={...d,deep_analysis:{overall:{conclusion:d.reasoning||`Primary tone: ${d.tone||'Unknown'}.`,percent:d.overall_confidence?.percent??0,evidence:d.evidence||[],counter_evidence:d.counter_evidence||[]},attitude:{conclusion:d.attitude?.summary||'Likely textual attitude.',percent:d.attitude?.percent??0,evidence:[d.attitude].filter(x=>x?.quote),counter_evidence:d.counter_evidence||[]},sarcasm_humour:{conclusion:`Sarcasm: ${d.sarcasm?.detected?'detected':'not strongly detected'}; humour: ${d.humor?.detected?'detected':'not strongly detected'}.`,percent:Math.max(d.sarcasm?.percent??0,d.humor?.percent??0),evidence:[d.sarcasm,d.humor].filter(x=>x?.quote),counter_evidence:d.counter_evidence||[]},psychology:{conclusion:d.reasoning||'Communication patterns identified in the selected text.',percent:(d.psychology_lenses||[]).length?Math.round((d.psychology_lenses||[]).reduce((a,x)=>a+(Number(x.percent)||0),0)/(d.psychology_lenses||[]).length):0,evidence:d.psychology_lenses||[],counter_evidence:d.counter_evidence||[]},risks:{conclusion:d.argumentative?.detected?'Potential argumentative escalation signal.':'No major risk signal detected in the selection.',percent:d.argumentative?.percent??0,evidence:[d.argumentative].filter(x=>x?.quote),counter_evidence:d.counter_evidence||[]},evidence:{conclusion:'Direct excerpts from the selected text and nearby context.',percent:d.evidence?.length?Math.min(95,40+d.evidence.length*10):0,evidence:d.evidence||[],counter_evidence:d.counter_evidence||[]},strategy:{conclusion:'Respond in a way that matches the selected text while accounting for ambiguity.',percent:d.strategy?.percent??0,evidence:d.strategy?.evidence?.slice(0,3)||d.evidence?.slice(0,3)||[],counter_evidence:d.counter_evidence||[]},alternatives:{conclusion:d.alternative_interpretation||'Consider at least one alternative interpretation before responding.',percent:d.alternatives?.length?Math.min(85,40+d.alternatives.length*8):0,evidence:d.alternatives?.flatMap(x=>x?.evidence||[]).slice(0,3)||d.evidence?.slice(0,3)||[],counter_evidence:d.counter_evidence||[]}}};if(d.deep_analysis)latestAnalysis={...d,deep_analysis:d.deep_analysis};renderDashboard();openDeepAnalysis('overall');recordTiming('selection',Date.now()-timerStartedAt);stopAnalysisTimer(`Finished in ${formatTimer(Date.now()-timerStartedAt)}.<br>${estimateDisplayHtml()}`);}catch(e){const cancelled=/stopped by user|aborted/i.test(e.message||'');if(!cancelled){analysisCards.innerHTML=`<div class="error">${esc(e.message)}</div>`;stopAnalysisTimer();}}finally{selectionBtn.disabled=false;selectionBtn.textContent='Analyze selected text';currentRequestId=null;currentAbortController=null;}};

function wireDynamicHandlers(){const btn=$('save-correction');if(btn&&!btn.dataset.wired){btn.dataset.wired='1';btn.onclick=async()=>{const box=$('correction-box');const note=box.value.trim();if(!note)return;const rr=await fetch(`/api/chats/${encodeURIComponent(activeChatId)}/analysis-feedback`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:'interpretation_rule',note})});if(rr.ok)btn.textContent='Saved';else alert('Could not save correction.');};}const dljson=$('download-json');if(dljson&&!dljson.dataset.wired){dljson.dataset.wired='1';dljson.onclick=()=>downloadReportJson();}const dlhtml=$('download-html');if(dlhtml&&!dlhtml.dataset.wired){dlhtml.dataset.wired='1';dlhtml.onclick=()=>downloadReportHtml();}}

let tabDefs=[],tabContent={},activeTabId=null;
function upsertTab(id,label,html){tabContent[id]=html;const found=tabDefs.find(t=>t.id===id);if(found)found.label=label;else tabDefs.push({id,label});}
function renderTabBar(){deepTabs.innerHTML=tabDefs.map(t=>`<button class="deep-tab ${t.id===activeTabId?'active':''}" data-tab="${esc(t.id)}">${esc(t.label)}</button>`).join('');deepTabs.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));}
function showTab(id){if(!tabContent[id])return;activeTabId=id;analysisDashboard.classList.add('hidden');analysisDeep.classList.remove('hidden');renderTabBar();deepBody.innerHTML=tabContent[id];deepBody.scrollTop=0;wireFeatureExplorer();const dljson=$('download-json');if(dljson)dljson.onclick=()=>downloadReportJson();const dlhtml=$('download-html');if(dlhtml)dlhtml.onclick=()=>downloadReportHtml();}

/* ---- stats / report tabs (persist once loaded, alongside whatever analysis is active) ---- */
function makePie(values){
  const entries=Object.entries(values||{}).filter(([,v])=>Number(v)>0);
  if(!entries.length)return '<div class="pie-empty">No analyzed tone data yet.</div>';
  let cursor=0; const total=entries.reduce((a,[,v])=>a+Number(v),0); const stops=entries.map(([k,v])=>{const a=cursor/total*360; cursor+=Number(v); const b=cursor/total*360; return `var(--c-${Math.abs(hashCode(k))%8}) ${a}deg ${b}deg`;}).join(',');
  const legend=entries.map(([k,v])=>`<div class="pie-legend"><span class="swatch sw-${Math.abs(hashCode(k))%8}"></span><span>${esc(k)}</span><b>${Number(v).toFixed(1)}%</b></div>`).join('');
  return `<div class="pie-wrap"><div class="pie" style="background:conic-gradient(${stops})"></div><div class="pie-legend-list">${legend}</div></div>`;
}
function hashCode(str){let h=0;for(let i=0;i<str.length;i++)h=((h<<5)-h)+str.charCodeAt(i)|0;return h;}
async function loadStats(){
  if(!activeChatId)return null;
  const d=await fetch(`/api/chats/${encodeURIComponent(activeChatId)}/stats?limit=5000`).then(r=>r.json());
  if(d.error)throw Error(d.error); return d;
}
statsBtn.onclick=async()=>{
  if(!activeChatId)return;
  insights.classList.remove('hidden');
  upsertTab('stats','Stats','<div class="loading">Loading conversation stats…</div>'); renderTabBar(); showTab('stats');
  try{
    const d=await loadStats(); const p=d.overall.percentages; const labels=Object.keys(p).sort((a,b)=>p[b]-p[a]);
    const html=`<div class="card"><div class="stats-head"><b>Conversation profile</b><span>${d.overall.sample_size} messages analyzed</span></div><p><b>Mostly:</b> ${esc(d.overall.mostly)} · <b>Secondary:</b> ${d.overall.secondary.map(esc).join(', ')}</p>${makePie(p)}<div class="bars">${labels.map(k=>`<div class="bar-row"><span>${esc(k)}</span><div><i style="width:${Math.max(2,p[k])}%"></i></div><b>${p[k]}%</b></div>`).join('')}</div><p class="muted">These are text-signal frequencies, not measurements of someone's inner emotional state.</p>${d.trend?.length?`<h4>Recent trend</h4><div class="trend">${d.trend.slice(-14).map(x=>`<span><b>${esc(x.date.slice(5))}</b><small>${esc(x.mostly)}</small></span>`).join('')}</div>`:''}</div>`;
    upsertTab('stats','Stats',html); showTab('stats');
  }catch(e){ upsertTab('stats','Stats',`<div class="error">${esc(e.message)}</div>`); showTab('stats'); }
};

let lastReportData=null;
reportBtn.onclick=async()=>{
  if(!activeChatId)return;
  insights.classList.remove('hidden');
  upsertTab('report','Report','<div class="loading">Building the saved conversation report…</div>'); renderTabBar(); showTab('report');
  try{
    const [st,history]=await Promise.all([loadStats(),fetch(`/api/chats/${encodeURIComponent(activeChatId)}/analysis-history?limit=5000`).then(r=>r.json())]);
    if(history.error)throw Error(history.error);
    const items=history.items||[];
    const chatTitle=activeChat?.display_name||activeChat?.name||activeChatId;
    const tone=st.overall.percentages||{};
    lastReportData={chatTitle,st,items,tone};
    const rows=items.map((x,i)=>{
      const a=x.analysis||{};
      const responseText = readable(a.response) || x.edited_text || x.response_text || '(none)';
      const toneText = readable(a.tone) || readable(a.likely_attitude) || '';
      const reasonText = readable(a.reasoning) || readable(a.psychology_summary) || '';
      const quotesUsed = collectQuotes(a);
      return `<details class="report-item"><summary>#${i+1} · ${new Date(x.created_at).toLocaleString()} · ${esc(x.kind)}</summary><p><b>Selected text:</b> ${esc(x.selected_text||'(none)')}</p><p><b>User request:</b> ${esc(x.user_request||'(none)')}</p><p><b>Response:</b> ${esc(responseText)}</p><p><b>Tone:</b> ${esc(toneText)}</p><p><b>Reasoning:</b> ${esc(reasonText)}</p>${quotesUsed.length?`<p><b>Quoted evidence used:</b></p><ul>${quotesUsed.map(q=>`<li>&ldquo;${esc(q)}&rdquo;</li>`).join('')}</ul>`:''}</details>`;
    }).join('');
    const html=`<div class="card"><div class="stats-head"><b>Conversation report</b><span>${items.length} saved analyses</span></div><h4>Tone distribution</h4>${makePie(tone)}<p><b>Mostly:</b> ${esc(st.overall.mostly)}</p><div class="report-actions"><button id="download-json" class="small">Download data (JSON)</button><button id="download-html" class="small">Download report (HTML)</button></div></div><div class="card"><h4>Saved selections & responses</h4>${rows||'<p class="muted">No saved analyses yet. Analyze a response or select text to begin.</p>'}</div>`;
    upsertTab('report','Report',html); showTab('report');
  }catch(e){ upsertTab('report','Report',`<div class="error">${esc(e.message)}</div>`); showTab('report'); }
};
// Pulls a display string out of a field that may be a plain string or a
// {summary/quote/percent} evidence object (schema differs between the
// analyze+draft and analyze-selection endpoints).
function readable(x){
  if(x==null) return '';
  if(typeof x==='string') return x;
  if(typeof x==='object') return x.summary || x.point || x.interpretation || '';
  return String(x);
}
// Walks a saved analysis object and pulls every verbatim quote out of it, so
// the report can show exactly which lines of the conversation backed each
// percentage that was shown at the time.
function collectQuotes(a){
  const out=new Set();
  const visit=v=>{
    if(!v) return;
    if(Array.isArray(v)){ v.forEach(visit); return; }
    if(typeof v==='object'){
      if(typeof v.quote==='string' && v.quote.trim()) out.add(v.quote.trim());
      Object.values(v).forEach(visit);
    }
  };
  visit(a);
  return [...out].slice(0,20);
}
function safeName(s){return String(s||'conversation').replace(/[^a-z0-9_-]+/gi,'_').slice(0,80)||'conversation';}
function dl(blob,name){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
function downloadReportJson(){
  if(!lastReportData)return;
  const {chatTitle,st,items}=lastReportData;
  const blob=JSON.stringify({chat:chatTitle,generated_at:new Date().toISOString(),stats:st,analyses:items},null,2);
  dl(new Blob([blob],{type:'application/json'}),`${safeName(chatTitle)}-conversation-data.json`);
}
function downloadReportHtml(){
  if(!lastReportData)return;
  const {chatTitle,st,items,tone}=lastReportData;
  const html=`<!doctype html><html><head><meta charset="utf-8"><title>Conversation Report - ${esc(chatTitle)}</title><style>body{font-family:Arial,sans-serif;max-width:900px;margin:40px auto;line-height:1.5;color:#222}.pie{width:280px;height:280px;border-radius:50%;margin:20px auto}.item{border-top:1px solid #ddd;padding:12px 0}small{color:#666}blockquote{border-left:3px solid #45a380;margin:6px 0;padding:4px 12px;color:#333;font-style:italic}</style></head><body><h1>Conversation Report: ${esc(chatTitle)}</h1><p>Generated ${new Date().toLocaleString()}</p><h2>Tone distribution</h2><div class="pie" style="background:conic-gradient(${Object.entries(tone).map(([,v],i)=>`hsl(${i*45},60%,55%) ${Object.values(tone).slice(0,i).reduce((a,n)=>a+n,0)/100*360}deg ${Object.values(tone).slice(0,i+1).reduce((a,n)=>a+n,0)/100*360}deg`).join(',')})"></div><pre>${esc(JSON.stringify(st.overall,null,2))}</pre><h2>Saved analyses (${items.length})</h2>${items.map((x,i)=>{
    const a=x.analysis||{};
    const responseText=readable(a.response)||x.edited_text||x.response_text||'(none)';
    const toneText=readable(a.tone)||readable(a.likely_attitude)||'';
    const reasonText=readable(a.reasoning)||readable(a.psychology_summary)||'';
    const quotes=collectQuotes(a);
    return `<div class="item"><b>#${i+1} ${esc(x.kind)}</b><br>${new Date(x.created_at).toLocaleString()}<p><b>Selected:</b> ${esc(x.selected_text||'(none)')}</p><p><b>Request:</b> ${esc(x.user_request||'(none)')}</p><p><b>Response:</b> ${esc(responseText)}</p><p><b>Tone/reasoning:</b> ${esc(toneText)} — ${esc(reasonText)}</p>${quotes.length?`<p><b>Quoted evidence:</b></p>${quotes.map(q=>`<blockquote>${esc(q)}</blockquote>`).join('')}`:''}</div>`;
  }).join('')}</body></html>`;
  dl(new Blob([html],{type:'text/html'}),`${safeName(chatTitle)}-conversation-report.html`);
}


sync.onclick=async()=>{sync.disabled=true;sync.textContent='Syncing…';syncStatus.textContent='Starting a safe background sync…';try{const r=await fetch('/api/sync',{method:'POST'});const d=await r.json();if(!r.ok)throw Error(d.error||'Could not start sync');syncStatus.textContent=d.sync?.detail||'Sync is running in the background. You can keep using Copilot.';}catch(e){syncStatus.textContent=`Could not start sync: ${e.message}`;}finally{setTimeout(()=>{sync.disabled=false;sync.textContent='Sync now';},1200);}};

digest.onclick=async()=>{modal.classList.remove('hidden');digestBody.innerHTML='Loading…';try{const d=await fetch('/api/priorities').then(r=>r.json());if(d.error)throw Error(d.error);digestBody.innerHTML=`<p>${esc(d.summary)}</p>`+(d.items||[]).map(i=>`<article class="card"><h3>${esc(i.chat_name)} <small>${esc(i.priority)} · ${i.score}</small></h3><p>${esc(i.reason)}</p><p><b>Action:</b> ${esc(i.suggested_action)}</p></article>`).join('');}catch(e){digestBody.textContent=e.message;}};
$('digest-close').onclick=()=>modal.classList.add('hidden');



// Keep connection/model state visible and recoverable without restarting the browser.
setInterval(async()=>{ try { const st=await fetch('/api/status').then(r=>r.json()); const dot=$('conn-dot'); if(dot) dot.title=`WhatsApp: ${st.status} · AI: ${st.model}`; } catch(_){} }, 5000);


/* ==========================================================================
   SITE NAVIGATION
   ========================================================================== */
const pageTabs=[...document.querySelectorAll('.nav-tab')];
function goToPage(pageId){
  if(!document.getElementById(pageId)) return;
  if(window.__CA_NAV) window.__CA_NAV(pageId);
  else { document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active-page',p.id===pageId)); pageTabs.forEach(t=>t.classList.toggle('active',t.dataset.page===pageId)); }
  if(pageId==='history-page') loadRecentActivity();
  if(pageId==='relationship-page') loadRelationshipChats();
  if(pageId==='contacts-page') loadChats();
  if(pageId==='conversation-page' && activeChatId) renderMessages();
  if(pageId==='reports-page') loadSavedReports();
  if(pageId==='deep-page' && latestAnalysis) renderDashboard();
  window.scrollTo({top:0,behavior:'smooth'});
}

function updateCurrentConversationHeader(){
  const el=$('top-conversation');
  if(el) el.textContent=activeChat ? (activeChat.display_name||activeChat.name||activeChat.id) : 'Select a conversation';
}

const contactsSync=$('contacts-sync');
if(contactsSync) contactsSync.onclick=()=>sync.click();
const contactSearch=$('contact-search');
if(contactSearch) contactSearch.addEventListener('input',()=>{
  const q=contactSearch.value.trim().toLowerCase();
  chatList.querySelectorAll('.chat-item').forEach(el=>el.classList.toggle('hidden',q && !el.textContent.toLowerCase().includes(q)));
});

/* ------------------------ History & Settings ---------------------------- */
async function loadRecentActivity(){
  const list=$('activity-list'); if(!list) return;
  list.innerHTML='<div class="loading">Loading recent activity…</div>';
  try{
    const r=await fetch('/api/activity?limit=60'); const d=await r.json(); if(!r.ok) throw Error(d.error||'Could not load activity');
    const items=d.items||[];
    if(!items.length){list.innerHTML='<div class="empty-list">No recent activity yet. Analyze some text or selected conversation messages to begin.</div>';return;}
    list.innerHTML=items.map(x=>{
      const date=new Date(Number(x.created_at)||0);
      const label=x.activity_type==='saved_report'?'Saved report':'Analysis';
      const kind=String(x.activity_kind||'').replace(/_/g,' ');
      return `<article class="activity-item"><div class="activity-icon">${x.activity_type==='saved_report'?'▣':'◈'}</div><div class="activity-copy"><b>${esc(label)} · ${esc(kind)}</b><span>${esc(x.contact_name||x.chat_id||'Unknown conversation')}</span><p>${esc(x.detail||'')}</p></div><time>${esc(date.toLocaleString())}</time></article>`;
    }).join('');
  }catch(e){list.innerHTML=`<div class="error">${esc(e.message)}</div>`;}
}
$('refresh-activity')?.addEventListener('click',loadRecentActivity);

/* ------------------------ Relationship Mode ---------------------------- */
const REL_TONES={flirtatious:'Flirtatious',affectionate:'Affectionate',interested:'Interested',insecure_uncertain:'Insecure / uncertain',complimentary:'Complimentary',teasing:'Teasing',playful:'Playful',vulnerable:'Vulnerable',warm:'Warm',attentive:'Attentive',curious:'Curious',enthusiastic:'Enthusiastic',excited:'Excited',reassuring:'Reassuring',reserved:'Reserved',distant:'Distant',frustrated:'Frustrated',ambivalent:'Ambivalent',jealous:'Jealous / possessive',supportive:'Supportive'};
const REL_SECTIONS=[
  ['objective_alignment','Objective alignment'],['relationship_dynamic','Relationship dynamic'],['attraction_interest','Attraction & interest'],['insecurity_vulnerability','Insecurity & vulnerability'],['flirting_affection','Flirting & affection'],['reciprocity_effort','Reciprocity & effort'],['barriers_risks','Barriers & risks'],['strategy','Objective strategy']
];
async function loadRelationshipChats(){
  if(!relationshipChats)return;
  try{const r=await fetch('/api/chats');const cs=await r.json();if(!r.ok)throw Error(cs.error||'Could not load conversations');
    relationshipChats.innerHTML=cs.length?cs.map(c=>{const n=c.display_name||c.name||c.id;return `<label class="relationship-chat-option"><input type="checkbox" value="${esc(c.id)}"><span><b>${esc(n)}</b><small>${Number(c.message_count||0).toLocaleString()} stored messages</small></span><i class="relationship-checkmark">✓</i></label>`;}).join(''):'<div class="empty-list">No conversations available yet. Sync WhatsApp first.</div>';
    const updatePicker=()=>{const inputs=[...relationshipChats.querySelectorAll('input')],checked=inputs.filter(i=>i.checked);inputs.forEach(i=>{i.disabled=checked.length>=2&&!i.checked;i.closest('.relationship-chat-option')?.classList.toggle('selected',i.checked);});const status=$('relationship-picker-status');if(status)status.textContent=checked.length?`${checked.length} of 2 conversations selected`:'Choose 1 or 2 conversations.';};
    relationshipChats.querySelectorAll('input').forEach(x=>x.onchange=updatePicker);updatePicker();
  }catch(e){relationshipChats.innerHTML=`<div class="error">${esc(e.message)}</div>`;}
}
function relationshipTimerStart(){if(relationshipTimerHandle)clearInterval(relationshipTimerHandle);relationshipTimerStarted=Date.now();const limit=SELECTION_LIMIT_MS;relationshipTimerHandle=setInterval(()=>{const elapsed=Date.now()-relationshipTimerStarted;relationshipTimer.textContent=`Running: ${formatTimer(elapsed)} elapsed · ${formatTimer(Math.max(0,limit-elapsed))} left of ${formatTimer(limit)} max`;},250);relationshipTimer.textContent=`Running: 00:00 elapsed · ${formatTimer(limit)} left of ${formatTimer(limit)} max`;}
function relationshipTimerStop(text){if(relationshipTimerHandle){clearInterval(relationshipTimerHandle);relationshipTimerHandle=null;}if(relationshipTimer)relationshipTimer.textContent=text||'AI timer: idle';}
function relationshipPie(values){const raw=Object.entries(REL_TONES).map(([id,label])=>[id,label,Math.max(0,Number(values?.[id])||0)]);const total=raw.reduce((a,x)=>a+x[2],0);const rows=raw.map(x=>[x[0],x[1],total>0?(x[2]/total*100):0]);let cur=0;const stops=rows.filter(x=>x[2]>0).map(x=>{const a=cur/100*360;cur+=x[2];const b=cur/100*360;return `var(--c-${Math.abs(hashCode(x[0]))%8}) ${a}deg ${b}deg`;}).join(',');return `<div class="relationship-tone-chart"><div class="relationship-pie" style="background:${stops?`conic-gradient(${stops})`:'#edf0f5'}"></div><div class="relationship-tone-legend">${rows.map(x=>`<div><span class="swatch sw-${Math.abs(hashCode(x[0]))%8}"></span><span>${esc(x[1])}</span><b>${x[2].toFixed(1)}%</b></div>`).join('')}</div></div>`;}
function renderRelationshipResult(d){
  relationshipResult=d;const scope=d.analysis_scope||{};const conv=(d.conversations||[]).map(c=>`${esc(c.name)} (${Number(c.message_count||0).toLocaleString()} messages)`).join(' · ');
  $('relationship-results').classList.remove('hidden');$('relationship-result-head').innerHTML=`<div class="relationship-result-title"><div><span class="eyebrow">RELATIONSHIP RESULT</span><h2>${esc(d.relationship_status_label||'Relationship analysis')}</h2><p><b>Objective:</b> ${esc(d.objective||'')}</p><p>${conv}</p></div><div class="relationship-coverage"><b>${Number(scope.coverage_percent||100).toFixed(0)}% message coverage</b><span>${Number(scope.messages_considered||0).toLocaleString()} / ${Number(scope.messages_selected||0).toLocaleString()} messages · ${Number(scope.batches_completed||0)} AI batches</span></div></div><div class="relationship-conclusion"><b>Overall assessment</b><p>${esc(d.overall_conclusion||'')}</p><b>Objective assessment</b><p>${esc(d.objective_assessment||'')}</p><strong>${Math.round(Number(d.objective_percent)||0)}% confidence</strong></div>`;
  $('relationship-tone-panel').innerHTML=`<div class="relationship-panel"><div><h3>Relationship psychology tone distribution</h3><p>All ${Number(scope.messages_considered||0).toLocaleString()} processed messages contribute to the observable tone distribution. These are communication signals, not diagnoses or proof of hidden feelings.</p></div>${relationshipPie(d.relationship_tones||{})}<div class="relationship-principles"><h3>Psychological principles used</h3>${(d.psychology||[]).length?(d.psychology||[]).map((x,i)=>`<article class="relationship-principle"><b>${esc(x.principle||'Relationship psychology')}</b><span>${esc(x.interpretation||'')}</span>${evidenceCard(`Evidence ${i+1}`,x,{noteLabel:'observable cue'})}</article>`).join(''):'<p class="muted">The analysis used the relationship-principle framework and observable evidence.</p>'}</div></div>`;
  $('relationship-sections').innerHTML=`<div class="relationship-section-grid">${REL_SECTIONS.map(([id,label])=>{const x=d.sections?.[id]||{};const ev=x.evidence||[];return `<article class="relationship-section"><div class="relationship-section-head"><h3>${esc(label)}</h3><b>${Math.round(Number(x.percent)||0)}%</b></div><p class="relationship-conclusion">${esc(x.conclusion||'No conclusion returned.')}</p><div class="evidence-panel"><div class="evidence-panel-title"><h4>Evidence & psychological justification</h4><span>${ev.length} verified item${ev.length===1?'':'s'}</span></div>${evidenceList(ev,(e,i)=>`Evidence ${i+1}`)}</div>${x.counter_evidence?.length?`<div class="counter-panel"><b>Counter-evidence</b>${evidenceList(x.counter_evidence,(e,i)=>`Counter-signal ${i+1}`)}</div>`:''}</article>`;}).join('')}</div><div class="relationship-alternatives"><h3>Alternative explanations</h3>${(d.alternative_explanations||[]).length?(d.alternative_explanations||[]).map((x,i)=>evidenceCard(`Alternative ${i+1}`,x,{noteLabel:'explanation'})).join(''):'<p class="muted">No additional alternative explanations were returned beyond the competing interpretations used during synthesis.</p>'}</div>`;
}
if(relationshipRun)relationshipRun.onclick=async()=>{
  const ids=[...relationshipChats.querySelectorAll('input:checked')].map(x=>x.value).slice(0,2);const objective=relationshipObjective.value.trim();if(!ids.length){alert('Choose at least one conversation.');return;}if(!objective){alert('List your objective first.');relationshipObjective.focus();return;}
  relationshipRun.disabled=true;relationshipRun.textContent='Analyzing relationship…';relationshipStop.classList.remove('hidden');relationshipTimerStart();relationshipResult=null;const requestId=beginCancellableRequest();
  $('relationship-status-note').textContent='Every stored message in the selected conversation(s) is being assigned to a bounded chronological AI batch. Do not close the page.';
  try{const r=await fetch('/api/relationship-analysis',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_ids:ids,objective,relationship_status:relationshipStatus.value,request_id:requestId}),signal:combinedSignalFor(SELECTION_UI_TIMEOUT_MS)});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Relationship analysis failed');renderRelationshipResult(d);relationshipTimerStop(`Finished in ${formatTimer(Date.now()-relationshipTimerStarted)} · ${Number(d.analysis_scope?.messages_considered||0).toLocaleString()} messages considered.`);$('relationship-status-note').textContent='Completed. The result above is a separate Relationship Mode analysis and does not replace ordinary Deep Analysis.';window.scrollTo({top:$('relationship-results').offsetTop-90,behavior:'smooth'});
  }catch(e){const cancelled=/stopped by user|aborted/i.test(e.message||'');if(!cancelled)alert(e.message);relationshipTimerStop(cancelled?'Stopped by you.':'Analysis ended with an error; the server remains available.');}finally{relationshipRun.disabled=false;relationshipRun.textContent='♡ Run Relationship Analysis';relationshipStop.classList.add('hidden');currentRequestId=null;currentAbortController=null;}
};
if(relationshipStop)relationshipStop.onclick=async()=>{relationshipStop.disabled=true;relationshipStop.textContent='Stopping…';await cancelCurrentRequest();relationshipTimerStop('Stopping…');setTimeout(()=>{relationshipStop.disabled=false;relationshipStop.textContent='Stop';relationshipStop.classList.add('hidden');},500);};

/* ---------------------- Conversation selection ------------------------- */
async function analyzeSelectedConversation(){
  if(!activeChatId){alert('Open a conversation first.');return;}
  const requestedRaw=Number(deepAnalysisCount?.value||1000);
  if(!Number.isFinite(requestedRaw)||requestedRaw<1||requestedRaw>MAX_ANALYSIS_MESSAGES){alert('Deep Analysis can analyze between 1 and 5,000 messages.');deepAnalysisCount?.focus();return;}
  const requested=Math.floor(requestedRaw);
  if(deepAnalysisCount) deepAnalysisCount.value=String(requested);
  const btn=conversationAnalyzeBtn; if(btn){btn.disabled=true;btn.textContent=`Analyzing ${requested.toLocaleString()} messages…`;}
  const focus=String($('conversation-focus')?.value||'').trim();
  const requestId=beginCancellableRequest(); startAnalysisTimer('selection',SELECTION_LIMIT_MS);
  try{
    const r=await fetch(`/api/chats/${encodeURIComponent(activeChatId)}/analyze-selection`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message_limit:requested,instruction:focus,request_id:requestId}),signal:combinedSignalFor(SELECTION_UI_TIMEOUT_MS)});
    const d=await r.json(); if(!r.ok) throw Error(d.error||'Selection analysis failed');
    latestAnalysis={...d,deep_analysis:{
      overall:{conclusion:d.reasoning||`Primary tone: ${d.tone||'Unknown'}.`,percent:d.overall_confidence?.percent??0,evidence:d.evidence||[],counter_evidence:d.counter_evidence||[]},
      attitude:{conclusion:d.attitude?.summary||'Likely textual attitude.',percent:d.attitude?.percent??0,evidence:[d.attitude].filter(x=>x?.quote)},
      sarcasm_humour:{conclusion:`Sarcasm: ${d.sarcasm?.detected?'detected':'not strongly detected'}; humour: ${d.humor?.detected?'detected':'not strongly detected'}.`,percent:Math.max(d.sarcasm?.percent??0,d.humor?.percent??0),evidence:[d.sarcasm,d.humor].filter(x=>x?.quote)},
      psychology:{conclusion:d.psychology_summary||d.reasoning||'Communication patterns identified in the selected text.',percent:(d.psychology_lenses||[]).length?Math.round((d.psychology_lenses||[]).reduce((a,x)=>a+(Number(x.percent)||0),0)/(d.psychology_lenses||[]).length):0,evidence:d.psychology_lenses||[]},
      risks:{conclusion:d.argumentative?.detected?'Potential argumentative escalation signal.':'No major risk signal detected in the selection.',percent:d.argumentative?.percent??0,evidence:[d.argumentative].filter(x=>x?.quote)},
      evidence:{conclusion:'Direct excerpts from the selected messages and nearby context.',percent:d.evidence?.length?Math.min(95,40+d.evidence.length*10):0,evidence:d.evidence||[]},
      strategy:{conclusion:'Interpret the selected messages using the strongest observable signals.',percent:d.strategy?.percent??0,evidence:d.strategy?.evidence?.slice(0,3)||d.evidence?.slice(0,3)||[]},
      alternatives:{conclusion:d.alternative_interpretation||'Consider at least one alternative interpretation.',percent:d.alternatives?.length?Math.min(85,40+d.alternatives.length*8):0,evidence:d.alternatives?.flatMap(x=>x?.evidence||[]).slice(0,3)||d.evidence?.slice(0,3)||[]}
    }};
    if(d.deep_analysis) latestAnalysis={...d,deep_analysis:d.deep_analysis};
    const summary=$('current-result-summary'); if(summary) summary.textContent=`${activeChat?.display_name||activeChat?.name||activeChatId} · Deep Analysis · ${Number(d.analysis_scope?.selected_messages||requested).toLocaleString()} messages · ${new Date().toLocaleString()}`;
    renderDashboard(); goToPage('deep-page'); openDeepAnalysis('overall');
    recordTiming('selection',Date.now()-timerStartedAt); stopAnalysisTimer(`Finished in ${formatTimer(Date.now()-timerStartedAt)}.`);
  }catch(e){if(!/stopped by user|aborted/i.test(e.message||'')){alert(e.message);stopAnalysisTimer();}}
  finally{if(btn){btn.disabled=false;btn.textContent='◈ Analyze requested messages';}currentRequestId=null;currentAbortController=null;}
}
conversationAnalyzeBtn?.addEventListener('click',analyzeSelectedConversation);
$('conversation-select-all')?.addEventListener('click',()=>{const chosen=messageCache.slice(-MAX_ANALYSIS_MESSAGES);selectedMessageIds.clear();chosen.forEach(m=>selectedMessageIds.add(String(m.id)));messages?.querySelectorAll('.message-check').forEach(cb=>cb.checked=selectedMessageIds.has(String(cb.dataset.id)));updateSelectionChip();if(conversationDateStatus)conversationDateStatus.textContent=`${chosen.length.toLocaleString()} most recent messages selected${messageCache.length>MAX_ANALYSIS_MESSAGES?` (limited from ${messageCache.length.toLocaleString()} stored messages).`:'.'}`;});

conversationSelectRange?.addEventListener('click',selectConversationDateRange);
conversationSummaryBtn?.addEventListener('click',async()=>{
  if(!activeChatId){alert('Choose a conversation first.');return;}
  let start=String(conversationStartDate?.value||''), end=String(conversationEndDate?.value||'');
  if(!start||!end){
    const keys=messageCache.map(m=>localDateKey(m.timestamp)).filter(Boolean).sort();
    if(!keys.length){alert('No stored messages are available. Sync the conversation first.');return;}
    end=keys.at(-1); const d=new Date(`${end}T00:00:00`); d.setDate(d.getDate()-1); start=localDateKey(d);
    if(conversationStartDate)conversationStartDate.value=start; if(conversationEndDate)conversationEndDate.value=end;
  }
  if(end<start||dateSpanDays(start,end)>2){alert('Conversation Summary supports a maximum of 2 calendar days.');return;}
  const matching=messageCache.filter(m=>{const key=localDateKey(m.timestamp);return key&&key>=start&&key<=end;});
  if(!matching.length){alert(`No stored messages fall between ${start} and ${end}.`);return;}
  const focus=String($('conversation-focus')?.value||'').trim();
  conversationSummaryBtn.disabled=true; conversationSummaryBtn.textContent='Summarizing…';
  const requestId=beginCancellableRequest(); startAnalysisTimer('summary',SELECTION_LIMIT_MS);
  try{
    const r=await fetch(`/api/chats/${encodeURIComponent(activeChatId)}/summarize`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({start_date:start,end_date:end,instruction:focus,request_id:requestId}),signal:combinedSignalFor(SELECTION_UI_TIMEOUT_MS)});
    const d=await r.json(); if(!r.ok)throw Error(d.error||'Conversation summary failed');
    latestAnalysis=d; renderConversationSummary(d); goToPage('deep-page');
    const summary=$('current-result-summary'); if(summary)summary.textContent=`${activeChat?.display_name||activeChat?.name||activeChatId} · ${d.title||'Conversation Summary'} · ${start} → ${end}`;
    recordTiming('summary',Date.now()-timerStartedAt); stopAnalysisTimer(`Finished in ${formatTimer(Date.now()-timerStartedAt)}.`);
  }catch(e){if(!/stopped by user|aborted/i.test(e.message||'')){alert(e.message);stopAnalysisTimer();}}
  finally{conversationSummaryBtn.disabled=false;conversationSummaryBtn.textContent='✦ AI Summary';currentRequestId=null;currentAbortController=null;}
});

$('conversation-clear')?.addEventListener('click',()=>{selectedMessageIds.clear();messages?.querySelectorAll('.message-check').forEach(cb=>cb.checked=false);updateSelectionChip();if(conversationDateStatus)conversationDateStatus.textContent='Selection cleared.';});
$('conversation-back')?.addEventListener('click',()=>goToPage('contacts-page'));

/* --------------------------- Analyze Text page --------------------------- */
const analyzeTextBtn=$('analyze-text-btn'), analyzeTextInput=$('analyze-text-input'), analyzeTextWordCount=$('analyze-text-word-count'), analyzeTextWordWarning=$('analyze-text-word-warning');
const textSourcePaste=$('text-source-paste'), textSourceContact=$('text-source-contact'), textPastePanel=$('text-paste-panel'), textContactPanel=$('text-contact-panel'), textContactSelect=$('text-contact-select');
let textAnalysisSource='paste';
function analyzeTextWords(){ return String(analyzeTextInput?.value||'').trim().split(/\s+/).filter(Boolean); }
function updateAnalyzeTextCount(){
  const n=analyzeTextInput ? analyzeTextWords().length : 0;
  if(analyzeTextWordCount) analyzeTextWordCount.textContent=`${n} / ${MAX_TEXT_ANALYSIS_WORDS} words`;
  if(analyzeTextWordWarning) analyzeTextWordWarning.textContent=n>MAX_TEXT_ANALYSIS_WORDS?`Too long — shorten to ${MAX_TEXT_ANALYSIS_WORDS.toLocaleString()} words or fewer.`:'';
  if(analyzeTextBtn){
    const invalidPaste=textAnalysisSource==='paste' && (n===0 || n>MAX_TEXT_ANALYSIS_WORDS);
    const invalidContact=textAnalysisSource==='contact' && !String(textContactSelect?.value||'').trim();
    analyzeTextBtn.disabled=invalidPaste||invalidContact;
  }
}
function setTextAnalysisSource(source){
  textAnalysisSource=source==='contact'?'contact':'paste';
  textSourcePaste?.classList.toggle('active',textAnalysisSource==='paste');
  textSourceContact?.classList.toggle('active',textAnalysisSource==='contact');
  textPastePanel?.classList.toggle('hidden',textAnalysisSource!=='paste');
  textContactPanel?.classList.toggle('hidden',textAnalysisSource!=='contact');
  if(analyzeTextBtn) analyzeTextBtn.textContent=textAnalysisSource==='contact'?'Analyze contact text':'Analyze pasted text';
  if(textAnalysisSource==='contact') refreshTextContactOptions();
  updateAnalyzeTextCount();
}
textSourcePaste?.addEventListener('click',()=>setTextAnalysisSource('paste'));
textSourceContact?.addEventListener('click',()=>setTextAnalysisSource('contact'));
textContactSelect?.addEventListener('change',updateAnalyzeTextCount);
if(analyzeTextInput){ analyzeTextInput.addEventListener('input',updateAnalyzeTextCount); updateAnalyzeTextCount(); }

function renderTextAnalysisSummary(d,metaText=''){
  const root=$('text-analysis-results'), points=$('text-analysis-points'), pie=$('text-analysis-pie'), graph=$('text-analysis-graph'), meta=$('text-analysis-result-meta');
  if(!root||!points||!pie||!graph) return;
  const deep=normalizeDeepForUI(d); const defs=DEEP_DEFS;
  points.innerHTML=defs.map(def=>{
    const sec=deep[def.id]||{};
    const pct=Number.isFinite(Number(sec.percent))?` <strong>${Math.round(Number(sec.percent))}%</strong>`:'';
    const ev=Array.isArray(sec.evidence)?sec.evidence.filter(x=>String(x?.quote||'').trim()):[];
    const first=ev[0]||{};
    const quote=String(first.quote||'').trim();
    const why=String(first.justification||first.interpretation||first.explanation||first.point||'').trim();
    const principle=String(first.principle||'').trim();
    return `<li><b>${esc(def.label)}</b>${pct}<span>${esc(String(sec.conclusion||'No sufficiently supported conclusion was established.'))}</span>${quote?`<blockquote>“${esc(quote)}”</blockquote>`:'<small class="summary-no-evidence">No verified direct quote supports this conclusion.</small>'}${why?`<small><b>Why:</b> ${esc(why)}</small>`:''}${principle?`<small><b>Principle:</b> ${esc(principle)}</small>`:''}</li>`;
  }).join('');
  const scores=d?.tone_distribution||d?.tone_scores||{};
  const ranked=Object.entries(scores).map(([id,v])=>[id,Math.max(0,Number(v)||0)]).filter(([,v])=>v>0).sort((a,b)=>b[1]-a[1]);
  const top=ranked.slice(0,5); const other=Math.max(0,100-top.reduce((a,[,v])=>a+v,0)); const pieRows=[...top]; if(other>.05) pieRows.push(['other',other]);
  const palette=['var(--c-0)','var(--c-1)','var(--c-2)','var(--c-3)','var(--c-4)','var(--c-5)']; let cursor=0;
  const stops=pieRows.map(([id,v],i)=>{const a=cursor*3.6;cursor+=v;return `${palette[i%palette.length]} ${a}deg ${cursor*3.6}deg`;}).join(',');
  pie.innerHTML=`<div class="text-mini-pie" style="background:${stops?`conic-gradient(${stops})`:'#eef1f6'}"></div><div class="text-mini-pie-legend">${pieRows.map(([id,v],i)=>`<div><i style="background:${palette[i%palette.length]}"></i><span>${esc(id==='other'?'Other tones':(TONE_DISPLAY[id]||id.replace(/_/g,' ')))}</span><b>${v.toFixed(1)}%</b></div>`).join('')}</div>`;
  const bars=ranked.slice(0,10); const max=Math.max(1,...bars.map(([,v])=>v));
  graph.innerHTML=bars.map(([id,v],i)=>`<div class="text-graph-row"><span>${i+1}. ${esc(TONE_DISPLAY[id]||id.replace(/_/g,' '))}</span><i><b style="width:${Math.max(2,v/max*100)}%"></b></i><strong>${v.toFixed(1)}%</strong></div>`).join('')||'<div class="feature-empty">No tone scores were returned.</div>';
  if(meta) meta.textContent=metaText;
  root.classList.remove('hidden');
}

$('text-analysis-open-deep')?.addEventListener('click',()=>{if(latestAnalysis){goToPage('deep-page');openDeepAnalysis('overall');}});

if(analyzeTextBtn) analyzeTextBtn.onclick=async()=>{
  const pastedText=String(analyzeTextInput?.value||'').trim();
  const wordCount=analyzeTextWords().length;
  const contactId=String(textContactSelect?.value||'').trim();
  if(textAnalysisSource==='paste'&&!pastedText){alert('Paste some text to analyze first.');return;}
  if(textAnalysisSource==='paste'&&wordCount>MAX_TEXT_ANALYSIS_WORDS){alert(`Text Analysis accepts up to ${MAX_TEXT_ANALYSIS_WORDS.toLocaleString()} words. You pasted ${wordCount.toLocaleString()}.`);updateAnalyzeTextCount();return;}
  if(textAnalysisSource==='contact'&&!contactId){alert('Choose a contact conversation first.');return;}
  analyzeTextBtn.disabled=true; analyzeTextBtn.textContent='Analyzing…';
  insights.classList.remove('hidden');
  const requestId=beginCancellableRequest(); startAnalysisTimer('text-analysis',TEXT_ANALYSIS_LIMIT_MS);
  try{
    const r=await fetch('/api/text-analysis',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source:textAnalysisSource,text:pastedText,chat_id:contactId,instruction:String(selectionRequest?.value||'').trim(),request_id:requestId}),signal:combinedSignalFor(TEXT_ANALYSIS_UI_TIMEOUT_MS)});
    const d=await r.json(); if(!r.ok) throw Error(d.error||'Text analysis failed');
    latestAnalysis={...d,deep_analysis:d.deep_analysis||{
      overall:{conclusion:d.reasoning||`Primary tone: ${d.tone||'Unknown'}.`,percent:d.overall_confidence?.percent??0,evidence:d.evidence||[]},
      attitude:{conclusion:d.attitude?.summary||'Likely textual attitude.',percent:d.attitude?.percent??0,evidence:[d.attitude].filter(x=>x?.quote)},
      sarcasm_humour:{conclusion:`Sarcasm: ${d.sarcasm?.detected?'detected':'not strongly detected'}; humour: ${d.humor?.detected?'detected':'not strongly detected'}.`,percent:Math.max(d.sarcasm?.percent??0,d.humor?.percent??0),evidence:[d.sarcasm,d.humor].filter(x=>x?.quote)},
      psychology:{conclusion:d.psychology_summary||d.reasoning||'Communication patterns identified in the selected text.',percent:(d.psychology_lenses||[]).length?Math.round((d.psychology_lenses||[]).reduce((a,x)=>a+(Number(x.percent)||0),0)/(d.psychology_lenses||[]).length):0,evidence:d.psychology_lenses||[]},
      risks:{conclusion:d.argumentative?.detected?'Potential argumentative escalation signal.':'No major risk signal detected in the selection.',percent:d.argumentative?.percent??0,evidence:[d.argumentative].filter(x=>x?.quote)},
      evidence:{conclusion:'Direct excerpts from the analyzed text.',percent:d.evidence?.length?Math.min(95,40+d.evidence.length*10):0,evidence:d.evidence||[]},
      strategy:{conclusion:'Respond in a way that matches the strongest observable signals.',percent:d.strategy?.percent??0,evidence:d.strategy?.evidence?.slice(0,3)||d.evidence?.slice(0,3)||[]},
      alternatives:{conclusion:d.alternative_interpretation||'Consider at least one alternative interpretation before responding.',percent:d.alternatives?.length?Math.min(85,40+d.alternatives.length*8):0,evidence:d.alternatives?.flatMap(x=>x?.evidence||[]).slice(0,3)||d.evidence?.slice(0,3)||[]}
    }};
    renderDashboard();
    const sourceName=d?.analysis_source?.label|| (textAnalysisSource==='paste'?'Pasted text':'Contact conversation');
    const sourceWords=Number(d?.analysis_source?.word_count||wordCount||0);
    const metaText=`${sourceName} · ${sourceWords.toLocaleString()} words · ${new Date().toLocaleString()}`;
    renderTextAnalysisSummary(latestAnalysis,metaText);
    const summary=$('current-result-summary'); if(summary) summary.textContent=`${sourceName} · Text analysis · ${new Date().toLocaleString()}`;
    recordTiming('selection',Date.now()-timerStartedAt); stopAnalysisTimer(`Finished in ${formatTimer(Date.now()-timerStartedAt)}.<br>Text Analysis max: ${formatTimer(TEXT_ANALYSIS_LIMIT_MS)}`);
    $('text-analysis-results')?.scrollIntoView({behavior:'smooth',block:'start'});
  }catch(e){ if(!/stopped by user|aborted/i.test(e.message||'')){alert(e.message);stopAnalysisTimer();} }
  finally{analyzeTextBtn.disabled=false;analyzeTextBtn.textContent=textAnalysisSource==='contact'?'Analyze contact text':'Analyze pasted text';currentRequestId=null;currentAbortController=null;updateAnalyzeTextCount();}
};


function renderConversationSummary(d){
  const bullets=(arr,key='text')=>(Array.isArray(arr)&&arr.length)?`<ul class="summary-list">${arr.map(x=>`<li>${esc(typeof x==='string'?x:(x?.[key]||x?.details||x?.item||x?.question||x?.event||''))}${x?.quote?`<blockquote>“${esc(x.quote)}”</blockquote>`:''}</li>`).join('')}</ul>`:'<div class="feature-note">None identified in the selected period.</div>';
  const dayHtml=(d.day_summaries||[]).map(x=>`<article class="summary-day"><b>${esc(x.date)}</b><p>${esc(x.summary||'')}</p>${bullets(x.key_points)}</article>`).join('');
  const dyn=d.communication_dynamics||{};
  const html=`<div class="summary-report feature-panel"><div class="feature-head"><div><span class="feature-kicker">AI CONVERSATION SUMMARY</span><h3>${esc(d.title||'Conversation Summary')}</h3><p>${esc(d.date_range?.start||'')} → ${esc(d.date_range?.end||'')} · ${Number(d.messages_selected||0).toLocaleString()} messages selected${d.limited?' · limited to the 5,000 most recent in range':''}</p></div><span class="summary-confidence">${Number(d.overall_confidence?.percent||0)}% confidence</span></div><div class="summary-executive"><b>Executive summary</b><p>${esc(d.executive_summary||'')}</p></div>${dayHtml?`<div class="summary-grid"><section class="summary-card"><h4>Day-by-day</h4>${dayHtml}</section><section class="summary-card"><h4>Main topics</h4>${bullets(d.main_topics,'topic')}<h4>Decisions</h4>${bullets(d.decisions,'decision')}</section><section class="summary-card"><h4>Plans & commitments</h4>${bullets(d.plans_and_commitments,'item')}<h4>Open questions</h4>${bullets(d.open_questions,'question')}</section><section class="summary-card"><h4>Communication dynamics</h4><p><b>Tone:</b> ${esc(dyn.tone||'Not strongly established')}</p><p><b>Engagement:</b> ${esc(dyn.engagement||'Not strongly established')}</p><p><b>Changes:</b> ${esc(dyn.changes||'No clear change identified')}</p>${dyn.evidence_quote?`<blockquote>“${esc(dyn.evidence_quote)}”</blockquote>`:''}</section></div>`:''}<div class="summary-grid"><section class="summary-card"><h4>Notable events</h4>${bullets(d.notable_events,'event')}</section><section class="summary-card"><h4>Important quotes</h4>${bullets(d.important_quotes,'why')}</section><section class="summary-card"><h4>Uncertainties</h4>${bullets(d.uncertainties)}</section><section class="summary-card"><h4>Potential next steps</h4>${bullets(d.next_steps)}</section></div><div class="feature-note">Summary scope: ${Number(d.messages_in_range||0).toLocaleString()} text messages existed in the selected range; ${Number(d.messages_selected||0).toLocaleString()} were used, across ${Number(d.batches_completed||0)}/${Number(d.batches_total||0)} AI batches. The summary describes observable conversation content and does not claim hidden motives or feelings.</div></div>`;
  upsertTab('summary','Summary',html); renderTabBar(); showTab('summary');
}

/* ---------------------------- Saved reports ------------------------------ */
function updateResultSummary(){
  const el=$('current-result-summary'); if(!el)return;
  if(!latestAnalysis){el.textContent='No analysis loaded yet.';return;}
  const type=latestAnalysis.response?'Response + Deep Analysis':'Text Analysis';
  el.textContent=`${activeChat?.display_name||activeChat?.name||activeChatId||'Conversation'} · ${type} · Ready to save`;
}
async function saveCurrentReport(){
  if(!activeChatId){alert('Choose a conversation first.');goToPage('contacts-page');return;}
  if(!latestAnalysis){alert('Run a response analysis or text analysis first.');return;}
  const defaultTitle=`${latestAnalysis.response?'Response & Deep Analysis':'Text Analysis'} — ${activeChat?.display_name||activeChat?.name||activeChatId}`;
  const title=prompt('Name this report:',defaultTitle);
  if(title===null)return;
  const btn=$('save-report-btn'); if(btn){btn.disabled=true;btn.textContent='Saving…';}
  try{
    const r=await fetch('/api/saved-reports',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:activeChatId,contact_name:activeChat?.display_name||activeChat?.name||activeChatId,report_type:latestAnalysis.response?'response_deep_analysis':'text_analysis',title:title.trim()||defaultTitle,analysis:latestAnalysis})});
    const d=await r.json(); if(!r.ok)throw Error(d.error||'Could not save report');
    await loadSavedReports(); alert('Report saved successfully.');
  }catch(e){alert(e.message)}finally{if(btn){btn.disabled=false;btn.textContent='▣ Save current result';}}
}
if($('save-report-btn')) $('save-report-btn').onclick=saveCurrentReport;
if($('refresh-reports')) $('refresh-reports').onclick=loadSavedReports;

function savedReportSummary(a){
  const deep=normalizeDeepForUI(a||{}); const overall=deep.overall||{};
  const tone=readable(a?.tone)||readable(a?.likely_attitude)||'';
  return `${overall.conclusion||tone||'Evidence-backed analysis saved for this conversation.'}`;
}
async function loadSavedReports(){
  const list=$('saved-reports-list'); if(!list)return;
  list.innerHTML='<div class="loading">Loading saved reports…</div>';
  try{
    const d=await fetch('/api/saved-reports?limit=100').then(r=>r.json()); if(d.error)throw Error(d.error);
    const items=d.items||[]; const count=$('saved-count'); if(count)count.textContent=items.length;
    if(!items.length){list.innerHTML='<div class="empty-list">No saved reports yet. Run an analysis and click “Save current result”.</div>';return;}
    list.innerHTML=items.map(x=>`<article class="saved-report" data-report-id="${esc(x.id)}"><div class="saved-report-head"><div><b>${esc(x.title)}</b><span>${esc(x.contact_name)} · ${esc(x.report_type.replace(/_/g,' '))}</span></div><span>${new Date(x.created_at).toLocaleString()}</span></div><p>${esc(savedReportSummary(x.analysis))}</p><div class="saved-report-actions"><button class="secondary open-saved" data-id="${esc(x.id)}">Open analysis</button><button class="secondary delete-saved" data-id="${esc(x.id)}">Delete</button></div></article>`).join('');
    list.querySelectorAll('.open-saved').forEach(b=>b.onclick=()=>openSavedReport(b.dataset.id));
    list.querySelectorAll('.delete-saved').forEach(b=>b.onclick=()=>deleteSavedReport(b.dataset.id));
  }catch(e){list.innerHTML=`<div class="error">${esc(e.message)}</div>`;}
}
async function openSavedReport(id){
  try{
    const r=await fetch(`/api/saved-reports/${encodeURIComponent(id)}`); const d=await r.json(); if(!r.ok)throw Error(d.error||'Could not open report');
    latestAnalysis=d.analysis||{};
    const chat={id:d.chat_id,display_name:d.contact_name}; activeChatId=d.chat_id; activeChat=chat; updateCurrentConversationHeader();
    updateResultSummary(); renderDashboard(); goToPage('deep-page'); openDeepAnalysis('overall');
  }catch(e){alert(e.message);}
}
async function deleteSavedReport(id){
  if(!confirm('Delete this saved report?'))return;
  try{const r=await fetch(`/api/saved-reports/${encodeURIComponent(id)}`,{method:'DELETE'});const d=await r.json();if(!r.ok||!d.ok)throw Error(d.error||'Could not delete report');await loadSavedReports();}catch(e){alert(e.message)}
}

const _renderDashboard=renderDashboard;
renderDashboard=function(){_renderDashboard();updateResultSummary();};
updateCurrentConversationHeader(); updateResultSummary();
const _renderDashboardFinal=renderDashboard;
renderDashboard=function(){
  _renderDashboardFinal();
  const placeholder=document.querySelector('#analysis-dashboard > .analysis-empty');
  if(placeholder) placeholder.classList.toggle('hidden',!!latestAnalysis);
  updateResultSummary();
};
/* ========================================================================
   ARY AI — standalone natural-language workspace assistant
   ======================================================================== */
const aryAiInput=$('ary-ai-input'), aryAiContext=$('ary-ai-context'), aryAiSend=$('ary-ai-send'), aryAiStop=$('ary-ai-stop'), aryAiMessages=$('ary-ai-messages'), aryAiScope=$('ary-ai-scope');
const aryAiHistoryPanel=$('ary-ai-history-panel'), aryAiHistoryList=$('ary-ai-history-list'), aryAiThreadTitle=$('ary-ai-thread-title');
let aryAiRequestId=null, aryAiAbort=null, aryAiTimerId=null, aryAiStartedAt=0, ARY_AI_GENERIC_UI_TIMEOUT_MS=185000, ARY_AI_WHATSAPP_UI_TIMEOUT_MS=298000;
// Ary AI memory now lives server-side as a real conversation thread (see
// server/db.js: ary_conversations / ary_messages). The browser only ever
// remembers WHICH conversation is open, not its content, so a reload or a
// different tab still shows the exact same persisted thread.
const ARY_AI_ACTIVE_CONVO_KEY='ary-ai-active-conversation-id';
let aryAiConversationId=null;
const ARY_AI_WELCOME_HTML='<div class="ary-ai-welcome"><div class="hero-icon">✦</div><h2>Hi, I\'m Ary AI.</h2><p>Ask me something about your conversations, contacts, messages, tone, evidence, communication patterns, or a general question.</p><div class="ary-ai-prompts"><button class="secondary ary-prompt">How many conversations do I have in my contacts?</button><button class="secondary ary-prompt">What psychological principles are relevant to this conversation?</button><button class="secondary ary-prompt">What are the strongest evidence-backed patterns in my active chat?</button></div></div>';
function aryAiMarkdown(text){
  let x=esc(String(text||''));
  x=x.replace(/^### (.+)$/gm,'<h3>$1</h3>').replace(/^## (.+)$/gm,'<h2>$1</h2>').replace(/^# (.+)$/gm,'<h1>$1</h1>');
  x=x.replace(/^> (.+)$/gm,'<blockquote>$1</blockquote>');
  x=x.replace(/`([^`]+)`/g,'<code>$1</code>');
  x=x.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>');
  x=x.replace(/^(?:[-•]) (.+)$/gm,'<li>$1</li>');
  x=x.replace(/(<li>.*<\/li>\n?)+/g,m=>`<ul>${m}</ul>`);
  return x.split(/\n{2,}/).map(part=>/^<(?:h[1-3]|ul|blockquote)/.test(part.trim())?part:`<p>${part.replace(/\n/g,'<br>')}</p>`).join('');
}
function appendAryAiMessage(role,text,extraClass=''){
  const wrap=document.createElement('div'); wrap.className=`ary-ai-msg ${role} ${extraClass}`;
  const bubble=document.createElement('div'); bubble.className='ary-ai-bubble'; bubble.innerHTML=role==='ai'?aryAiMarkdown(text):esc(text).replace(/\n/g,'<br>');
  wrap.appendChild(bubble); aryAiMessages.appendChild(wrap); aryAiMessages.scrollTop=aryAiMessages.scrollHeight;
  return wrap;
}
function setAryActiveConversation(id,title){
  aryAiConversationId=id||null;
  try{ if(id) localStorage.setItem(ARY_AI_ACTIVE_CONVO_KEY,String(id)); else localStorage.removeItem(ARY_AI_ACTIVE_CONVO_KEY); }catch(_){}
  if(aryAiThreadTitle) aryAiThreadTitle.textContent=title||'New conversation';
  document.querySelectorAll('.ary-ai-history-item').forEach(el=>el.classList.toggle('active',String(el.dataset.id)===String(id)));
}
function startNewAryChat(){
  setAryActiveConversation(null,'New conversation');
  if(aryAiMessages) aryAiMessages.innerHTML=ARY_AI_WELCOME_HTML;
  stopAryAiTimer('Ready');
  aryAiInput?.focus();
}
function aryHistoryTimeLabel(ts){
  const d=new Date(Number(ts)||0); if(!d.getTime())return '';
  const sameDay=d.toDateString()===new Date().toDateString();
  return sameDay?d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):d.toLocaleDateString([],{month:'short',day:'numeric'});
}
async function loadAryConversationList(){
  if(!aryAiHistoryList)return;
  try{
    const list=await fetch('/api/ary/conversations').then(r=>r.json());
    if(!Array.isArray(list)||!list.length){ aryAiHistoryList.innerHTML='<div class="empty-list">No conversations yet — ask Ary AI something to start one.</div>'; return; }
    aryAiHistoryList.innerHTML=list.map(c=>`<div class="ary-ai-history-item${String(c.id)===String(aryAiConversationId)?' active':''}" data-id="${c.id}"><div class="ary-ai-history-item-main"><b>${esc(c.title||'New conversation')}</b><small>${esc((c.last_message||'').slice(0,80))}</small></div><div class="ary-ai-history-item-side"><span>${aryHistoryTimeLabel(c.updated_at)}</span><button class="tiny ary-ai-history-delete" data-id="${c.id}" aria-label="Delete conversation">✕</button></div></div>`).join('');
  }catch(_){ aryAiHistoryList.innerHTML='<div class="error">Could not load past conversations.</div>'; }
}
async function openAryConversation(id){
  try{
    const r=await fetch(`/api/ary/conversations/${encodeURIComponent(id)}/messages`);
    const d=await r.json(); if(!r.ok)throw Error(d.error||'Conversation not found.');
    setAryActiveConversation(d.conversation.id,d.conversation.title);
    if(aryAiMessages){
      aryAiMessages.innerHTML='';
      const msgs=Array.isArray(d.messages)?d.messages:[];
      if(!msgs.length) aryAiMessages.innerHTML=ARY_AI_WELCOME_HTML;
      else msgs.forEach(m=>appendAryAiMessage(m.role==='assistant'?'ai':'user',m.content));
    }
    aryAiHistoryPanel?.classList.add('hidden');
  }catch(e){ appendAryAiMessage('ai',`Could not open that conversation. ${e.message||''}`,'ary-ai-error'); }
}
async function initAryConversation(){
  let savedId=null; try{ savedId=localStorage.getItem(ARY_AI_ACTIVE_CONVO_KEY); }catch(_){}
  if(savedId) await openAryConversation(savedId);
  else startNewAryChat();
}
function formatAryTimer(ms){ const sec=Math.max(0,Math.floor(ms/1000)); return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`; }
function startAryAiTimer(limitMs,isWhatsApp){
  const box=$('ary-ai-timer'), value=$('ary-ai-timer-value'), status=$('ary-ai-timer-status');
  aryAiStartedAt=Date.now(); if(aryAiTimerId)clearInterval(aryAiTimerId);
  if(box)box.classList.add('running');
  if(status)status.textContent=isWhatsApp?'WhatsApp-aware response window: up to 5 minutes':'Generic response window: up to 3 minutes';
  const tick=()=>{ const elapsed=Date.now()-aryAiStartedAt; const shown=Math.min(elapsed,limitMs); if(value)value.textContent=formatAryTimer(Math.max(0,limitMs-shown)); if(elapsed>=limitMs){ if(aryAiTimerId){clearInterval(aryAiTimerId);aryAiTimerId=null;} if(status)status.textContent='Finalizing the response…'; } };
  tick(); aryAiTimerId=setInterval(tick,250);
}
function stopAryAiTimer(label='Completed'){
  if(aryAiTimerId){clearInterval(aryAiTimerId);aryAiTimerId=null;}
  const box=$('ary-ai-timer'), value=$('ary-ai-timer-value'), status=$('ary-ai-timer-status');
  const elapsed=aryAiStartedAt?Date.now()-aryAiStartedAt:0;
  if(box)box.classList.remove('running');
  if(value)value.textContent=formatAryTimer(Math.min(elapsed,180000));
  if(status)status.textContent=`${label} · ${formatAryTimer(elapsed)}`;
  aryAiStartedAt=0;
}
async function syncAryAiLimit(){ try{ const r=await fetch('/api/status'); const s=await r.json(); if(Number(s?.ary_ai_generic_timeout_ms)>0) ARY_AI_GENERIC_UI_TIMEOUT_MS=Math.min(185000,Math.max(180000,Number(s.ary_ai_generic_timeout_ms)+5000)); if(Number(s?.ary_ai_whatsapp_timeout_ms)>0) ARY_AI_WHATSAPP_UI_TIMEOUT_MS=Math.min(300000,Number(s.ary_ai_whatsapp_timeout_ms)+5000); }catch(_){} }
function aryAiWhatsAppMode(q){ const scope=aryAiScope?.value||'workspace'; if(scope==='none')return false; if(scope==='conversation')return true; return /\b(whatsapp|my\s+(?:whatsapp|contacts?|chats?|conversations?|messages?|texts?)|this\s+(?:chat|conversation)|active\s+(?:chat|conversation)|in\s+(?:my|our)\s+(?:chat|conversation)|my\s+workspace|stored\s+messages?|contact\s+count|conversation\s+count|message\s+count|how\s+many\s+(?:contacts?|conversations?|chats?|messages?)|number\s+of\s+(?:contacts?|conversations?|chats?|messages?)|what\s+did\s+.*\s+say|messages?\s+with\s+)/i.test(String(q||'')); }
async function loadAryAiFacts(){
  try{
    const cs=await fetch('/api/chats').then(r=>r.json()); if(!Array.isArray(cs))return;
    const total=cs.reduce((n,c)=>n+Number(c.message_count||0),0); const activeRow=activeChatId?cs.find(c=>c.id===activeChatId):null;
    const cc=$('ary-ai-contact-count'), mm=$('ary-ai-message-count'), ac=$('ary-ai-active-count');
    if(cc)cc.textContent=cs.length.toLocaleString(); if(mm)mm.textContent=total.toLocaleString(); if(ac)ac.textContent=Number(activeRow?.message_count||activeChat?.message_count||0).toLocaleString();
  }catch(_){ }
}
async function askAryAi(){
  const q=aryAiInput?.value.trim(); if(!q||!aryAiSend||!aryAiMessages)return;
  const isWhatsApp=aryAiWhatsAppMode(q); appendAryAiMessage('user',q); aryAiInput.value='';
  const thinking=appendAryAiMessage('ai','Ary AI is thinking…','ary-ai-thinking');
  aryAiSend.disabled=true; aryAiStop.classList.remove('hidden'); aryAiRequestId=genRequestId(); aryAiAbort=new AbortController();
  const uiTimeout=isWhatsApp?ARY_AI_WHATSAPP_UI_TIMEOUT_MS:ARY_AI_GENERIC_UI_TIMEOUT_MS;
  startAryAiTimer(uiTimeout,isWhatsApp);
  try{
    // Memory is now the server-persisted conversation thread (conversation_id).
    // The server loads the last 12 turns for this exact thread — so switching
    // to a different past conversation or starting a new chat can never bleed
    // context between threads the way a single client-side array could.
    const signal=window.AbortSignal?.any ? AbortSignal.any([aryAiAbort.signal,AbortSignal.timeout(uiTimeout)]) : aryAiAbort.signal;
    const r=await fetch('/api/ary-ai/ask',{method:'POST',headers:{'Content-Type':'application/json','x-analysis-request-id':aryAiRequestId},body:JSON.stringify({question:q,context:aryAiContext?.value||'',chat_id:activeChatId,scope:aryAiScope?.value||'workspace',conversation_id:aryAiConversationId,request_id:aryAiRequestId}),signal});
    const d=await r.json(); if(!r.ok)throw Error(d.error||'Ary AI could not answer.');
    thinking.remove(); const answer=d.answer||'I could not produce an answer.'; appendAryAiMessage('ai',answer);
    if(d.conversation?.id){ setAryActiveConversation(d.conversation.id,d.conversation.title); loadAryConversationList(); }
    if(d.facts){const cc=$('ary-ai-contact-count'),mm=$('ary-ai-message-count'),ac=$('ary-ai-active-count');if(cc)cc.textContent=Number(d.facts.conversation_count||0).toLocaleString();if(mm)mm.textContent=Number(d.facts.total_stored_messages||0).toLocaleString();if(ac)ac.textContent=Number(d.facts.active_message_count||0).toLocaleString();}
    stopAryAiTimer('Completed');
  }catch(e){
    thinking.remove();
    if(/aborted|stopped|cancelled/i.test(e.message||'')){ stopAryAiTimer('Stopped'); }
    else { const msg=`I can still give you a general answer even without extra context. ${e.message||'The local AI service was unavailable.'}`; appendAryAiMessage('ai',msg,'ary-ai-error'); stopAryAiTimer('Recovered'); }
  }finally{aryAiSend.disabled=false;aryAiStop.classList.add('hidden');aryAiRequestId=null;aryAiAbort=null;}
}
aryAiSend?.addEventListener('click',askAryAi);
aryAiInput?.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();askAryAi();}});
aryAiStop?.addEventListener('click',async()=>{if(aryAiAbort)aryAiAbort.abort();if(aryAiRequestId){try{await fetch(`/api/cancel/${encodeURIComponent(aryAiRequestId)}`,{method:'POST'});}catch(_){}}});
$('ary-ai-new-chat')?.addEventListener('click',startNewAryChat);
$('ary-ai-history-toggle')?.addEventListener('click',()=>{aryAiHistoryPanel?.classList.toggle('hidden');if(!aryAiHistoryPanel?.classList.contains('hidden'))loadAryConversationList();});
$('ary-ai-history-close')?.addEventListener('click',()=>aryAiHistoryPanel?.classList.add('hidden'));
aryAiHistoryList?.addEventListener('click',e=>{
  const del=e.target.closest('.ary-ai-history-delete');
  if(del){ e.stopPropagation(); const id=del.dataset.id; fetch(`/api/ary/conversations/${encodeURIComponent(id)}`,{method:'DELETE'}).then(()=>{ if(String(id)===String(aryAiConversationId)) startNewAryChat(); loadAryConversationList(); }); return; }
  const item=e.target.closest('.ary-ai-history-item'); if(item) openAryConversation(item.dataset.id);
});
document.querySelectorAll('.ary-prompt').forEach(b=>b.addEventListener('click',()=>{if(aryAiInput){aryAiInput.value=b.textContent.trim();aryAiInput.focus();}}));
initAryConversation();
/* ========================================================================
   PROFESSIONAL MODE — compact <=150-word corporate communication review
   ======================================================================== */
const corporateText=$('corporate-text'), corporateRun=$('corporate-run'), corporateStop=$('corporate-stop'), corporateResult=$('corporate-result'), corporateWordCount=$('corporate-word-count'), corporateWordWarning=$('corporate-word-warning'), corporateTimer=$('corporate-timer');
let corporateRequestId=null, corporateAbort=null, corporateTimerHandle=null, corporateStarted=0;
function corporateWords(){return String(corporateText?.value||'').trim().split(/\s+/).filter(Boolean);} 
function updateCorporateCount(){const n=corporateWords().length;if(corporateWordCount)corporateWordCount.textContent=`${n} / 150 words`;if(corporateWordWarning)corporateWordWarning.textContent=n>150?'Too long — shorten to 150 words or fewer.':'';if(corporateRun)corporateRun.disabled=!n||n>150;}
function corporateStopTimer(text){if(corporateTimerHandle){clearInterval(corporateTimerHandle);corporateTimerHandle=null;}if(corporateTimer)corporateTimer.textContent=text||'Target: under 1 minute';}
function corporateStartTimer(){corporateStarted=Date.now();corporateStopTimer('Running: 00:00 elapsed · under 1 minute target');corporateTimerHandle=setInterval(()=>{const e=Date.now()-corporateStarted;corporateTimer.textContent=`Running: ${formatTimer(e)} elapsed · under 1 minute target`;},250);}
function corporateResultHtml(d){const score=(v)=>Number.isFinite(Number(v))?Math.max(0,Math.min(100,Number(v))):0;const evidence=(d.evidence||[]).slice(0,6).map(x=>`<div class="corporate-evidence"><blockquote>${esc(x.quote||'')}</blockquote><b>${esc(x.finding||'')}</b><p>${esc(x.why||'')}</p><small>Confidence ${score(x.confidence)}%</small></div>`).join('');const patterns=(d.language_patterns||[]).slice(0,8).map(x=>`<div class="corporate-pattern"><b>${esc(x.pattern||'')}</b>${x.quote?`<blockquote>${esc(x.quote)}</blockquote>`:''}<p>${esc(x.explanation||'')}</p></div>`).join('');const risks=(d.risks||[]).slice(0,6).map(x=>`<div class="corporate-risk"><b>${esc((x.level||'').toUpperCase())}</b> ${esc(x.issue||'')} ${x.quote?`<blockquote>${esc(x.quote)}</blockquote>`:''}<p>${esc(x.reason||'')}</p></div>`).join('');const principles=(d.principles||[]).slice(0,8).map(x=>`<div class="corporate-principle"><b>${esc(x.name||'')}</b><p>${esc(x.explanation||'')}</p>${x.quote?`<blockquote>${esc(x.quote)}</blockquote>`:''}</div>`).join('');const alt=d.alternatives||{};return `<div class="corporate-summary"><h3>Overall interpretation</h3><p>${esc(d.overall||'')}</p><h3>How it may come across</h3><p>${esc(d.recipient_perception||'')}</p><div class="corporate-score-grid">${[['Professionalism',d.scores?.professionalism],['Clarity',d.scores?.clarity],['Assertiveness',d.scores?.assertiveness],['Diplomacy',d.scores?.diplomacy],['Collaboration',d.scores?.collaboration],['Corporate risk',100-score(d.scores?.corporate_risk)]].map(([k,v])=>`<div><b>${score(v)}</b><span>${k}</span></div>`).join('')}</div><h3>Evidence</h3>${evidence||'<p>No strong evidence item was necessary.</p>'}<h3>Corporate language</h3>${patterns||'<p>No notable corporate-language pattern detected.</p>'}<h3>Communication principles</h3>${principles||'<p>No specific principle was strong enough to report.</p>'}<h3>Potential risks</h3>${risks||'<p>No material communication risk detected.</p>'}<h3>What I would change</h3><ul>${(d.recommended_changes||[]).slice(0,6).map(x=>`<li>${esc(x)}</li>`).join('')}</ul><h3>Professional rewrite</h3><div class="corporate-rewrite">${esc(d.rewrite||'')}</div><h3>Alternative versions</h3><div class="corporate-alts"><div><b>Executive</b><p>${esc(alt.executive||'')}</p></div><div><b>Diplomatic</b><p>${esc(alt.diplomatic||'')}</p></div><div><b>Assertive</b><p>${esc(alt.assertive||'')}</p></div><div><b>Concise</b><p>${esc(alt.concise||'')}</p></div></div><h3>Confidence & limitations</h3><p>Confidence: ${score(d.confidence)}%</p><ul>${(d.limitations||[]).slice(0,5).map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`;}
async function runCorporate(){const text=String(corporateText?.value||'').trim(), words=corporateWords();if(!text||words.length>150)return;corporateRequestId=genRequestId();corporateAbort=new AbortController();corporateRun.disabled=true;corporateStop.classList.remove('hidden');corporateResult.innerHTML='<div class="corporate-empty">Ary AI is analyzing the communication…</div>';corporateStartTimer();try{const r=await fetch('/api/corporate/analyze',{method:'POST',headers:{'Content-Type':'application/json','x-analysis-request-id':corporateRequestId},body:JSON.stringify({text,recipient:$('corporate-recipient')?.value||'Unknown',objective:$('corporate-objective')?.value||'Sound more professional',request_id:corporateRequestId}),signal:(window.AbortSignal?.any?AbortSignal.any([corporateAbort.signal,AbortSignal.timeout(52000)]):corporateAbort.signal)});const d=await r.json();if(!r.ok)throw Error(d.error||'Professional analysis failed.');corporateResult.innerHTML=corporateResultHtml(d);if(d.fallback)corporateResult.insertAdjacentHTML('afterbegin','<div class="corporate-fallback-note">⚡ Ollama took too long, so Professional Mode automatically used its local evidence engine instead of showing a timeout error.</div>');corporateStopTimer(`Completed in ${formatTimer(Date.now()-corporateStarted)} · target under 1 minute`);}catch(e){corporateResult.innerHTML=`<div class="corporate-error">${esc(e.message||'Professional analysis could not be completed.')}</div>`;corporateStopTimer('Analysis stopped or failed');}finally{corporateRun.disabled=false;corporateStop.classList.add('hidden');corporateRequestId=null;corporateAbort=null;}}
corporateText?.addEventListener('input',updateCorporateCount);corporateRun?.addEventListener('click',runCorporate);corporateStop?.addEventListener('click',async()=>{if(corporateAbort)corporateAbort.abort();if(corporateRequestId){try{await fetch(`/api/cancel/${encodeURIComponent(corporateRequestId)}`,{method:'POST'});}catch(_){}}});updateCorporateCount();
const _goToPageAry=goToPage;
goToPage=function(pageId){_goToPageAry(pageId);if(pageId==='ary-ai-page'){syncAryAiLimit();loadAryAiFacts();}};
