# Ary AI 8.4 — Counterfactual Conversation Simulator

This build includes the 5,000-message analysis cap plus Baseline + Change Detection, Evidence Explorer and Conversation Timeline visualizations.

# Confidential Algorithm 6.4

Laptop-friendly WhatsApp analysis and response assistant using Ollama `llama3.2` (3B-class).

## Accuracy architecture
- Recency-weighted 20-dimensional tone vectors at message level.
- Contact-specific communication baseline.
- Contrastive tone reasoning before selecting the primary tone.
- Strict evidence verification: displayed quotes must occur in the supplied conversation text.
- Every Deep Analysis evidence item includes a psychological/communication principle when applicable, plus justification and counter-evidence when available.
- Confidence is recalibrated from verified evidence, context depth, and contradictions rather than trusting a raw model percentage.
- User feedback is stored locally and supplied as future correction context.
- Response generation asks for multiple candidates and ranks them for instruction fit, tone, naturalness and unsupported-fact risk.

## Model
The launcher explicitly uses `llama3.2` for laptop-friendly local inference. It does not automatically switch to `llama3.1`.


## 7.7 visual + date-range update
- Relationship Mode frontend repaired and made responsive.
- Relationship/20-tone pie colors and legend rendering repaired.
- Relationship conversation picker now clearly shows 1/2 selected conversations.
- Full Conversation now supports inclusive Start date → End date selection while retaining Select all and manual checkboxes.
- Browser asset cache versions updated so the current frontend actually loads.

## Relationship Mode 7.6
This build adds a separate Relationship Mode for up to two chosen conversations, a user-stated objective, three relationship situations, relationship-specific psychology, indirect evidence, and a 20-tone relationship distribution. Every stored message in the selected conversations is processed through bounded chronological AI batches.

## 7.8 Analysis limits
Deep and Relationship Analysis are capped at 5,000 messages. Select All uses the 5,000 most recent messages; date-range selection uses the 5,000 most recent messages within the chosen range. The Ollama safety ceiling is 15 minutes, with 45-second batch calls and 30-second compact retries.

## 8.0 — Contacts grid + WhatsApp names
My Contacts now uses a compact full-width header and a responsive 3/2/1-column contact grid. The app also prefers WhatsApp-provided contact names and push/profile names when Baileys supplies them, while preserving local renames as the highest-priority display name.


## 8.2 Conversation Summary
The Full Conversation page now includes **AI Summary**. Choose an inclusive date range of up to **2 calendar days**; if the range contains more than 5,000 text messages, the newest 5,000 in that range are summarized. The result includes an executive summary, day-by-day breakdown, topics, decisions, plans/commitments, open questions, notable events, communication dynamics, important quotes, uncertainties and next steps. It uses local Ollama/Llama 3.2 and the same bounded, cancellable AI pipeline.


## 8.3 — Counterfactual Simulator + message-based workload
- Added a Counterfactual Conversation Simulator to Deep Analysis.
- Choose a real message, replace it with a hypothetical version, optionally state an objective, and receive multiple plausible downstream branches with verified real-message evidence, uncertainty, decision guidance, and alternative hypotheticals.
- Simulation is explicitly probabilistic and does not claim access to private thoughts or guaranteed future responses.
- Analysis workload is now explicitly message/text-count based: the hard ceiling is 5,000 selected messages, and batching targets a fixed number of messages. Character count remains only as a model-context safety guard and never silently removes messages.

- Message-count clarification: the 5,000 ceiling and primary batch sizing use messages/texts as the workload unit. Word counts remain descriptive statistics only. Character limits are context-safety guards, not selection quotas.


## Ary AI 8.7 — Fast Generic Assistant
Ary AI now behaves as a general-purpose local AI assistant first. Users can optionally provide their own context, then ask any normal question. WhatsApp workspace data is attached only when the question clearly requires it, preventing giant transcript prompts and improving reliability. Ary AI uses a bounded ~52-second Ollama generation window and a ~58-second browser request window, with a Stop button.


## 8.10 — Fast generic Ary AI
Generic Ary AI uses llama3.2 with a compact context and bounded generation budget. It now has a 3-minute response window, expanded rolling conversation memory, a live timer, automatic compact recovery, and a deterministic local fallback. WhatsApp-specific Ary AI continues using llama3.2 with the five-minute window.


## 8.10 — Fast Generic Ary AI
Generic Ary AI uses llama3.2 with a compact 1536-token context and bounded generation budget. Generic questions bypass WhatsApp/database retrieval entirely unless WhatsApp data is explicitly requested. The generic path has a 3-minute total response window with compact recovery and a deterministic fallback; WhatsApp-specific Ary AI continues to use llama3.2 with the five-minute budget. This build uses port 3011 to prevent an older 3010 server from being accidentally reused.


## Ary AI 8.11 — generic response database fix
Generic Ary AI questions do not belong to a WhatsApp chat, so they are no longer written to the chat-bound `analysis_records` table. A successful Ary AI answer is now returned even if optional history logging fails. WhatsApp-grounded Ary AI answers with a real chat id can still be recorded.


## 8.12 Professional Mode
- Added a separate Professional Mode tab for corporate/workplace communication.
- Accepts up to 150 words and analyzes professionalism, clarity, assertiveness, diplomacy, collaboration, recipient perception, corporate language, risks, relevant communication principles, evidence, and rewrites.
- Runs as one compact local Ary AI request with a target of under one minute; it does not retrieve WhatsApp data.


## Ary AI 8.20 — Memory + 3-minute response window
Ary AI now persists up to 30 recent messages locally, sends up to 12 prior messages as working memory, and shows a live response timer. Generic Ary AI has a 3-minute total window with a 160-second primary generation budget, a 20-second compact recovery attempt, and a deterministic fallback so missing context or Ollama timeouts do not produce a useless refusal/error. The default model remains llama3.2.
