# Confidential Algorithm 6.1 — Deep Analysis + 20-Tone Update

## What changed

- Reworked the right-hand intelligence panel to match the supplied bright dashboard reference.
- Added exactly **8 Deep Analysis categories**:
  1. Overall Interpretation
  2. Likely Attitude
  3. Sarcasm & Humour
  4. Psychology / Communication
  5. Risks
  6. Evidence
  7. Strategy
  8. Alternatives
- The overview shows the eight categories as clickable cards.
- Clicking **Open Deep Analysis** or any card switches the same page into a dedicated tabbed analysis view. Browser URL state uses a hash, so the page does not navigate away from the current app.
- Every deep-analysis conclusion now requests a direct verbatim evidence excerpt plus a justification explaining why that excerpt supports the conclusion.
- Evidence quotes are checked against the actual conversation text. Unsupported model-generated quotes are discarded/repaired only when a relevant real message can be found; unsupported confidence is capped.
- Added **20 distinct tone options** and an explicit model instruction not to use Neutral / matter-of-fact when stronger evidence exists.
- Added a visible tone selector to Response Copilot.
- Conversation statistics now use the same 20-tone taxonomy instead of a seven-label neutral-heavy classifier.
- Added message-selection checkboxes so Analyze + Generate can prioritize the exact selected messages shown in the UI.
- Added an inline AI response preview before sending.
- Existing rename/delete, WhatsApp sync, Ollama, reports, feedback, and cancellation flows remain in place.

## 20 tones

Warm; Affectionate; Friendly; Playful; Humorous; Sarcastic; Flirty; Casual; Curious; Enthusiastic; Excited; Confident; Direct; Professional; Formal; Serious; Reassuring; Concerned; Frustrated; Neutral / matter-of-fact.

## Evidence behavior

The analysis is deliberately evidence-first. A confidence percentage without a verified conversation excerpt is capped to prevent a high-looking percentage from being presented as well-supported. This is still an AI interpretation of language, not proof of a person's internal mental state.


## Accuracy tuning (6.1)
- Uses llama3.2 by default when no OLLAMA_MODEL override is supplied.
- Adds a deterministic text-signal pass as an AI guardrail rather than treating Neutral as a safe default.
- The model analyzes the latest meaningful message first and uses preceding messages for ambiguity resolution.
- Exact evidence quotes are required; unsupported quotes are no longer replaced with merely similar messages.
- Main analysis uses lower generation temperature and a larger structured-output budget/context window.
- A neutral result is only corrected when the latest message contains a strong observable marker; nuanced non-neutral model decisions are left untouched.


## Accuracy-tuned 6.4 additions
- Message-level recency weighting (latest message carries the strongest influence).
- Contact-specific baseline for comparing current communication with the contact’s own normal style.
- Contrastive interpretation: up to three candidate tones are compared before selection.
- Confidence calibration uses verified evidence, context depth and counter-evidence.
- Deep Analysis evidence includes the psychological/communication principle used and a justification.
- Counter-evidence and alternative interpretations are preserved.
- User feedback becomes future correction context.
- Llama 3.2 remains the default local model for laptop-friendly inference.
