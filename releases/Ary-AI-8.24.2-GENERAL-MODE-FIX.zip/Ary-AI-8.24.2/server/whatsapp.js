// whatsapp.js — browser-free WhatsApp transport using Baileys.
//
// This deliberately does NOT use whatsapp-web.js/Puppeteer/Chromium.
// The repeated "Execution context was destroyed" and "Attempted to use
// detached Frame" failures come from a browser execution context being
// replaced underneath Puppeteer. A WebSocket transport removes that entire
// failure class instead of trying to catch it after the fact.

const path = require('path');
const fs = require('fs');
const EventEmitter = require('events');
const QRCode = require('qrcode');
const pino = require('pino');
// Baileys v7 is ESM-only. Keep the rest of this Windows app CommonJS and
// load Baileys with one dynamic import. This also avoids npm's old git-based
// libsignal dependency used by the legacy 6.x line.
let makeWASocket;
let useMultiFileAuthState;
let DisconnectReason;
let Browsers;
let baileysLoadPromise = null;

async function loadBaileys() {
  if (!baileysLoadPromise) {
    baileysLoadPromise = import('@whiskeysockets/baileys').then(mod => {
      makeWASocket = mod.default;
      useMultiFileAuthState = mod.useMultiFileAuthState;
      DisconnectReason = mod.DisconnectReason;
      Browsers = mod.Browsers;
      if (typeof makeWASocket !== 'function') throw new Error('Baileys failed to expose its default socket factory.');
      return mod;
    });
  }
  return baileysLoadPromise;
}

const {
  upsertChat,
  insertMessage,
  upsertContact,
  isInitialSyncComplete,
  setInitialSyncComplete,
  setSyncMeta,
  getSyncMeta,
} = require('./db');

const liveEvents = new EventEmitter();
const DATA_DIR = path.join(__dirname, '..', 'data');
const AUTH_DIR = path.join(DATA_DIR, 'baileys_auth');
fs.mkdirSync(AUTH_DIR, { recursive: true });

const logger = pino({ level: process.env.WA_LOG_LEVEL || 'warn' });

let sock = null;
let status = 'starting';
let latestQrDataUrl = null;
let lastSyncAt = null;
let lastSyncError = null;
let reconnectTimer = null;
let connectInFlight = false;
let syncRunning = false;
let syncStartedAt = null;
let syncProgress = 0;
let syncMessages = 0;
let syncChats = 0;
let syncContacts = 0;
let syncDetail = 'Waiting for WhatsApp history sync…';
let historyBatches = 0;
let connectionStartedAt = 0;
let qrSeenThisAttempt = false;
let connectionWatchdog = null;
let reconnectAttempts = 0;
let freshLoginResetInProgress = false;

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function clearConnectionWatchdog() {
  if (connectionWatchdog) { clearTimeout(connectionWatchdog); connectionWatchdog = null; }
}

async function closeSocket() {
  try {
    if (sock?.ws?.close) sock.ws.close();
    else if (sock?.end) sock.end(undefined);
  } catch (_) {}
  sock = null;
}

async function resetAuthState(reason = 'fresh QR requested') {
  if (freshLoginResetInProgress) return;
  freshLoginResetInProgress = true;
  clearConnectionWatchdog();
  latestQrDataUrl = null;
  status = 'starting';
  lastSyncError = null;
  syncDetail = `Resetting the WhatsApp login session (${reason})…`;
  connectInFlight = false;
  try {
    await closeSocket();
    await fs.promises.rm(AUTH_DIR, { recursive: true, force: true });
    await fs.promises.mkdir(AUTH_DIR, { recursive: true });
    console.log(`WhatsApp auth state reset: ${reason}`);
  } finally {
    freshLoginResetInProgress = false;
  }
}

function armConnectionWatchdog(attemptRegistered) {
  clearConnectionWatchdog();
  const timeout = attemptRegistered ? 90_000 : 60_000;
  connectionWatchdog = setTimeout(async () => {
    connectionWatchdog = null;
    if (status === 'ready' || !connectInFlight) return;
    console.warn(`WhatsApp connection watchdog fired after ${Math.round(timeout/1000)}s (registered=${attemptRegistered}, qr=${!!latestQrDataUrl}).`);
    if (attemptRegistered) {
      await resetAuthState('connection did not complete after the previous login');
    } else {
      await closeSocket();
      connectInFlight = false;
      status = 'reconnecting';
      syncDetail = 'QR generation timed out. Restarting the WhatsApp connection…';
    }
    scheduleReconnect(1000);
  }, timeout);
}

function jidFromKey(key) {
  return key?.remoteJid || key?.participant || null;
}

function timestampMs(value) {
  if (value == null) return Date.now();
  if (typeof value === 'object' && typeof value.toNumber === 'function') return value.toNumber() * 1000;
  const n = Number(value);
  return n > 1e12 ? n : n * 1000;
}

function textFromMessage(message, depth = 0) {
  if (!message || depth > 4) return '';
  // WhatsApp frequently wraps ordinary text in ephemeral/view-once/edit
  // containers during history sync. Unwrap those first so the conversation
  // viewer receives the real text instead of an empty placeholder.
  const wrapped = message.ephemeralMessage?.message ||
    message.viewOnceMessage?.message ||
    message.viewOnceMessageV2?.message ||
    message.viewOnceMessageV2Extension?.message ||
    message.documentWithCaptionMessage?.message ||
    message.editedMessage?.message ||
    message.protocolMessage?.editedMessage?.message;
  if (wrapped) {
    const nested = textFromMessage(wrapped, depth + 1);
    if (nested) return nested;
  }
  return message.conversation ||
    message.extendedTextMessage?.text ||
    message.imageMessage?.caption ||
    message.videoMessage?.caption ||
    message.documentMessage?.caption ||
    message.audioMessage?.caption ||
    message.buttonsResponseMessage?.selectedDisplayText ||
    message.listResponseMessage?.title ||
    message.templateButtonReplyMessage?.selectedDisplayText ||
    message.contactMessage?.displayName ||
    message.locationMessage?.name ||
    message.pollCreationMessage?.name ||
    message.pollCreationMessageV3?.name ||
    (message.reactionMessage ? `Reaction: ${message.reactionMessage.text || ''}` : '') ||
    '';
}

function chatName(jid, fallback = '') {
  if (fallback) return fallback;
  if (!jid) return '';
  return jid.endsWith('@g.us') ? jid.replace('@g.us', '') : jid.replace('@s.whatsapp.net', '');
}

function persistBaileysMessage(message) {
  const key = message?.key;
  const chatId = jidFromKey(key);
  if (!chatId || chatId === 'status@broadcast' || !key?.id) return false;

  const body = textFromMessage(message.message);
  const row = {
    id: key.id,
    chat_id: chatId,
    sender: key.fromMe ? 'me' : (key.participant || key.remoteJid || ''),
    from_me: key.fromMe ? 1 : 0,
    body,
    timestamp: timestampMs(message.messageTimestamp),
  };

  upsertChat({
    id: chatId,
    name: chatName(chatId),
    is_group: chatId.endsWith('@g.us') ? 1 : 0,
    last_message_at: row.timestamp,
  });

  // WhatsApp often includes the sender's profile/push name on incoming direct
  // messages even when the address-book name is not available through Baileys.
  // Keep it as a best-effort fallback; a user-set local custom_name still wins.
  if (!key.fromMe && !chatId.endsWith('@g.us') && message?.pushName) {
    upsertContact({
      id: chatId,
      name: '',
      pushname: String(message.pushName || '').trim(),
      phone: chatId.endsWith('@s.whatsapp.net') ? chatId.split('@')[0] : '',
    });
  }
  insertMessage(row);
  liveEvents.emit('message', row);
  return true;
}

function persistChat(chat) {
  const id = chat?.id;
  if (!id || id === 'status@broadcast') return;
  upsertChat({
    id,
    name: chat.name || chat.subject || chatName(id),
    is_group: id.endsWith('@g.us') ? 1 : 0,
    last_message_at: timestampMs(chat.conversationTimestamp || chat.lastMessageRecvTimestamp || 0),
  });
}

function persistContact(contact) {
  const id = contact?.id;
  if (!id || id === 'status@broadcast') return;
  upsertContact({
    id,
    name: contact.name || contact.verifiedName || '',
    pushname: contact.notify || contact.pushName || '',
    phone: id.endsWith('@s.whatsapp.net') ? id.split('@')[0] : '',
  });
}

function processHistorySet(data) {
  const chats = data?.chats || [];
  const contacts = data?.contacts || [];
  const messages = data?.messages || [];

  syncRunning = true;
  if (!syncStartedAt) syncStartedAt = Date.now();
  historyBatches += 1;

  for (const chat of chats) persistChat(chat);
  for (const contact of contacts) persistContact(contact);
  for (const message of messages) persistBaileysMessage(message);

  syncChats += chats.length;
  syncContacts += contacts.length;
  syncMessages += messages.length;
  syncProgress = Number(data?.progress || 0);
  syncDetail = `WhatsApp history batch ${historyBatches}: ${messages.length.toLocaleString()} messages received${data?.isLatest ? ' — latest history reached' : ''}.`;
  lastSyncAt = Date.now();

  if (data?.isLatest || syncProgress >= 100) {
    syncRunning = false;
    setInitialSyncComplete(true);
    setSyncMeta('last_history_sync_at', String(Date.now()));
    syncDetail = `History sync complete. ${syncMessages.toLocaleString()} messages received across ${syncChats.toLocaleString()} chat records.`;
  }
}

async function connect() {
  if (connectInFlight || freshLoginResetInProgress) return;
  await loadBaileys();
  connectInFlight = true;
  connectionStartedAt = Date.now();
  qrSeenThisAttempt = false;
  latestQrDataUrl = null;
  status = 'starting';
  lastSyncError = null;

  try {
    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
    armConnectionWatchdog(!!state.creds.registered);

    sock = makeWASocket({
      auth: state,
      browser: Browsers.macOS('Ary AI'),
      printQRInTerminal: false,
      syncFullHistory: true,
      markOnlineOnConnect: false,
      fireInitQueries: true,
      emitOwnEvents: true,
      logger,
      connectTimeoutMs: 60_000,
      keepAliveIntervalMs: 30_000,
      defaultQueryTimeoutMs: 60_000,
      retryRequestDelayMs: 500,
      maxMsgRetryCount: 5,
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async update => {
      const { connection, lastDisconnect, qr } = update;

      if (qr) {
        qrSeenThisAttempt = true;
        status = 'qr';
        try {
          latestQrDataUrl = await QRCode.toDataURL(qr, { margin: 2, width: 360, errorCorrectionLevel: 'M' });
        } catch (qrError) {
          latestQrDataUrl = null;
          lastSyncError = `QR rendering failed: ${qrError?.message || qrError}`;
          syncDetail = 'WhatsApp produced a QR, but the browser could not render it. Retrying…';
          console.error('QR rendering error:', lastSyncError);
        }
        if (latestQrDataUrl) syncDetail = 'Scan the QR code from WhatsApp → Linked Devices. History will sync automatically after connection.';
        console.log('WhatsApp QR ready. Scan it from WhatsApp > Linked Devices.');
      }

      if (connection === 'open') {
        clearConnectionWatchdog();
        reconnectAttempts = 0;
        status = 'ready';
        latestQrDataUrl = null;
        connectInFlight = false;
        syncRunning = !isInitialSyncComplete();
        syncStartedAt = syncStartedAt || Date.now();
        syncDetail = isInitialSyncComplete()
          ? 'Connected. Waiting for incremental history updates.'
          : 'Connected. WhatsApp is delivering the initial history in background batches.';
        console.log('WhatsApp connected using browser-free WebSocket transport.');
      }

      if (connection === 'close') {
        clearConnectionWatchdog();
        const code = lastDisconnect?.error?.output?.statusCode;
        const loggedOut = code === DisconnectReason.loggedOut;
        status = loggedOut ? 'disconnected' : 'reconnecting';
        connectInFlight = false;
        latestQrDataUrl = null;
        if (!loggedOut) {
          const reason = lastDisconnect?.error?.message || `disconnect code ${code ?? 'unknown'}`;
          lastSyncError = reason;
          syncDetail = `WhatsApp disconnected (${reason}). Reconnecting automatically…`;
          scheduleReconnect(1500);
        }
        else {
          latestQrDataUrl = null;
          lastSyncError = 'WhatsApp logged out. Scan the new QR code to reconnect.';
          console.error('WhatsApp logged out. A new QR scan is required.');
        }
      }
    });

    sock.ev.on('messaging-history.set', data => {
      try { processHistorySet(data); }
      catch (err) {
        lastSyncError = err?.message || String(err);
        syncDetail = `History batch could not be stored: ${lastSyncError}. Waiting for the next batch.`;
        console.error('History batch error:', lastSyncError);
      }
    });

    sock.ev.on('chats.upsert', chats => {
      for (const chat of chats || []) persistChat(chat);
    });

    sock.ev.on('contacts.upsert', contacts => {
      for (const contact of contacts || []) persistContact(contact);
    });

    // Baileys can deliver later name/profile changes separately from the first
    // contact upsert. Persist those too so the Contacts page improves over time.
    sock.ev.on('contacts.update', contacts => {
      for (const contact of contacts || []) persistContact(contact);
    });

    sock.ev.on('messages.upsert', ({ messages, type }) => {
      if (type !== 'notify') return;
      for (const message of messages || []) {
        try { persistBaileysMessage(message); }
        catch (err) { console.error('Failed to store live message:', err?.message || err); }
      }
    });

    // If the account is already authenticated, there may be no QR and the
    // initial history will arrive asynchronously through messaging-history.set.
    if (state.creds.registered) {
      syncDetail = isInitialSyncComplete()
        ? 'Authenticated. Waiting for incremental updates.'
        : 'Authenticated. Requesting full history from WhatsApp…';
    }
  } catch (err) {
    clearConnectionWatchdog();
    connectInFlight = false;
    status = 'disconnected';
    lastSyncError = err?.message || String(err);
    syncDetail = `Connection failed: ${lastSyncError}. Retrying automatically.`;
    console.error('WhatsApp connection failed:', lastSyncError);
    scheduleReconnect();
  }
}

function scheduleReconnect(delay = 5000) {
  if (reconnectTimer || freshLoginResetInProgress) return;
  reconnectAttempts += 1;
  reconnectTimer = setTimeout(async () => {
    reconnectTimer = null;
    await closeSocket();
    await connect();
  }, delay);
}

function init() {
  if (status === 'ready' || connectInFlight) return;
  connect().catch(err => console.error('WhatsApp init error:', err?.message || err));
}

async function forceNewQr() {
  await resetAuthState('user requested a new QR code');
  scheduleReconnect(250);
  return { ok: true };
}

async function sendMessage(chatId, text) {
  if (!sock || status !== 'ready') throw new Error(`WhatsApp is not ready (status: ${status}).`);
  if (!chatId || !String(text || '').trim()) throw new Error('A chat ID and non-empty message are required.');
  return sock.sendMessage(chatId, { text: String(text).trim() });
}

async function syncAll() {
  if (status !== 'ready') throw new Error(`WhatsApp is not ready (status: ${status}).`);
  // Full history is delivered by WhatsApp after login. There is intentionally
  // no browser-side "scan every chat" loop anymore. This endpoint simply
  // exposes the current asynchronous sync state and keeps the UI responsive.
  syncRunning = true;
  syncStartedAt = syncStartedAt || Date.now();
  syncDetail = isInitialSyncComplete()
    ? 'Incremental synchronization is handled automatically by the WhatsApp socket.'
    : 'Initial synchronization is running in background history batches. You can leave Ary AI open.';
  return { accepted: true, ...getStatus().sync };
}

function getStatus() {
  return {
    status,
    qr: latestQrDataUrl,
    transport: 'baileys-websocket',
    sync: {
      running: syncRunning,
      lastSyncAt,
      lastError: lastSyncError,
      chats: syncChats,
      messages: syncMessages,
      contacts: syncContacts,
      phase: syncRunning ? 'syncing' : (status === 'ready' ? 'complete' : 'waiting'),
      mode: isInitialSyncComplete() ? 'incremental' : 'initial',
      startedAt: syncStartedAt,
      elapsedMs: syncStartedAt ? Date.now() - syncStartedAt : 0,
      progress: syncProgress,
      totalChats: syncChats,
      completedChats: syncProgress >= 100 ? syncChats : 0,
      skippedChats: 0,
      currentChat: 'WhatsApp history stream',
      currentChatIndex: 0,
      currentChatMessages: syncMessages,
      detail: syncDetail,
      historyBatches,
      initialComplete: isInitialSyncComplete(),
      lastHistorySyncAt: getSyncMeta('last_history_sync_at', null),
      browserFree: true,
    }
  };
}

setInterval(() => {
  if (status === 'ready' && !syncRunning && !isInitialSyncComplete()) {
    syncRunning = true;
    syncDetail = 'Waiting for the next WhatsApp history batch…';
  }
}, 30_000).unref?.();

module.exports = { init, getStatus, sendMessage, syncAll, liveEvents, forceNewQr };
