// stats.js — transparent, recency-weighted conversation statistics.
// These are observable text signals, not measurements of a person's mental state.
const { getMessages, listChats } = require('./db');
const LABELS=['Warm','Affectionate','Friendly','Playful','Humorous','Sarcastic','Flirty','Casual','Curious','Enthusiastic','Excited','Confident','Direct','Professional','Formal','Serious','Reassuring','Concerned','Frustrated','Neutral / matter-of-fact'];
const IDS=['warm','affectionate','friendly','playful','humorous','sarcastic','flirty','casual','curious','enthusiastic','excited','confident','direct','professional','formal','serious','reassuring','concerned','frustrated','neutral'];
const clamp=(n,a=0,b=100)=>Math.max(a,Math.min(b,n));
function toneScores(body=''){
  const t=String(body||''),low=t.toLowerCase(),s=Object.fromEntries(IDS.map(x=>[x,0]));
  const add=(id,n)=>s[id]=clamp(s[id]+n);
  const q=(t.match(/\?/g)||[]).length;
  const laugh=/(\blol\b|\blmao\b|\bhaha+\b|😂|🤣|😭|💀|\brofl\b)/i.test(t);
  if(/❤️|❤|🥰|😍|😘|love you|miss you|proud of you|take care|xoxo/i.test(t))add('affectionate',72);
  if(/thanks|thank you|appreciate|glad to hear|good to hear|😊|🙂|🤝/i.test(t))add('warm',58);
  if(/\bhey|\bhi|how are you|sounds good|sure|cool|nice|thanks/i.test(t))add('friendly',48);
  if(/tease|kidding|joking|😉|😜|😏|😂|🤣/i.test(t))add('playful',65);
  if(laugh)add('humorous',78);
  if(/yeah right|sure\.\.\.|great\.\.\.|wow\.\.\.|obviously|as if|nice one|thanks for nothing|love that for you|of course you did/i.test(low)||(/\b(sure|great|amazing|perfect)\b/i.test(t)&&/🙄|😒|🙂/.test(t)))add('sarcastic',82);
  if(/😉|😏|😜|😘|cute|hot|date me|miss me\?|you look/i.test(t))add('flirty',76);
  if(/\b(lol|haha|sure|okay|ok|yeah|yep|nah|btw|idk|gonna|wanna)\b/i.test(t)&&t.length<220)add('casual',52);
  if(q||/\b(why|how|what|when|where|which|curious)\b/i.test(t))add('curious',62);
  if(/!{2,}|can't wait|so excited|amazing|awesome|let's go|yay|woo+|🎉|🥳|🤩/i.test(t))add('enthusiastic',72);
  if(/!!!|can't wait|so excited|finally|omg|oh my god|let's go|🎉|🥳|🤩/i.test(t))add('excited',80);
  if(/\b(i know|i'll|i can|definitely|absolutely|we should|do this|i'm sure)\b/i.test(t)&&q===0)add('confident',60);
  if(/^(please )?(send|tell|let|give|do|stop|call|come|check|confirm|use|choose|answer)\b/i.test(low)||/\b(can you|please)\b/i.test(low))add('direct',66);
  if(/meeting|project|work|client|deadline|schedule|report|team|office|regards|available at|invoice|proposal/i.test(low))add('professional',58);
  if(/dear |kindly |sincerely|would you be so kind|i would like to|please note|furthermore|therefore/i.test(low))add('formal',78);
  if(/important|need to talk|seriously|deadline|urgent|problem|issue|apolog|sorry|decision|safety/i.test(low))add('serious',70);
  if(/don't worry|no worries|it's okay|you'll be fine|i've got you|we can handle|all good|we're okay/i.test(t))add('reassuring',75);
  if(/worried|concerned|careful|be careful|are you okay|hope you're okay|risk|danger|concern/i.test(low))add('concerned',74);
  if(/annoyed|annoying|whatever|seriously|ffs|wtf|ugh|stop|not again|leave it|forget it|frustrat|why would you/i.test(low))add('frustrated',80);
  if(!Object.entries(s).some(([k,v])=>k!=='neutral'&&v>0))add('neutral',72);
  if(/meeting|project|work|client|deadline/i.test(low)&&!/(dear|kindly|sincerely)/i.test(low))s.professional=Math.min(s.professional,62);
  if(s.sarcastic){s.friendly=Math.min(s.friendly,35);s.enthusiastic=Math.min(s.enthusiastic,45);}
  return s;
}
function weightedToneScores(messages=[]){
  const totals=Object.fromEntries(IDS.map(x=>[x,0]));
  const rows=messages.map((m,i)=>{const age=messages.length-1-i;const w=age===0?.45:age===1?.20:age===2?.12:age===3?.08:.15/Math.max(1,messages.length-4);return {message:m,weight:w,scores:toneScores(m.body)};});
  for(const r of rows)for(const id of IDS)totals[id]+=r.scores[id]*r.weight;
  const max=Math.max(...Object.values(totals),1);const normalized=Object.fromEntries(IDS.map(id=>[id,Math.round(totals[id]/max*100)]));
  return {rows,scores:normalized};
}
function classifyTone(body=''){const s=toneScores(body),e=Object.entries(s).sort((a,b)=>b[1]-a[1]);return {primary:LABELS[IDS.indexOf(e[0][0])]||'Neutral / matter-of-fact',scores:s};}
function msgSignals(body=''){const t=String(body).toLowerCase(),ex=(body.match(/!/g)||[]).length,q=(body.match(/\?/g)||[]).length;return {sarcasm:/yeah right|sure\.\.\.|great\.\.\.|obviously|as if|nice one|thanks for nothing/i.test(t),laugh:/(\blol\b|\blmao\b|\bhaha+\b|😂|🤣|😭|💀)/i.test(body),grumpy:/annoyed|annoying|whatever|seriously|ffs|wtf|ugh|stop|not again/i.test(t)||ex>=2,argument:/but you|that's not|you always|you never|i told you|not my fault/i.test(t)||(q>=2&&!/lol|haha/i.test(t)),warm:/thanks|thank you|appreciate|love|proud|miss you|take care|❤️|😊|🥰/i.test(body),serious:/important|need to talk|seriously|deadline|urgent|problem|issue|apolog|sorry/i.test(t)};}
function scoreMessages(messages){const agg=weightedToneScores(messages);const counts=Object.fromEntries(LABELS.map(x=>[x,0]));for(const r of agg.rows){const p=Object.entries(r.scores).sort((a,b)=>b[1]-a[1])[0][0];counts[LABELS[IDS.indexOf(p)]]++;}const percentages=Object.fromEntries(IDS.map((id,i)=>[LABELS[i],agg.scores[id]]));const sorted=LABELS.slice().sort((a,b)=>percentages[b]-percentages[a]);return {sample_size:messages.length,counts,percentages,mostly:sorted[0],secondary:sorted.slice(1,3),labels:LABELS,message_vectors:agg.rows.map(r=>({weight:r.weight,scores:r.scores,body:r.message.body,from_me:r.message.from_me,timestamp:r.message.timestamp}))};}
function scoreChat(chat,messages){const now=Date.now(),unread=messages.filter(m=>!m.from_me),lastIncoming=unread.length?Math.max(...unread.map(m=>m.timestamp||0)):0,waitHours=lastIncoming?Math.max(0,(now-lastIncoming)/3600000):0,mine=messages.filter(m=>m.from_me),intervals=[];for(let i=1;i<mine.length;i++)intervals.push((mine[i].timestamp-mine[i-1].timestamp)/3600000);const baseline=intervals.length?intervals.reduce((a,b)=>a+b,0)/intervals.length:24;const openLoop=unread.some(m=>/[?]$|\b(can|could|would|will|when|where|why|how)\b/i.test(m.body||''));const equityDebt=Math.min(1,unread.length/5),z=baseline>0?waitHours/baseline:0,weakTie=waitHours>24?1:0;return {score:Math.min(100,Math.round(20*openLoop+25*Math.min(1,z/3)+25*equityDebt+20*weakTie)),factors:{open_loop:openLoop,wait_hours:Math.round(waitHours*10)/10,baseline_mean_hours:Math.round(baseline*10)/10,z_score:Math.round(z*100)/100,equity_debt:equityDebt,weak_tie_reactivation:weakTie}};}
function priorityTier(score){return score>=70?'HIGH':score>=40?'MEDIUM':'LOW';}
function conversationStats(chatId,limit=1000){const messages=getMessages(chatId,limit),overall=scoreMessages(messages),recent=scoreMessages(messages.slice(-100)),byPerson={me:scoreMessages(messages.filter(m=>m.from_me)),them:scoreMessages(messages.filter(m=>!m.from_me))},days={};for(const m of messages){const d=new Date(m.timestamp||0);if(!d.getTime())continue;const parts=new Intl.DateTimeFormat(undefined,{year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(d);const dm=Object.fromEntries(parts.map(p=>[p.type,p.value]));const key=`${dm.year}-${dm.month}-${dm.day}`;(days[key]||=[]).push(m);}const trend=Object.entries(days).sort(([a],[b])=>a.localeCompare(b)).slice(-14).map(([date,ms])=>({date,...scoreMessages(ms)}));return {overall,recent,byPerson,trend};}
async function prioritize(){const chats=listChats(),pending=chats.filter(c=>c.unread_from_them>0);if(!pending.length)return {summary:'You are caught up — nothing waiting on a reply.',items:[]};const scored=pending.map(c=>{const unread=getMessages(c.id,30).filter(m=>!m.from_me),s=scoreChat(c,unread);return {chat:c,...s};}).sort((a,b)=>b.score-a.score).slice(0,15);return {summary:`${pending.length} chat(s) waiting on you, ranked using response-time, open-loop, reciprocity and reactivation signals.`,items:scored.map(s=>({chat_id:s.chat.id,chat_name:s.chat.name,priority:priorityTier(s.score),score:s.score,factors:s.factors,reason:s.factors.open_loop?'There is a direct question or request waiting.':s.factors.z_score>1?`You have waited longer than usual here (~${s.factors.wait_hours}h vs ~${s.factors.baseline_mean_hours}h typical).`:'Worth reviewing when practical.',suggested_action:s.factors.open_loop?'Answer the direct question or request first.':'Reply when practical.'}))};}
module.exports={scoreChat,priorityTier,conversationStats,msgSignals,scoreMessages,prioritize,weightedToneScores,toneScores,LABELS};
