const path = require('path');
const express = require('express');
const cors = require('cors');
const wa = require('./whatsapp');
const { listChats, listContacts, getMessages, getAllMessages, getChat, isChatHidden, hideChatFromAlgorithm, getAryAIWorkspaceFacts, searchAryAIMessages, recordAnalysisFeedback, setChatContext, setChatAIInstructions, setChatCustomName, setChatProfile, getUserProfile, setUserProfile, recordAnalysis, listAnalyses, getAnalysisSummary, listRecentActivity, saveReport, listSavedReports, getSavedReport, deleteSavedReport, createAryConversation, listAryConversations, getAryConversation, getAryMessages, appendAryMessage, renameAryConversation, deleteAryConversation } = require('./db');
const { analyzeTextSelection, summarizeConversationDays, simulateCounterfactual, analyzeRelationshipMode, askAryAI, analyzeCorporateText, prioritize, classifyChatContext, TONE_PROFILES, TONE_OPTIONS, RELATIONSHIP_STATUSES, RELATIONSHIP_TONES, OLLAMA_MODEL, OLLAMA_ARY_TIMEOUT_MS, OLLAMA_ARY_GENERIC_TIMEOUT_MS, OLLAMA_ARY_WHATSAPP_TIMEOUT_MS, OLLAMA_ARY_GENERIC_MODEL, OLLAMA_SELECTION_TIMEOUT_MS, OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS } = require('./llm');
const { conversationStats } = require('./stats');
const { splitConversationByDay, prioritizeDayBlocks } = require('./llm');
const { startPeriodicBackups } = require('./backup');

process.on('uncaughtException', (err) => {
  console.error('UNCAUGHT EXCEPTION (server kept alive):', err?.stack || err);
});
process.on('unhandledRejection', (err) => {
  console.error('UNHANDLED REJECTION (server kept alive):', err?.stack || err);
});

const app = express();
app.use(cors());
app.use(express.json({ limit: '6mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/api/status', (req,res) => res.json({ ...wa.getStatus(), model: OLLAMA_MODEL, pid: process.pid, node: process.version, selection_timeout_ms: OLLAMA_SELECTION_TIMEOUT_MS, text_analysis_timeout_ms: OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS, ary_ai_timeout_ms: OLLAMA_ARY_TIMEOUT_MS, ary_ai_generic_timeout_ms: OLLAMA_ARY_GENERIC_TIMEOUT_MS, ary_ai_whatsapp_timeout_ms: OLLAMA_ARY_WHATSAPP_TIMEOUT_MS, ary_ai_generic_model: OLLAMA_ARY_GENERIC_MODEL, build: '8.23-speed-pass' }));

// Live message stream. New WhatsApp messages are pushed to the browser
// immediately, independently of AI analysis and periodic history sync.
app.get('/api/live', (req,res) => {
  res.setHeader('Content-Type','text/event-stream');
  res.setHeader('Cache-Control','no-cache, no-transform');
  res.setHeader('Connection','keep-alive');
  if (res.flushHeaders) res.flushHeaders();
  const send = payload => { try { res.write(`data: ${JSON.stringify(payload)}\n\n`); } catch (_) {} };
  const onMessage = msg => send({ type:'message', message:msg, at:Date.now() });
  wa.liveEvents.on('message', onMessage);
  const heartbeat = setInterval(() => { try { res.write(': heartbeat\n\n'); } catch (_) {} }, 15000);
  req.on('close', () => { clearInterval(heartbeat); wa.liveEvents.off('message', onMessage); });
});
app.get('/api/context-types', (req,res) => res.json(Object.entries(TONE_PROFILES).map(([id,p]) => ({id,label:p.label}))));
app.get('/api/tone-options', (req,res) => res.json(TONE_OPTIONS));
app.get('/api/relationship-options', (req,res) => res.json({statuses:RELATIONSHIP_STATUSES,tones:RELATIONSHIP_TONES.map(([id,label])=>({id,label}))}));
app.get('/api/chats', (req,res) => res.json(listChats()));

// Ary AI conversations — real server-persisted threads so "New chat" and
// "view past conversations" work the same way after a reload or restart.
app.get('/api/ary/conversations', (req,res) => { try { res.json(listAryConversations()); } catch(e){ res.status(500).json({error:e.message}); } });
app.post('/api/ary/conversations', (req,res) => { try { res.json(createAryConversation(String(req.body?.title||''))); } catch(e){ res.status(500).json({error:e.message}); } });
app.get('/api/ary/conversations/:id/messages', (req,res) => {
  try {
    const convo = getAryConversation(req.params.id);
    if (!convo) return res.status(404).json({ error: 'Conversation not found.' });
    res.json({ conversation: convo, messages: getAryMessages(req.params.id) });
  } catch(e){ res.status(500).json({error:e.message}); }
});
app.patch('/api/ary/conversations/:id', (req,res) => { try { res.json(renameAryConversation(req.params.id, String(req.body?.title||''))); } catch(e){ res.status(500).json({error:e.message}); } });
app.delete('/api/ary/conversations/:id', (req,res) => { try { deleteAryConversation(req.params.id); res.json({ deleted:true }); } catch(e){ res.status(500).json({error:e.message}); } });

app.post('/api/ary-ai/ask', async (req,res) => {
  if(deepAnalysisBusy) return res.status(429).json({error:'Another AI analysis is already running. Please wait for it to finish or press Stop.',busy:true});
  deepAnalysisBusy=true;
  const requestId=String(req.body?.request_id||req.headers['x-analysis-request-id']||'').trim();
  const controller=new AbortController(); if(requestId) activeAiRequests.set(requestId,controller);
  const question=String(req.body?.question||'');
  if(!question.trim()){ deepAnalysisBusy=false; if(requestId) activeAiRequests.delete(requestId); return res.status(400).json({error:'Ask Ary AI a question first.'}); }
  try {
    // The conversation is the source of truth for memory: if the client
    // didn't send a conversation_id (or sent a stale/deleted one), start a
    // fresh persisted thread rather than silently going stateless.
    let conversation=null;
    const requestedConvoId=req.body?.conversation_id;
    if(requestedConvoId){ conversation=getAryConversation(requestedConvoId); }
    if(!conversation){ conversation=createAryConversation(question); }
    // Prior turns come from the database, not from whatever the browser
    // happened to still have in memory — this is what makes "view past
    // conversations" and "new chat" actually reliable across reloads.
    const priorMessages=getAryMessages(conversation.id, 26);
    const history=priorMessages.slice(-12).map(m=>({role:m.role,content:m.content}));
    appendAryMessage(conversation.id,'user',question);

    const result=await askAryAI(question,{chatId:String(req.body?.chat_id||'').trim()||null,scope:String(req.body?.scope||'workspace'),history,signal:controller.signal,userContext:String(req.body?.context||'')});
    appendAryMessage(conversation.id,'assistant',result.answer||'');
    // analysis_records.chat_id is intentionally NOT NULL because historical analyses
    // belong to a real WhatsApp chat. Generic Ary AI questions have no chat_id, so
    // never try to insert them into that table. More importantly, logging must never
    // be allowed to turn a successfully generated AI answer into an API failure.
    if(result?.chat?.id){
      try {
        recordAnalysis({chat_id:result.chat.id,kind:'ary_ai',selected_text:result.chat.name||'Conversation',user_request:result.question,analysis:result,created_at:Date.now()});
      } catch(logErr) {
        console.warn('Ary AI answer generated but analysis-history logging failed:', logErr?.message || logErr);
      }
    }
    res.json({...result, conversation:{id:conversation.id, title:getAryConversation(conversation.id)?.title||conversation.title}});
  } catch(e) {
    const status=(e?.message==='CANCELLED_BY_USER'||e?.message==='Stopped by user.')?499:(/OLLAMA_|Could not reach Ollama|Ollama request failed/i.test(String(e?.message||''))?503:400);
    res.status(status).json({error:e.message||'Ary AI could not answer.',cancelled:status===499,retryable:status===503});
  } finally { if(requestId) activeAiRequests.delete(requestId); deepAnalysisBusy=false; }
});


app.post('/api/corporate/analyze', async (req,res) => {
  if(deepAnalysisBusy) return res.status(429).json({error:'Another AI analysis is already running. Please wait for it to finish or press Stop.',busy:true});
  const text=String(req.body?.text||'').trim();
  const words=text ? text.split(/\s+/).filter(Boolean) : [];
  if(!text) return res.status(400).json({error:'Paste some workplace text first.'});
  if(words.length>150) return res.status(400).json({error:`Professional Mode accepts up to 150 words. You pasted ${words.length}.`});
  deepAnalysisBusy=true;
  const requestId=String(req.body?.request_id||req.headers['x-analysis-request-id']||'').trim();
  const controller=new AbortController(); if(requestId) activeAiRequests.set(requestId,controller);
  try {
    const result=await analyzeCorporateText(text,{recipient:String(req.body?.recipient||'Unknown'),objective:String(req.body?.objective||'Sound more professional'),signal:controller.signal});
    res.json(result);
  } catch(e) {
    const status=(e?.message==='CANCELLED_BY_USER')?499:(/OLLAMA_|Could not reach Ollama|Ollama request failed/i.test(String(e?.message||''))?503:400);
    res.status(status).json({error:e.message||'Professional analysis could not be completed.',cancelled:status===499,retryable:status===503});
  } finally { if(requestId) activeAiRequests.delete(requestId); deepAnalysisBusy=false; }
});

app.get('/api/contacts', (req,res) => res.json(listContacts()));
app.get('/api/chats/:id/messages', (req,res) => { if(isChatHidden(req.params.id)) return res.status(404).json({error:'This contact is hidden from the algorithm.'}); const limit=Number(req.query.limit||0); const rows=limit>0 ? getMessages(req.params.id, Math.min(limit,200000)) : getAllMessages(req.params.id); res.json(rows); });

app.post('/api/chats/:id/context', (req,res) => { setChatContext(req.params.id, req.body.context_type, req.body.tone_note, null); res.json({ok:true}); });
app.post('/api/chats/:id/ai-instructions', (req,res) => { setChatAIInstructions(req.params.id, req.body?.ai_instructions || ''); res.json({ok:true}); });
app.get('/api/profile', (req,res) => res.json(getUserProfile()));
app.post('/api/profile', (req,res) => { try { res.json({ok:true, profile:setUserProfile(req.body || {})}); } catch(e){ res.status(400).json({error:e.message}); } });
app.post('/api/chats/:id/profile', (req,res) => { try { const chat=setChatProfile(req.params.id, req.body || {}); res.json({ok:true, profile:{gender:chat?.contact_gender||'', age:chat?.contact_age||null}}); } catch(e){ res.status(400).json({error:e.message}); } });
// Lets the user override the displayed chat name (raw phone numbers, group
// JIDs, @lid ids, etc.) with a readable nickname. Sending an empty name
// clears the override and falls back to whatever WhatsApp reported.
app.delete('/api/chats/:id', (req,res) => {
  try {
    hideChatFromAlgorithm(req.params.id);
    res.json({ ok:true, hidden:true, message:'Removed from this algorithm only. WhatsApp was not changed.' });
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.post('/api/chats/:id/name', (req,res) => {
  try {
    setChatCustomName(req.params.id, req.body?.name || '');
    const chat = getChat(req.params.id);
    res.json({ ok:true, display_name: chat?.display_name || req.params.id });
  } catch(e){ res.status(500).json({error:e.message}); }
});
app.post('/api/chats/:id/classify', async (req,res) => { try { res.json({context_type:await classifyChatContext(req.params.id)}); } catch(e){res.status(500).json({error:e.message});} });
app.post('/api/sync', async (req,res) => { try { res.status(202).json({ok:true,...await wa.syncAll()}); } catch(e){res.status(500).json({ok:false,error:e.message});} });
app.post('/api/whatsapp/new-qr', async (req,res) => { try { res.status(202).json(await wa.forceNewQr()); } catch(e){ res.status(500).json({ok:false,error:e.message}); } });

app.get('/api/chats/:id/stats', (req,res) => { try { res.json(conversationStats(req.params.id, Math.min(Number(req.query.limit)||1000,5000))); } catch(e){ res.status(500).json({error:e.message}); } });
app.get('/api/chats/:id/days', (req,res) => { try { const messages=getMessages(req.params.id, Math.min(Number(req.query.limit)||50000,50000)); const days=splitConversationByDay(messages); res.json({days, prioritized:prioritizeDayBlocks(messages)}); } catch(e){ res.status(500).json({error:e.message}); } });
app.get('/api/chats/:id/analysis-history', (req,res) => { try { res.json({summary:getAnalysisSummary(req.params.id), items:listAnalyses(req.params.id, Math.min(Number(req.query.limit)||50000,50000))}); } catch(e){res.status(500).json({error:e.message});} });

app.get('/api/activity', (req,res) => { try { res.json({items:listRecentActivity(Math.min(Number(req.query.limit)||50,200))}); } catch(e){ res.status(500).json({error:e.message}); } });

app.get('/api/saved-reports', (req,res) => { try { const items=listSavedReports(Math.min(Number(req.query.limit)||100,500)); res.json({items,count:items.length}); } catch(e){res.status(500).json({error:e.message});} });
app.get('/api/saved-reports/:id', (req,res) => { try { const item=getSavedReport(req.params.id); if(!item) return res.status(404).json({error:'Saved report not found.'}); res.json(item); } catch(e){res.status(500).json({error:e.message});} });
app.post('/api/saved-reports', (req,res) => { try { const chatId=String(req.body?.chat_id||'').trim(); if(!chatId || isChatHidden(chatId)) return res.status(400).json({error:'Select a valid conversation first.'}); const analysis=req.body?.analysis; if(!analysis || typeof analysis!=='object') return res.status(400).json({error:'There is no analysis result to save yet.'}); res.json({ok:true, report:saveReport({chat_id:chatId,contact_name:req.body?.contact_name,report_type:req.body?.report_type,title:req.body?.title,analysis,created_at:Date.now()})}); } catch(e){res.status(500).json({error:e.message});} });
app.delete('/api/saved-reports/:id', (req,res) => { try { res.json({ok:deleteSavedReport(req.params.id)}); } catch(e){res.status(500).json({error:e.message});} });

// In-flight AI requests, keyed by a client-generated request id, so the
// "Stop" button in the UI can actually cancel the underlying Ollama call
// instead of just abandoning it client-side while it keeps running.
const activeAiRequests = new Map();
let deepAnalysisBusy = false;
app.post('/api/cancel/:requestId', (req,res) => {
  const controller = activeAiRequests.get(req.params.requestId);
  if (controller) { controller.abort(); return res.json({ ok:true, cancelled:true }); }
  res.json({ ok:true, cancelled:false });
});

app.post('/api/relationship-analysis', async (req,res) => {
  if(deepAnalysisBusy) return res.status(429).json({error:'Another AI analysis is already running. Please wait for it to finish or press Stop.',busy:true});
  deepAnalysisBusy=true;
  const requestId=String(req.body?.request_id||'');
  const controller=new AbortController();
  if(requestId) activeAiRequests.set(requestId, controller);
  try {
    const chatIds=Array.isArray(req.body?.chat_ids)?req.body.chat_ids.slice(0,2).map(String):[];
    const objective=String(req.body?.objective||'').slice(0,4000);
    const status=String(req.body?.relationship_status||'talking_exploring');
    const result=await analyzeRelationshipMode(chatIds,objective,status,controller.signal);
    const primary=result.conversations?.[0]?.chat_id;
    if(primary) recordAnalysis({chat_id:primary,kind:'relationship',selected_text:`Relationship Mode · ${result.conversations.length} conversation(s) · ${result.analysis_scope.messages_considered} messages`,user_request:objective,analysis:result,created_at:Date.now()});
    res.json({...result,saved:Boolean(primary)});
  } catch(e){
    const statusCode=e.message==='Stopped by user.'?499:(/OLLAMA_|Could not reach Ollama|Ollama request failed/i.test(String(e?.message||''))?503:500);
    res.status(statusCode).json({error:e.message,cancelled:statusCode===499,retryable:statusCode===503});
  } finally {
    if(requestId) activeAiRequests.delete(requestId);
    deepAnalysisBusy=false;
  }
});
app.post('/api/chats/:id/summarize', async (req,res) => {
  if(deepAnalysisBusy) return res.status(429).json({error:'An AI analysis is already running. Please wait for it to finish or press Stop.',busy:true});
  deepAnalysisBusy=true;
  const requestId=String(req.body?.request_id||'');
  const controller=new AbortController();
  if(requestId) activeAiRequests.set(requestId, controller);
  try {
    const start=String(req.body?.start_date||'').trim(), end=String(req.body?.end_date||'').trim();
    const instruction=String(req.body?.instruction||'').slice(0,4000);
    const result=await summarizeConversationDays(req.params.id,start,end,instruction,controller.signal);
    recordAnalysis({chat_id:req.params.id,kind:'conversation_summary',selected_text:`Conversation Summary · ${result.date_range.start} to ${result.date_range.end} · ${result.messages_selected} messages`,user_request:instruction,analysis:result,created_at:Date.now()});
    res.json({...result,saved:true});
  } catch(e) {
    const status=e.message==='Stopped by user.'?499:(/OLLAMA_|Could not reach Ollama|Ollama request failed/i.test(String(e?.message||''))?503:400);
    res.status(status).json({error:e.message,cancelled:status===499,retryable:status===503});
  } finally { if(requestId) activeAiRequests.delete(requestId); deepAnalysisBusy=false; }
});

app.post('/api/chats/:id/counterfactual', async (req,res) => {
  if(deepAnalysisBusy) return res.status(429).json({error:'An AI analysis is already running. Please wait for it to finish or press Stop.',busy:true});
  deepAnalysisBusy=true;
  const requestId=String(req.body?.request_id||req.headers['x-analysis-request-id']||'').trim();
  const controller=new AbortController(); if(requestId) activeAiRequests.set(requestId,controller);
  try{
    const result=await simulateCounterfactual(req.params.id,req.body?.target_message_id,req.body?.hypothetical_text,req.body?.objective||'',controller.signal);
    recordAnalysis({chat_id:req.params.id,kind:'counterfactual',selected_text:`Counterfactual for ${result.target_message.sender}: ${result.target_message.real_text} → ${result.target_message.hypothetical_text}`,user_request:req.body?.objective||'',analysis:result,created_at:Date.now()});
    res.json(result);
  }catch(e){ const status=(e?.message==='CANCELLED_BY_USER'||e?.name==='AbortError'||e?.message==='Stopped by user.')?499:(/OLLAMA_|Could not reach Ollama|Ollama request failed/i.test(String(e?.message||''))?503:400); res.status(status).json({error:e.message||'Counterfactual simulation failed.',cancelled:status===499,retryable:status===503}); }
  finally{ if(requestId) activeAiRequests.delete(requestId); deepAnalysisBusy=false; }
});

app.post('/api/text-analysis', async (req,res) => {
  if(deepAnalysisBusy) return res.status(429).json({error:'An AI analysis is already running. Please wait for it to finish or press Stop.',busy:true});
  deepAnalysisBusy=true;
  const requestId=String(req.body?.request_id||req.headers['x-analysis-request-id']||'').trim();
  const controller=new AbortController(); if(requestId) activeAiRequests.set(requestId,controller);
  try{
    const source=String(req.body?.source||'paste').trim()==='contact'?'contact':'paste';
    const instruction=String(req.body?.instruction||'').slice(0,4000);
    let text=''; let chatId=null; let sourceLabel='Pasted text'; let saved=false;
    if(source==='paste'){
      text=String(req.body?.text||'').trim();
      if(!text) return res.status(400).json({error:'Paste some text to analyze first.'});
    } else {
      chatId=String(req.body?.chat_id||'').trim();
      if(!chatId) return res.status(400).json({error:'Choose a contact conversation first.'});
      const chat=getChat(chatId); if(!chat) return res.status(404).json({error:'That contact conversation is not available.'});
      sourceLabel=chat.display_name||chat.name||chatId;
      // Read only a bounded recent window, then walk backward until the 1,500-word
      // Text Analysis ceiling is reached. The final analysis never exceeds 1,500 words.
      const rows=getMessages(chatId,5000).filter(m=>String(m.body||'').trim());
      if(!rows.length) return res.status(400).json({error:'No stored text messages are available for this contact. Sync the conversation first.'});
      const chosen=[]; let words=0;
      for(let i=rows.length-1;i>=0;i--){
        const body=String(rows[i].body||'').trim();
        const count=body.split(/\s+/).filter(Boolean).length;
        if(words+count>1500){
          const remaining=1500-words;
          if(remaining>0){
            const clipped=body.split(/\s+/).filter(Boolean).slice(-remaining).join(' ');
            if(clipped) chosen.push({...rows[i],body:clipped});
          }
          break;
        }
        chosen.push(rows[i]); words+=count;
        if(words>=1500) break;
      }
      chosen.reverse();
      text=chosen.map(m=>{
        const ts=Number(m.timestamp||0); const stamp=Number.isFinite(ts)&&ts?`[${new Date(ts).toISOString()}] `:'';
        return `${stamp}${m.from_me?'ME':'THEM'}: ${String(m.body||'').trim()}`;
      }).join('\n');
    }
    const wordCount=text.split(/\s+/).filter(Boolean).length;
    if(wordCount>1500) return res.status(400).json({error:`Text Analysis accepts up to 1,500 words. This source contains ${wordCount.toLocaleString()} words.`});
    const result=await analyzeTextSelection(chatId,text,instruction,controller.signal,{budget_ms:OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS,standalone:source==='paste'});
    result.analysis_source={type:source,label:sourceLabel,word_count:wordCount,limit_words:1500,time_limit_ms:OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS};
    if(chatId){
      try{ recordAnalysis({chat_id:chatId,kind:'text_analysis',selected_text:text,user_request:instruction,analysis:result,created_at:Date.now()}); saved=true; }
      catch(logErr){ console.warn('Text analysis completed but history logging failed:',logErr?.message||logErr); }
    }
    res.json({...result,saved});
  }catch(e){
    const status=(e?.message==='CANCELLED_BY_USER'||e?.message==='Stopped by user.'||e?.name==='AbortError')?499:(/OLLAMA_|Could not reach Ollama|Ollama request failed/i.test(String(e?.message||''))?503:400);
    res.status(status).json({error:e.message||'Text analysis failed.',cancelled:status===499,retryable:status===503});
  }finally{ if(requestId) activeAiRequests.delete(requestId); deepAnalysisBusy=false; }
});

app.post('/api/chats/:id/analyze-selection', async (req,res) => {
  if(deepAnalysisBusy) return res.status(429).json({error:'Deep Analysis is already running. Please wait for the current analysis to finish or press Stop.',busy:true});
  deepAnalysisBusy=true;
  const requestId=String(req.body?.request_id||'');
  const controller=new AbortController();
  if(requestId) activeAiRequests.set(requestId, controller);
  try {
    const requestedRaw=req.body?.message_limit;
    const hasMessageLimit=requestedRaw!==undefined && requestedRaw!==null && String(requestedRaw)!=='';
    let text=String(req.body?.text||'').trim();
    let requestedCount=null;
    if(hasMessageLimit){
      requestedCount=Math.floor(Number(requestedRaw));
      if(!Number.isFinite(requestedCount)||requestedCount<1||requestedCount>5000) return res.status(400).json({error:'Deep Analysis message count must be between 1 and 5,000.'});
      // Fetch exactly the requested number from SQLite. This is the important
      // fast-path: the server never reads the other messages just to discard
      // them later. getMessages returns the most recent N in chronological order.
      const rows=getMessages(req.params.id,requestedCount);
      text=rows.map(m=>{
        const ts=Number(m.timestamp||0);
        const stamp=Number.isFinite(ts)&&ts?`[${new Date(ts).toISOString()}] `:'';
        return `${stamp}${m.from_me?'ME':'THEM'}: ${String(m.body??'').trim()}`;
      }).filter(x=>!/: $/.test(x)).join('\n');
      if(!text) return res.status(400).json({error:'No stored text messages are available for this conversation. Sync the conversation first.'});
    }
    if(!text) return res.status(400).json({error:'Select some message text first.'});
    const instruction=String(req.body?.instruction||'').slice(0,4000);
    const analysisMode=String(req.body?.analysis_mode||'').trim();
    if(analysisMode==='manual_text'){
      const wordCount=text.split(/\s+/).filter(Boolean).length;
      if(wordCount>1500) return res.status(400).json({error:`Text Analysis accepts up to 1,500 words. You pasted ${wordCount.toLocaleString()}.`});
    }
    const result=await analyzeTextSelection(req.params.id,text,instruction,controller.signal,{budget_ms:analysisMode==='manual_text'?OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS:null});
    if(hasMessageLimit){
      result.analysis_scope={...(result.analysis_scope||{}),requested_messages:requestedCount,selected_messages:requestedCount,selection_mode:'most_recent_messages'};
    }
    recordAnalysis({chat_id:req.params.id,kind:'selection',selected_text:text,user_request:instruction,analysis:result,created_at:Date.now()});
    res.json({ ...result, saved:true });
  } catch(e){
    const status = e.message === 'Stopped by user.' ? 499 : (/OLLAMA_|Could not reach Ollama|Ollama request failed/i.test(String(e?.message||'')) ? 503 : 500);
    res.status(status).json({error:e.message, cancelled: status===499, retryable: status===503});
  } finally {
    if(requestId) activeAiRequests.delete(requestId);
    deepAnalysisBusy=false;
  }
});
app.post('/api/chats/:id/analysis-feedback', (req,res) => { try { const note=String(req.body?.note||'').trim(); if(!note) return res.status(400).json({error:'Correction cannot be empty.'}); recordAnalysisFeedback({chat_id:req.params.id,kind:String(req.body?.kind||'user_correction').slice(0,80),note:note.slice(0,4000),created_at:Date.now()}); res.json({ok:true}); } catch(e){res.status(500).json({error:e.message});} });

app.get('/api/priorities', async (req,res) => { try { res.json(await prioritize()); } catch(e){res.status(500).json({error:e.message});} });

// Last-resort Express error boundary. Route-level handlers above already catch
// expected failures; this prevents an unexpected middleware error from turning
// into an unhandled rejection or an HTML error page.
app.use((err, req, res, next) => {
  console.error('EXPRESS ERROR:', err?.stack || err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'The server recovered from an unexpected request error. The server process is still running.' });
});

const PORT=Number(process.env.PORT)||3000;
app.listen(PORT,()=>{
  console.log(`\nAry AI running at http://localhost:${PORT}`);
  console.log(`AI model: ${OLLAMA_MODEL}`);
  console.log('Starting WhatsApp connection (a QR code will appear here and on the page)...\n');
  startPeriodicBackups();
  wa.init();
});
