// db.js — local SQLite storage. Everything lives in data/copilot.db on your disk.
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const DATA_DIR = path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, 'copilot.db'));
db.pragma('journal_mode = WAL');
// Speed/memory tuning. WAL already avoids reader/writer blocking; these four
// pragmas cut disk I/O further for a laptop-local, single-writer app:
// - synchronous=NORMAL is safe under WAL (only risks the last few WAL frames
//   on an OS crash, not app-level data loss) and avoids an fsync on every commit.
// - a larger page cache keeps hot chat/message pages resident instead of
//   re-reading them from disk on every list/analysis call.
// - temp_store=MEMORY keeps ORDER BY / GROUP BY scratch space in RAM.
// - a bounded mmap lets SQLite read large tables without extra copies.
db.pragma('synchronous = NORMAL');
db.pragma('cache_size = -32000'); // ~32MB page cache (negative = KB)
db.pragma('temp_store = MEMORY');
db.pragma('mmap_size = 268435456'); // 256MB

db.exec(`
CREATE TABLE IF NOT EXISTS hidden_chats (
  chat_id TEXT PRIMARY KEY,
  hidden_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS chats (
  id TEXT PRIMARY KEY,
  name TEXT,
  is_group INTEGER DEFAULT 0,
  last_message_at INTEGER DEFAULT 0,
  importance REAL DEFAULT 0.5
);
`);

const chatCols = db.prepare('PRAGMA table_info(chats)').all().map(c => c.name);
if (!chatCols.includes('context_type')) db.exec('ALTER TABLE chats ADD COLUMN context_type TEXT');
if (!chatCols.includes('tone_note')) db.exec('ALTER TABLE chats ADD COLUMN tone_note TEXT');
if (!chatCols.includes('ai_instructions')) db.exec('ALTER TABLE chats ADD COLUMN ai_instructions TEXT');
// A user-set nickname that always wins over whatever WhatsApp reports (raw
// phone numbers, group JIDs, @lid ids, etc.), so the chat list can always
// show something readable instead of an ID string.
if (!chatCols.includes('custom_name')) db.exec('ALTER TABLE chats ADD COLUMN custom_name TEXT');
if (!chatCols.includes('contact_gender')) db.exec('ALTER TABLE chats ADD COLUMN contact_gender TEXT');
if (!chatCols.includes('contact_age')) db.exec('ALTER TABLE chats ADD COLUMN contact_age INTEGER');

db.exec(`
CREATE TABLE IF NOT EXISTS contacts (
  id TEXT PRIMARY KEY,
  name TEXT,
  pushname TEXT,
  phone TEXT
);
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  chat_id TEXT NOT NULL,
  sender TEXT,
  from_me INTEGER DEFAULT 0,
  body TEXT,
  timestamp INTEGER,
  FOREIGN KEY (chat_id) REFERENCES chats(id)
);
CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id, timestamp);
-- Covers my_message_count / unread_from_them in listChats() (both filter on
-- from_me), so those no longer fall back to a partial scan of every message
-- in a chat just to count one side of the conversation.
CREATE INDEX IF NOT EXISTS idx_messages_chat_fromme_ts ON messages(chat_id, from_me, timestamp);
CREATE TABLE IF NOT EXISTS feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id TEXT NOT NULL,
  suggested_text TEXT,
  final_text TEXT,
  action TEXT,
  created_at INTEGER
);
CREATE TABLE IF NOT EXISTS analysis_feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  note TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS analysis_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  selected_text TEXT,
  user_request TEXT,
  response_text TEXT,
  edited_text TEXT,
  analysis_json TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (chat_id) REFERENCES chats(id)
);
CREATE INDEX IF NOT EXISTS idx_analysis_records_chat ON analysis_records(chat_id, created_at);
CREATE TABLE IF NOT EXISTS saved_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  report_type TEXT NOT NULL,
  title TEXT NOT NULL,
  analysis_json TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (chat_id) REFERENCES chats(id)
);
CREATE INDEX IF NOT EXISTS idx_saved_reports_created ON saved_reports(created_at DESC);
CREATE TABLE IF NOT EXISTS ary_conversations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL DEFAULT 'New conversation',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS ary_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  conversation_id INTEGER NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (conversation_id) REFERENCES ary_conversations(id)
);
CREATE INDEX IF NOT EXISTS idx_ary_messages_conv ON ary_messages(conversation_id, created_at);
CREATE INDEX IF NOT EXISTS idx_ary_conversations_updated ON ary_conversations(updated_at DESC);
CREATE TABLE IF NOT EXISTS sync_meta (
  key TEXT PRIMARY KEY,
  value TEXT
);
CREATE TABLE IF NOT EXISTS chat_sync_state (
  chat_id TEXT PRIMARY KEY,
  history_complete INTEGER DEFAULT 0,
  last_synced_at INTEGER DEFAULT 0,
  last_message_timestamp INTEGER DEFAULT 0,
  FOREIGN KEY (chat_id) REFERENCES chats(id)
);
`);

// listChats() is the single most expensive read (it aggregates the whole
// messages table per chat) and the single most frequently called one — every
// page load, every Ary AI data-grounded question, every dashboard refresh.
// Rather than change its SQL shape (and risk changing its output), cache the
// computed rows and invalidate on any write that could change them. Version
// number, not a timer, so results are always exactly as fresh as the data.
let _chatsCache = null;
let _chatsCacheVersion = -1;
let _dbVersion = 0;
function bumpChatsVersion() { _dbVersion++; }

function upsertChat(chat) {
  db.prepare(`
    INSERT INTO chats (id, name, is_group, last_message_at)
    VALUES (@id, @name, @is_group, @last_message_at)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      is_group = excluded.is_group,
      last_message_at = MAX(chats.last_message_at, excluded.last_message_at)
  `).run(chat);
  bumpChatsVersion();
}

function upsertContact(contact) {
  if (!contact || !contact.id) return;
  db.prepare(`
    INSERT INTO contacts (id, name, pushname, phone)
    VALUES (@id, @name, @pushname, @phone)
    ON CONFLICT(id) DO UPDATE SET
      name = COALESCE(NULLIF(excluded.name, ''), contacts.name),
      pushname = COALESCE(NULLIF(excluded.pushname, ''), contacts.pushname),
      phone = COALESCE(NULLIF(excluded.phone, ''), contacts.phone)
  `).run({
    id: contact.id,
    name: contact.name || '',
    pushname: contact.pushname || '',
    phone: contact.phone || ''
  });
  bumpChatsVersion();
}

function listContacts() {
  return db.prepare('SELECT * FROM contacts ORDER BY name COLLATE NOCASE').all();
}

function insertMessage(msg) {
  if (!msg || !msg.id || !msg.chat_id) return;
  db.prepare(`
    INSERT OR IGNORE INTO messages (id, chat_id, sender, from_me, body, timestamp)
    VALUES (@id, @chat_id, @sender, @from_me, @body, @timestamp)
  `).run({ ...msg, body: msg.body || '', timestamp: Number(msg.timestamp) || Date.now() });
  bumpChatsVersion();
}

function listChats() {
  if (_chatsCache && _chatsCacheVersion === _dbVersion) return _chatsCache;
  const rows = _listChatsUncached();
  _chatsCache = rows;
  _chatsCacheVersion = _dbVersion;
  return rows;
}

function _listChatsUncached() {
  return db.prepare(`
    SELECT c.*,
      COALESCE(
        NULLIF(c.custom_name, ''),
        NULLIF(NULLIF(NULLIF(ct.name, ''), c.id), ct.phone),
        NULLIF(ct.pushname, ''),
        NULLIF(c.name, ''),
        c.id
      ) AS display_name,
      NULLIF(ct.name, '') AS whatsapp_name,
      NULLIF(ct.pushname, '') AS whatsapp_pushname,
      (SELECT COUNT(*) FROM messages m0 WHERE m0.chat_id = c.id) AS message_count,
      (SELECT COUNT(*) FROM messages m1 WHERE m1.chat_id = c.id AND m1.from_me = 1) AS my_message_count,
      (SELECT MIN(timestamp) FROM messages m2 WHERE m2.chat_id = c.id) AS first_message_at,
      (SELECT MAX(timestamp) FROM messages m3 WHERE m3.chat_id = c.id) AS latest_message_at,
      (SELECT body FROM messages m WHERE m.chat_id = c.id ORDER BY timestamp DESC LIMIT 1) AS last_body,
      (SELECT COUNT(*) FROM messages m WHERE m.chat_id = c.id AND from_me = 0
        AND timestamp > COALESCE((SELECT MAX(timestamp) FROM messages m2 WHERE m2.chat_id = c.id AND from_me = 1), 0)
      ) AS unread_from_them
    FROM chats c
    LEFT JOIN contacts ct ON ct.id = c.id
    LEFT JOIN hidden_chats h ON h.chat_id = c.id
    WHERE h.chat_id IS NULL
    ORDER BY c.last_message_at DESC
  `).all();
}

function isChatHidden(chatId) {
  return !!db.prepare('SELECT 1 FROM hidden_chats WHERE chat_id = ?').get(chatId);
}

function hideChatFromAlgorithm(chatId) {
  const id = String(chatId || '').trim();
  if (!id) throw new Error('Chat id is required.');
  const tx = db.transaction(() => {
    db.prepare('INSERT OR IGNORE INTO hidden_chats (chat_id, hidden_at) VALUES (?, ?)').run(id, Date.now());
    // Remove all locally stored algorithm data for this conversation. This does
    // not call WhatsApp and does not delete anything from the real account.
    db.prepare('DELETE FROM messages WHERE chat_id = ?').run(id);
    db.prepare('DELETE FROM feedback WHERE chat_id = ?').run(id);
    db.prepare('DELETE FROM analysis_feedback WHERE chat_id = ?').run(id);
    db.prepare('DELETE FROM analysis_records WHERE chat_id = ?').run(id);
    db.prepare('DELETE FROM chat_sync_state WHERE chat_id = ?').run(id);
    db.prepare('DELETE FROM chats WHERE id = ?').run(id);
    db.prepare('DELETE FROM contacts WHERE id = ?').run(id);
  });
  tx();
  bumpChatsVersion();
  return true;
}

function setChatCustomName(chatId, name) {
  const clean = String(name || '').trim().slice(0, 120);
  db.prepare('UPDATE chats SET custom_name = ? WHERE id = ?').run(clean || null, chatId);
  bumpChatsVersion();
  return clean;
}

function getMessages(chatId, limit = 50) {
  return db.prepare('SELECT * FROM messages WHERE chat_id = ? ORDER BY timestamp DESC LIMIT ?').all(chatId, limit).reverse();
}

function getAllMessages(chatId) {
  return db.prepare('SELECT * FROM messages WHERE chat_id = ? ORDER BY timestamp ASC').all(chatId);
}

function getMyPastMessages(chatId, limit = 12) {
  return db.prepare(`
    SELECT body FROM messages WHERE chat_id = ? AND from_me = 1 AND body IS NOT NULL AND body != ''
    ORDER BY timestamp DESC LIMIT ?
  `).all(chatId, limit).map(r => r.body).reverse();
}

function getMyGlobalStyleSamples(limit = 20) {
  return db.prepare(`
    SELECT body FROM messages WHERE from_me = 1 AND body IS NOT NULL AND length(body) > 3
    ORDER BY RANDOM() LIMIT ?
  `).all(limit).map(r => r.body);
}

function getChat(chatId) {
  return db.prepare(`
    SELECT c.*, COALESCE(NULLIF(c.custom_name, ''), NULLIF(c.name, ''), c.id) AS display_name
    FROM chats c WHERE c.id = ?
  `).get(chatId);
}

function setChatProfile(chatId, profile = {}) {
  const gender = String(profile.gender || '').trim().slice(0, 30) || null;
  const ageRaw = Number(profile.age);
  const age = Number.isFinite(ageRaw) && ageRaw >= 13 && ageRaw <= 120 ? Math.round(ageRaw) : null;
  db.prepare('UPDATE chats SET contact_gender = ?, contact_age = ? WHERE id = ?').run(gender, age, chatId);
  bumpChatsVersion();
  return getChat(chatId);
}

function getUserProfile() {
  const row = db.prepare("SELECT value FROM sync_meta WHERE key = 'user_profile'").get();
  try { return row ? JSON.parse(row.value || '{}') : {}; } catch (_) { return {}; }
}

function setUserProfile(profile = {}) {
  const gender = String(profile.gender || '').trim().slice(0, 30) || '';
  const ageRaw = Number(profile.age);
  const age = Number.isFinite(ageRaw) && ageRaw >= 13 && ageRaw <= 120 ? Math.round(ageRaw) : null;
  const value = JSON.stringify({ gender, age });
  db.prepare("INSERT INTO sync_meta (key,value) VALUES ('user_profile',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(value);
  return { gender, age };
}

function setChatContext(chatId, context_type, tone_note, ai_instructions) {
  db.prepare(`
    UPDATE chats SET
      context_type = ?,
      tone_note = ?,
      ai_instructions = COALESCE(?, ai_instructions)
    WHERE id = ?
  `).run(context_type || null, tone_note || null, ai_instructions == null ? null : String(ai_instructions).slice(0, 8000), chatId);
  bumpChatsVersion();
}

function setChatAIInstructions(chatId, aiInstructions) {
  db.prepare('UPDATE chats SET ai_instructions = ? WHERE id = ?')
    .run(String(aiInstructions || '').slice(0, 8000) || null, chatId);
  bumpChatsVersion();
}

function recordFeedback(entry) {
  db.prepare(`
    INSERT INTO feedback (chat_id, suggested_text, final_text, action, created_at)
    VALUES (@chat_id, @suggested_text, @final_text, @action, @created_at)
  `).run(entry);
}

function saveReport(entry) {
  const chat = getChat(entry.chat_id);
  const contactName = String(entry.contact_name || chat?.display_name || chat?.name || entry.chat_id).slice(0, 160);
  const type = String(entry.report_type || 'deep_analysis').slice(0, 40);
  const title = String(entry.title || `${type === 'text_analysis' ? 'Text Analysis' : 'Deep Analysis'} — ${contactName}`).slice(0, 200);
  const result = db.prepare(`INSERT INTO saved_reports (chat_id, contact_name, report_type, title, analysis_json, created_at) VALUES (?, ?, ?, ?, ?, ?)`).run(entry.chat_id, contactName, type, title, JSON.stringify(entry.analysis || {}), entry.created_at || Date.now());
  return { id: Number(result.lastInsertRowid), chat_id: entry.chat_id, contact_name: contactName, report_type: type, title, analysis: entry.analysis || {}, created_at: entry.created_at || Date.now() };
}

function listSavedReports(limit = 100) {
  return db.prepare('SELECT * FROM saved_reports ORDER BY created_at DESC LIMIT ?').all(Math.min(Number(limit) || 100, 500)).map(r => ({ ...r, analysis: (() => { try { return JSON.parse(r.analysis_json || '{}'); } catch (_) { return {}; } })() }));
}

function getSavedReport(id) {
  const r = db.prepare('SELECT * FROM saved_reports WHERE id = ?').get(Number(id));
  if (!r) return null;
  return { ...r, analysis: (() => { try { return JSON.parse(r.analysis_json || '{}'); } catch (_) { return {}; } })() };
}

function deleteSavedReport(id) { return db.prepare('DELETE FROM saved_reports WHERE id = ?').run(Number(id)).changes > 0; }

function recordAnalysisFeedback(entry) {
  db.prepare('INSERT INTO analysis_feedback (chat_id, kind, note, created_at) VALUES (@chat_id,@kind,@note,@created_at)').run(entry);
}

function getAnalysisFeedback(chatId, limit = 12) {
  return db.prepare('SELECT * FROM analysis_feedback WHERE chat_id = ? ORDER BY created_at DESC LIMIT ?').all(chatId, limit);
}


function recordAnalysis(entry) {
  db.prepare(`
    INSERT INTO analysis_records
      (chat_id, kind, selected_text, user_request, response_text, edited_text, analysis_json, created_at)
    VALUES (@chat_id, @kind, @selected_text, @user_request, @response_text, @edited_text, @analysis_json, @created_at)
  `).run({
    chat_id: entry.chat_id,
    kind: entry.kind || 'response',
    selected_text: entry.selected_text || '',
    user_request: entry.user_request || '',
    response_text: entry.response_text || '',
    edited_text: entry.edited_text || '',
    analysis_json: JSON.stringify(entry.analysis || {}),
    created_at: entry.created_at || Date.now()
  });
}

function listAnalyses(chatId, limit = 5000) {
  return db.prepare('SELECT * FROM analysis_records WHERE chat_id = ? ORDER BY created_at ASC LIMIT ?').all(chatId, limit)
    .map(r => ({ ...r, analysis: (() => { try { return JSON.parse(r.analysis_json || '{}'); } catch (_) { return {}; } })() }));
}

function getAnalysisSummary(chatId) {
  const rows = listAnalyses(chatId, 5000);
  return { count: rows.length, first_at: rows[0]?.created_at || null, last_at: rows.at(-1)?.created_at || null };
}

function listRecentActivity(limit = 50) {
  const n = Math.min(Math.max(Number(limit) || 50, 1), 200);
  return db.prepare(`
    SELECT * FROM (
      SELECT a.id AS id, 'analysis' AS activity_type, a.kind AS activity_kind, a.created_at,
             a.chat_id, COALESCE(NULLIF(c.custom_name,''), NULLIF(c.name,''), c.id) AS contact_name,
             a.user_request AS detail
      FROM analysis_records a JOIN chats c ON c.id = a.chat_id
      UNION ALL
      SELECT r.id AS id, 'saved_report' AS activity_type, r.report_type AS activity_kind, r.created_at,
             r.chat_id, r.contact_name, r.title AS detail
      FROM saved_reports r
    ) activity
    ORDER BY created_at DESC LIMIT ?
  `).all(n);
}

function getSyncMeta(key, fallback = null) {
  const row = db.prepare('SELECT value FROM sync_meta WHERE key = ?').get(key);
  return row ? row.value : fallback;
}

function setSyncMeta(key, value) {
  db.prepare(`
    INSERT INTO sync_meta (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(key, String(value));
}

function getChatSyncState(chatId) {
  return db.prepare('SELECT * FROM chat_sync_state WHERE chat_id = ?').get(chatId) || {
    chat_id: chatId,
    history_complete: 0,
    last_synced_at: 0,
    last_message_timestamp: 0
  };
}

function markChatSync(chatId, { complete = false, lastMessageTimestamp = 0 } = {}) {
  db.prepare(`
    INSERT INTO chat_sync_state (chat_id, history_complete, last_synced_at, last_message_timestamp)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(chat_id) DO UPDATE SET
      history_complete = MAX(chat_sync_state.history_complete, excluded.history_complete),
      last_synced_at = excluded.last_synced_at,
      last_message_timestamp = MAX(chat_sync_state.last_message_timestamp, excluded.last_message_timestamp)
  `).run(chatId, complete ? 1 : 0, Date.now(), Number(lastMessageTimestamp) || 0);
}

function isInitialSyncComplete() {
  return getSyncMeta('initial_sync_complete', '0') === '1';
}

function setInitialSyncComplete(value) {
  setSyncMeta('initial_sync_complete', value ? '1' : '0');
}

function getRecentFeedback(chatId, limit = 8) {
  return db.prepare('SELECT * FROM feedback WHERE chat_id = ? ORDER BY created_at DESC LIMIT ?').all(chatId, limit);
}

function getAryAIWorkspaceFacts() {
  const visible = listChats();
  const total = visible.reduce((n,c)=>n+Number(c.message_count||0),0);
  const mine = visible.reduce((n,c)=>n+Number(c.my_message_count||0),0);
  const groupCount = visible.filter(c=>Number(c.is_group)===1).length;
  const sync = db.prepare(`SELECT COUNT(*) AS chats, SUM(CASE WHEN history_complete=1 THEN 1 ELSE 0 END) AS complete FROM chat_sync_state WHERE chat_id IN (SELECT id FROM chats WHERE id NOT IN (SELECT chat_id FROM hidden_chats))`).get();
  const top = visible.slice().sort((a,b)=>Number(b.message_count||0)-Number(a.message_count||0)).slice(0,100).map(c=>({id:c.id,name:c.display_name||c.name||c.id,message_count:Number(c.message_count||0),my_message_count:Number(c.my_message_count||0),is_group:!!c.is_group,first_message_at:c.first_message_at||0,latest_message_at:c.latest_message_at||c.last_message_at||0,last_body:c.last_body||''}));
  return {
    conversation_count: visible.length,
    contact_count: visible.length,
    group_count: groupCount,
    total_stored_messages: total,
    messages_from_me: mine,
    messages_from_them: Math.max(0,total-mine),
    sync_chats: Number(sync?.chats||0),
    sync_complete_chats: Number(sync?.complete||0),
    conversations: top
  };
}
function searchAryAIMessages(query, limit=80) {
  const q=String(query||'').trim();
  if(!q) return [];
  const words=[...new Set(q.toLowerCase().replace(/[^a-z0-9@_'-]+/g,' ').split(/\s+/).filter(w=>w.length>=3 && !['the','and','for','what','why','how','does','this','that','with','from','have','are','you','about','conversation','messages','contact'].includes(w)))].slice(0,8);
  if(!words.length) return [];
  const clauses=words.map(()=>`LOWER(m.body) LIKE ?`).join(' OR ');
  const params=words.map(w=>`%${w}%`);
  return db.prepare(`SELECT m.*, COALESCE(NULLIF(c.custom_name,''),NULLIF(c.name,''),c.id) AS chat_name FROM messages m JOIN chats c ON c.id=m.chat_id LEFT JOIN hidden_chats h ON h.chat_id=m.chat_id WHERE h.chat_id IS NULL AND m.body IS NOT NULL AND (${clauses}) ORDER BY m.timestamp DESC LIMIT ?`).all(...params,Math.min(Math.max(Number(limit)||80,1),200));
}

// ---------------------------------------------------------------------------
// Ary AI conversations. Each "New chat" is a real, server-persisted thread —
// not just a client-side rolling memory — so it survives page reloads, works
// across tabs/devices on the same machine, and can be listed and reopened.
// ---------------------------------------------------------------------------
function titleFromMessage(text) {
  const clean = String(text || '').trim().replace(/\s+/g, ' ');
  if (!clean) return 'New conversation';
  return clean.length > 60 ? clean.slice(0, 57) + '…' : clean;
}

function createAryConversation(firstMessage = '') {
  const now = Date.now();
  const title = titleFromMessage(firstMessage);
  const result = db.prepare('INSERT INTO ary_conversations (title, created_at, updated_at) VALUES (?, ?, ?)').run(title, now, now);
  return { id: Number(result.lastInsertRowid), title, created_at: now, updated_at: now };
}

function listAryConversations(limit = 200) {
  return db.prepare(`
    SELECT c.id, c.title, c.created_at, c.updated_at,
      (SELECT COUNT(*) FROM ary_messages m WHERE m.conversation_id = c.id) AS message_count,
      (SELECT content FROM ary_messages m WHERE m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS last_message
    FROM ary_conversations c
    ORDER BY c.updated_at DESC
    LIMIT ?
  `).all(Math.min(Math.max(Number(limit) || 200, 1), 500));
}

function getAryConversation(id) {
  return db.prepare('SELECT * FROM ary_conversations WHERE id = ?').get(Number(id));
}

function getAryMessages(conversationId, limit = 400) {
  return db.prepare('SELECT * FROM ary_messages WHERE conversation_id = ? ORDER BY created_at ASC LIMIT ?')
    .all(Number(conversationId), Math.min(Math.max(Number(limit) || 400, 1), 2000));
}

function appendAryMessage(conversationId, role, content) {
  const id = Number(conversationId);
  const now = Date.now();
  const text = String(content || '');
  db.prepare('INSERT INTO ary_messages (conversation_id, role, content, created_at) VALUES (?, ?, ?, ?)').run(id, role === 'assistant' ? 'assistant' : 'user', text, now);
  // Auto-title a conversation from its first user message instead of leaving
  // every thread in the list labeled "New conversation".
  const convo = getAryConversation(id);
  if (convo && role === 'user' && (!convo.title || convo.title === 'New conversation')) {
    db.prepare('UPDATE ary_conversations SET title = ?, updated_at = ? WHERE id = ?').run(titleFromMessage(text), now, id);
  } else {
    db.prepare('UPDATE ary_conversations SET updated_at = ? WHERE id = ?').run(now, id);
  }
  return { conversation_id: id, role, content: text, created_at: now };
}

function renameAryConversation(id, title) {
  const clean = String(title || '').trim().slice(0, 120) || 'New conversation';
  db.prepare('UPDATE ary_conversations SET title = ?, updated_at = ? WHERE id = ?').run(clean, Date.now(), Number(id));
  return getAryConversation(id);
}

function deleteAryConversation(id) {
  const cid = Number(id);
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM ary_messages WHERE conversation_id = ?').run(cid);
    db.prepare('DELETE FROM ary_conversations WHERE id = ?').run(cid);
  });
  tx();
  return true;
}

module.exports = {
  db, upsertChat, upsertContact, listContacts, insertMessage, listChats, isChatHidden, hideChatFromAlgorithm, getMessages, getAllMessages,
  getMyPastMessages, getMyGlobalStyleSamples, recordFeedback, getRecentFeedback,
  getChat, setChatContext, setChatAIInstructions, setChatCustomName, setChatProfile, getUserProfile, setUserProfile, recordAnalysisFeedback, getAnalysisFeedback, recordAnalysis, listAnalyses, getAnalysisSummary, listRecentActivity, saveReport, listSavedReports, getSavedReport, deleteSavedReport,
  getSyncMeta, setSyncMeta, getChatSyncState, markChatSync, isInitialSyncComplete, setInitialSyncComplete, getAryAIWorkspaceFacts, searchAryAIMessages,
  createAryConversation, listAryConversations, getAryConversation, getAryMessages, appendAryMessage, renameAryConversation, deleteAryConversation
};
