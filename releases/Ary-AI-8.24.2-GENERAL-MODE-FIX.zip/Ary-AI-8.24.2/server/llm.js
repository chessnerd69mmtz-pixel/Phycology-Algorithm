// llm.js — evidence-aware local AI for reply generation and conversation analysis.
// It deliberately separates observations from interpretations. Every confidence
// percentage the model returns must be backed by a verbatim quote copied from the
// actual conversation text, so the person reading the analysis can check the claim
// against the real message rather than trusting a bare number.
const {
  getMessages, getAllMessages, getMyPastMessages, getMyGlobalStyleSamples, getRecentFeedback,
  listChats, getChat, isChatHidden, setChatContext, getAnalysisFeedback, getUserProfile
} = require('./db');
const { scoreChat, priorityTier } = require('./stats');


// --- Cloud provider support -------------------------------------------------
// Keys are loaded from a local .env file. Never expose them to public/app.js.
const fs = require('fs');
const path = require('path');
function loadLocalEnv(){
  try {
    const envPath=path.join(__dirname,'..','.env');
    if(!fs.existsSync(envPath)) return;
    for(const raw of fs.readFileSync(envPath,'utf8').split(/\r?\n/)){
      const line=raw.trim();
      if(!line || line.startsWith('#')) continue;
      const i=line.indexOf('='); if(i<1) continue;
      const k=line.slice(0,i).trim();
      let v=line.slice(i+1).trim();
      if((v.startsWith('"')&&v.endsWith('"'))||(v.startsWith("'")&&v.endsWith("'"))) v=v.slice(1,-1);
      if(!process.env[k]) process.env[k]=v;
    }
  } catch(e){ console.warn('Could not read local .env:',e.message); }
}
loadLocalEnv();

const AI_PROVIDER = String(process.env.AI_PROVIDER || 'auto').toLowerCase();
const MISTRAL_API_KEY = String(process.env.MISTRAL_API_KEY || '').trim();
const MISTRAL_MODEL = process.env.MISTRAL_MODEL || 'mistral-small-latest';
const GROQ_API_KEY = String(process.env.GROQ_API_KEY || '').trim();
const GROQ_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const MISTRAL_TIMEOUT_MS = Math.max(15000, Number(process.env.MISTRAL_TIMEOUT_MS)||90000);
const GROQ_TIMEOUT_MS = Math.max(15000, Number(process.env.GROQ_TIMEOUT_MS)||90000);

async function callCloudChat(url, key, model, messages, {timeoutMs=90000,signal=null,temperature=0.2,json=false}={}){
  if(!key) throw new Error('AI_PROVIDER_KEY_MISSING');
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),timeoutMs);
  const onAbort=()=>controller.abort();
  if(signal) signal.addEventListener('abort',onAbort,{once:true});
  try{
    const body={model,messages,temperature};
    if(json) body.response_format={type:'json_object'};
    const res=await fetch(url,{method:'POST',headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify(body),signal:controller.signal});
    const text=await res.text();
    if(!res.ok) throw new Error(`CLOUD_PROVIDER_HTTP_${res.status}: ${text.slice(0,500)}`);
    const data=JSON.parse(text);
    const content=data?.choices?.[0]?.message?.content;
    if(!content) throw new Error('CLOUD_PROVIDER_EMPTY_RESPONSE');
    return String(content);
  }catch(e){
    if(e?.name==='AbortError') throw new Error('CLOUD_PROVIDER_TIMEOUT');
    throw e;
  }finally{
    clearTimeout(timer);
    if(signal) signal.removeEventListener('abort',onAbort);
  }
}

async function callMistral(messages, options={}){
  return callCloudChat('https://api.mistral.ai/v1/chat/completions',MISTRAL_API_KEY,MISTRAL_MODEL,messages,{...options,timeoutMs:MISTRAL_TIMEOUT_MS});
}
async function callGroq(messages, options={}){
  return callCloudChat('https://api.groq.com/openai/v1/chat/completions',GROQ_API_KEY,GROQ_MODEL,messages,{...options,timeoutMs:GROQ_TIMEOUT_MS});
}
function providerStatus(){
  return {
    selected:AI_PROVIDER,
    unlimitless_configured:Boolean(process.env.UNLIMITLESS_API_KEY),
    mistral_configured:Boolean(MISTRAL_API_KEY),
    groq_configured:Boolean(GROQ_API_KEY),
    mistral_model:MISTRAL_MODEL,
    groq_model:GROQ_MODEL
  };
}

async function callAryCloud(messages,{signal=null,temperature=0.2,json=false}={}){
  const order=[];
  // Unlimitless is currently an MCP/context platform, not a documented
  // chat-completion endpoint. We therefore record its key for future/context
  // integration but do not invent a completion API. Mistral and Groq are the
  // actual generation providers in this build.
  if(AI_PROVIDER==='mistral') order.push(['mistral']);
  else if(AI_PROVIDER==='groq') order.push(['groq']);
  else order.push(['mistral'],['groq']);
  let last=null;
  for(const [name] of order){
    try{
      const text=name==='mistral' ? await callMistral(messages,{signal,temperature,json}) : await callGroq(messages,{signal,temperature,json});
      return {text,provider:name,model:name==='mistral'?MISTRAL_MODEL:GROQ_MODEL};
    }catch(e){
      last=e;
      if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
      console.warn(`Ary AI ${name} provider unavailable; trying next provider:`,e.message);
    }
  }
  throw last || new Error('NO_CLOUD_PROVIDER_AVAILABLE');
}

const TONE_PROFILES = {
  partner: { label: 'Partner', style: 'Warm, attentive, natural, affectionate when supported by the conversation. Never force intimacy.' },
  academic: { label: 'Academic', style: 'Clear, precise, respectful, appropriately formal, and complete.' },
  professional: { label: 'Professional / serious', style: 'Concise, confident, polite, direct, and controlled.' },
  fun: { label: 'Fun / casual', style: 'Relaxed, playful, concise, and matched to the other person’s energy.' },
  general: { label: 'General', style: 'Match the user’s demonstrated texting style without forcing a persona.' }
};
const VALID_CONTEXTS = Object.keys(TONE_PROFILES);
const TONE_OPTIONS = [
  { id: 'warm', label: 'Warm', description: 'Kind, caring, welcoming, or emotionally supportive.' },
  { id: 'affectionate', label: 'Affectionate', description: 'Fond, tender, caring, or openly attached.' },
  { id: 'friendly', label: 'Friendly', description: 'Approachable, cooperative, sociable, and positive.' },
  { id: 'playful', label: 'Playful', description: 'Light teasing, joking, mischievous, or energetic.' },
  { id: 'humorous', label: 'Humorous', description: 'Primarily trying to amuse or make the exchange lighter.' },
  { id: 'sarcastic', label: 'Sarcastic', description: 'Meaning is partly conveyed through irony, reversal, or pointed wit.' },
  { id: 'flirty', label: 'Flirty', description: 'Romantic or suggestive playfulness supported by context.' },
  { id: 'casual', label: 'Casual', description: 'Relaxed, everyday, low-formality conversation.' },
  { id: 'curious', label: 'Curious', description: 'Seeking information, clarification, or engagement.' },
  { id: 'enthusiastic', label: 'Enthusiastic', description: 'High positive energy, eagerness, or strong interest.' },
  { id: 'excited', label: 'Excited', description: 'Strong anticipation, celebration, or heightened positive energy.' },
  { id: 'confident', label: 'Confident', description: 'Self-assured, decisive, and comfortable in its position.' },
  { id: 'direct', label: 'Direct', description: 'Clear, explicit, and low-ambiguity communication.' },
  { id: 'professional', label: 'Professional', description: 'Work-oriented, polished, restrained, or businesslike.' },
  { id: 'formal', label: 'Formal', description: 'Structured, ceremonious, or deliberately high-formality.' },
  { id: 'serious', label: 'Serious', description: 'Focused, weighty, or dealing with an important matter.' },
  { id: 'reassuring', label: 'Reassuring', description: 'Reducing uncertainty, offering comfort, or signaling safety.' },
  { id: 'concerned', label: 'Concerned', description: 'Expressing worry, caution, care, or attention to a problem.' },
  { id: 'frustrated', label: 'Frustrated', description: 'Showing irritation, dissatisfaction, impatience, or blocked intent.' },
  { id: 'neutral', label: 'Neutral / matter-of-fact', description: 'Informational and emotionally unmarked; use only when stronger signals are absent.' }
];
const TONE_BY_ID = Object.fromEntries(TONE_OPTIONS.map(t => [t.id, t]));
const TONE_LABELS = TONE_OPTIONS.map(t => t.label);
const TONE_GUIDANCE = TONE_OPTIONS.map(t => `- ${t.label}: ${t.description}`).join('\n');

const PSYCHOLOGY_LENSES = [
  ['Attribution & ambiguity','Separate observable wording from explanations of why it was said; keep multiple interpretations when intent is unclear.'],
  ['Face-saving & face threat','Look for language protecting dignity, autonomy, competence, or social image; avoid escalating threats to these.'],
  ['Reciprocity & conversational repair','Notice apologies, acknowledgements, connection bids, repairs after misunderstandings, and reciprocal effort.'],
  ['Uncertainty reduction','Identify unanswered questions, ambiguity, reassurance-seeking, clarification, and opportunities for concrete answers.'],
  ['Emotional signaling','Use observable intensity, wording, punctuation, repetition, timing, and emoji patterns as signals, not proof of internal emotion.'],
  ['Conflict & de-escalation','Identify criticism, defensiveness, contempt-like wording, escalation, boundaries, validation, and repair opportunities without diagnosing.'],
  ['Politeness & indirectness','Consider hedges, softeners, directness, implied refusals, requests, and politeness strategies.'],
  ['Sarcasm & incongruity','Test literal meaning against context, exaggeration, reversal, absurdity, punctuation, emojis, and shared style.'],
  ['Humor & play','Distinguish humour from sarcasm; look for teasing, callbacks, wordplay, absurdity, laughter markers, and mutual participation.'],
  ['Cognitive load & clarity','Notice complexity, missing context, multiple topics, and wording that may affect comprehension.'],
  ['Temporal/context effects','Use timestamps and sequence to interpret relative time, delays, rapid exchanges, and tone shifts.']
];
const PSYCHOLOGY_FRAMEWORK_TEXT = PSYCHOLOGY_LENSES.map(x => `- ${x[0]}: ${x[1]}`).join('\n');

const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'llama3.2';
// Analyze + draft stays on the tight 4-minute SLA (one bounded call on the send path).
const OLLAMA_TIMEOUT_MS = Math.max(15000, Number(process.env.OLLAMA_TIMEOUT_MS) || 240000);
// Ary AI has its own hard SLA. Generic Ary AI gets a full 3-minute total
// response window so the laptop-friendly local model has time to reason. The
// server reserves part of that window for a compact recovery answer, ensuring
// a generic request still receives a useful response if the primary generation
// times out or Ollama is unavailable.
const OLLAMA_ARY_GENERIC_TIMEOUT_MS = Math.min(180000, Math.max(60000, Number(process.env.OLLAMA_ARY_GENERIC_TIMEOUT_MS) || 180000));
// Generic Ary AI intentionally stays on the same laptop-friendly llama3.2 model
// family as the main analysis path; it does not silently switch to llama3.1/larger models.
const OLLAMA_ARY_GENERIC_MODEL = process.env.OLLAMA_ARY_GENERIC_MODEL || 'llama3.2';
const OLLAMA_ARY_GENERIC_NUM_PREDICT = Math.max(96, Math.min(220, Number(process.env.OLLAMA_ARY_GENERIC_NUM_PREDICT) || 180));
const OLLAMA_ARY_GENERIC_NUM_CTX = Math.max(1024, Math.min(2048, Number(process.env.OLLAMA_ARY_GENERIC_NUM_CTX) || 1536));
const OLLAMA_ARY_WHATSAPP_TIMEOUT_MS = Math.min(295000, Math.max(60000, Number(process.env.OLLAMA_ARY_WHATSAPP_TIMEOUT_MS) || 295000));
// Backwards-compatible export/name: generic Ary AI uses its own bounded SLA.
const OLLAMA_ARY_TIMEOUT_MS = OLLAMA_ARY_GENERIC_TIMEOUT_MS;
// Analyze-selected-text is a deliberate, user-initiated deep read of a passage,
// not on the send path, so it gets a longer 15-minute budget instead.
// Deep analysis is chunked. This is the TOTAL request budget; individual Ollama calls are much shorter.
const OLLAMA_SELECTION_TIMEOUT_MS = Math.max(600000, Number(process.env.OLLAMA_SELECTION_TIMEOUT_MS) || 900000); // 15 min hard ceiling
// Manual Text Analysis has its own 120-second budget. This is intentionally
// separate from WhatsApp selection/deep-analysis timing so changing this mode
// does not alter the other analysis modes.
const OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS = Math.min(120000, Math.max(30000, Number(process.env.OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS) || 120000));
// Batch sizing directly trades off round trips vs. per-call cost: every batch
// re-sends the same ~1.5-2K tokens of fixed instructions before it ever gets
// to the actual conversation content, so on a long chat that fixed cost gets
// paid once per batch. Larger batches mean fewer batches, which means that
// fixed cost is paid fewer times for the same total amount of content — this
// is the single biggest lever available without touching model choice or
// timeouts. numCtx is bumped alongside it (see OLLAMA_BATCH_NUM_CTX) so the
// larger prompt + its reserved output space still comfortably fits in one
// context window instead of risking truncation.
const OLLAMA_BATCH_TIMEOUT_MS = Math.max(20000, Number(process.env.OLLAMA_BATCH_TIMEOUT_MS) || 55000);
const OLLAMA_BATCH_RETRY_TIMEOUT_MS = Math.max(15000, Number(process.env.OLLAMA_BATCH_RETRY_TIMEOUT_MS) || 38000);
const OLLAMA_BATCH_CHARS = Math.max(6000, Number(process.env.OLLAMA_BATCH_CHARS) || 14000);
const OLLAMA_MAX_BATCHES = Math.max(2, Number(process.env.OLLAMA_MAX_BATCHES) || 24);
// Message-count is the primary workload unit. Character limits remain only as
// a model-context safety guard, never as a reason to silently drop messages.
const OLLAMA_BATCH_MESSAGES = Math.max(25, Number(process.env.OLLAMA_BATCH_MESSAGES) || 280);
// Context window used for every batch/synthesis call. Sized to comfortably
// hold the larger batch text above plus its fixed instructions plus its full
// reserved output (numPredict) with headroom, so raising batch size never
// risks silently truncating a batch.
const OLLAMA_BATCH_NUM_CTX = Math.max(8192, Number(process.env.OLLAMA_BATCH_NUM_CTX) || 12288);
const MAX_TRANSCRIPT_MESSAGES = Math.max(12, Number(process.env.MAX_TRANSCRIPT_MESSAGES) || 28);
const MAX_ANALYSIS_TEXTS = 5000;
const MAX_ANALYSIS_MESSAGES = MAX_ANALYSIS_TEXTS; // backwards-compatible name; workload is counted in messages/texts, never words.

// Shared instruction fragment: every JSON schema below embeds "quote" fields.
// This text tells the model exactly what those fields mean so it doesn't
// paraphrase or invent a line that never appeared in the conversation.
const QUOTE_RULE = `EVIDENCE RULE (applies to every "quote" field and every percentage/confidence number below):
- A "quote" must be copied EXACTLY, character-for-character, from the RECENT CONVERSATION or SELECTED TEXT provided to you. Never invent, paraphrase, or combine wording into a quote.
- Prefer short quotes (a few words to one sentence) that most directly support the point.
- If you genuinely cannot find a real quote that supports a percentage/claim, lower the percentage instead of inventing a quote, and leave "quote" as an empty string.
- Every percentage (0-100) is your estimated confidence that the interpretation is correct given ONLY the quoted text — not a claim about anyone's inner state.`;

async function callOllama(prompt, { json = false, temperature = 0.45, timeoutMs = OLLAMA_TIMEOUT_MS, signal = null, numPredict = null, numCtx = 8192, model = OLLAMA_MODEL } = {}) {
  const timeoutSignal = AbortSignal.timeout(timeoutMs);
  const combinedSignal = signal ? AbortSignal.any([timeoutSignal, signal]) : timeoutSignal;
  let res;
  try {
    res = await fetch(`${OLLAMA_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model,
        prompt,
        stream: false,
        keep_alive: '30m',
        ...(json ? { format: 'json' } : {}),
        options: { temperature, num_predict: Number.isFinite(numPredict) ? numPredict : (json ? 2800 : 400), num_ctx: numCtx, top_p: 0.9, repeat_penalty: 1.08 }
      }),
      signal: combinedSignal
    });
  } catch (err) {
    // A user-triggered Stop aborts the same combined signal a timeout would,
    // so tell them apart by which one actually fired.
    if (signal?.aborted) {
      throw new Error('CANCELLED_BY_USER');
    }
    if (err?.name === 'TimeoutError' || err?.name === 'AbortError' || /timeout|aborted/i.test(String(err?.message || ''))) {
      throw new Error(`OLLAMA_TIMEOUT after ${timeoutMs}ms`);
    }
    throw new Error(`Could not reach Ollama at ${OLLAMA_URL}. Make sure Ollama is running. ${err.message}`);
  }
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Ollama request failed (${res.status}): ${text || 'unknown error'}. Model: ${model}`);
  }
  const data = await res.json();
  return data.response || '';
}

// Both checks below hit Ollama's /api/tags endpoint purely to answer "is it
// up" and "what's installed" — neither changes turn to turn in a normal
// session, so re-checking on every single analysis or Ary AI question is a
// network round trip paid for no reason. Cache each with a short TTL: long
// enough to skip the redundant check on back-to-back requests (the common
// case — someone asking several Ary AI questions in a row, or opening Deep
// Analysis right after a previous one), short enough that Ollama actually
// going down or a newly-pulled model still gets picked up quickly.
let _ollamaReadyUntil = 0;
let _aryModelCache = { value: null, until: 0 };
const OLLAMA_READY_CACHE_MS = 20000;
const ARY_MODEL_CACHE_MS = 300000;

async function ollamaReady(signal=null) {
  if (Date.now() < _ollamaReadyUntil) return true;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 4000);
  const combined = signal ? AbortSignal.any([controller.signal, signal]) : controller.signal;
  try {
    const res = await fetch(`${OLLAMA_URL}/api/tags`, { signal: combined });
    if (!res.ok) throw new Error(`Ollama health check returned HTTP ${res.status}.`);
    _ollamaReadyUntil = Date.now() + OLLAMA_READY_CACHE_MS;
    return true;
  } catch (err) {
    if (signal?.aborted) throw new Error('CANCELLED_BY_USER');
    throw new Error(`OLLAMA_UNAVAILABLE: Could not reach Ollama at ${OLLAMA_URL}. Start Ollama and try again.`);
  } finally { clearTimeout(timer); }
}

async function pickAryGenericModel(signal=null) {
  if (_aryModelCache.value && Date.now() < _aryModelCache.until) return _aryModelCache.value;
  try {
    const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),2000);
    const combined=signal ? AbortSignal.any([controller.signal,signal]) : controller.signal;
    const res=await fetch(`${OLLAMA_URL}/api/tags`,{signal:combined});
    clearTimeout(timer);
    if(!res.ok) return OLLAMA_MODEL;
    const data=await res.json();
    const names=(Array.isArray(data.models)?data.models:[]).map(x=>String(x.name||''));
    const picked = names.some(n=>n===OLLAMA_ARY_GENERIC_MODEL || n.startsWith(`${OLLAMA_ARY_GENERIC_MODEL}:`)) ? OLLAMA_ARY_GENERIC_MODEL : OLLAMA_MODEL;
    _aryModelCache = { value: picked, until: Date.now() + ARY_MODEL_CACHE_MS };
    return picked;
  } catch(e) {
    if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
    return OLLAMA_MODEL;
  }
}

function cleanJson(text) {
  try { return JSON.parse(text); } catch (_) {}
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start >= 0 && end > start) {
    try { return JSON.parse(text.slice(start, end + 1)); } catch (_) {}
  }
  return null;
}

async function classifyChatContext(chatId) {
  const recent = getMessages(chatId, MAX_TRANSCRIPT_MESSAGES);
  if (recent.length < 3) return 'general';
  const transcript = recent.map(m => `${m.from_me ? 'ME' : 'THEM'}: ${m.body}`).join('\n');
  const prompt = `Classify this WhatsApp conversation into exactly one category: partner, academic, professional, fun, general.\n\n${transcript}\n\nReturn only the category.`;
  const response = await callOllama(prompt, { temperature: 0.1 });
  const cleaned = response.trim().toLowerCase().replace(/[^a-z]/g, '');
  const context = VALID_CONTEXTS.find(c => cleaned.includes(c)) || 'general';
  setChatContext(chatId, context, null, null);
  return context;
}

function buildVoice(chatId) {
  const mine = getMyPastMessages(chatId, 16);
  const global = mine.length < 4 ? getMyGlobalStyleSamples(16) : [];
  return [...mine, ...global].slice(-18).map(t => `- ${JSON.stringify(t)}`).join('\n') || '(not enough examples yet)';
}

function buildFeedback(chatId) {
  const feedback = getRecentFeedback(chatId, 8);
  return feedback.length
    ? feedback.map(f => `- ${f.action}: suggested=${JSON.stringify(f.suggested_text)} final=${JSON.stringify(f.final_text || '')}`).join('\n')
    : '(no previous feedback)';
}

function analysisDefaults(requested = {}) {
  return {
    draft: requested.draft !== false,
    psychology: requested.psychology !== false,
    attitude: requested.attitude !== false,
    intent: requested.intent !== false,
    evidence: requested.evidence !== false,
    signals: requested.signals !== false,
    risks: requested.risks !== false,
    strategy: requested.strategy !== false,
    alternatives: requested.alternatives !== false
  };
}

// ---- percentage + verbatim-quote normalization helpers ----------------------

function clampPercent(value, fallback = 50) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(0, Math.min(100, Math.round(n)));
}

function percentLabel(pct) {
  if (pct >= 71) return 'high';
  if (pct >= 40) return 'moderate';
  return 'low';
}

// ---- guaranteeing every quote is a real example taken directly from the chat ----

function normalizeWs(s) { return String(s || '').toLowerCase().replace(/\s+/g, ' ').trim(); }

// Builds the lookup context (once per request) used to verify or repair quotes:
// the whole source text normalized for substring checks, plus it split into
// individual message lines so a bad/missing quote can be swapped for a real one.
function buildQuoteContext(sourceText) {
  const raw = String(sourceText || '');
  const haystackNorm = normalizeWs(raw);
  const lines = raw
    .split(/\r?\n/)
    .map(l => l.replace(/^(ME|THEM)\s*(\[[^\]]*\])?:\s*/i, '').trim())
    .filter(l => l.length > 1);
  return { raw, haystackNorm, lines };
}

function quoteExistsIn(quote, sourceTextOrContext) {
  const q = String(quote || '').trim();
  if (q.length < 3) return false;
  // Evidence must be copied exactly. Whitespace-normalized matching is useful
  // for retrieval, but it is not strict enough for a displayed quotation.
  const raw = typeof sourceTextOrContext === 'string'
    ? sourceTextOrContext
    : String(sourceTextOrContext?.raw || '');
  if (raw.includes(q)) return true;
  const lines = typeof sourceTextOrContext === 'object' && Array.isArray(sourceTextOrContext?.lines)
    ? sourceTextOrContext.lines
    : raw.split(/\r?\n/);
  return lines.some(line => String(line || '').includes(q));
}

// Picks the message line most relevant to a claim, by simple word overlap,
// so a repaired quote is at least topically tied to what it's backing.
function bestMatchingLine(lines, referenceText) {
  if (!lines.length) return '';
  const stop = new Set(['the','and','that','this','with','from','they','them','their','there','have','has','had','you','your','are','was','were','for','but','not','too','very','just','what','when','where','why','how','into','about','then','than','can','could','would','should','will','shall','may','might']);
  const refWords = normalizeWs(referenceText).split(' ').filter(w => w.length > 2 && !stop.has(w));
  if (!refWords.length) return '';
  let best = '', bestScore = 0;
  for (const line of lines) {
    const lineWords = new Set(normalizeWs(line).split(' '));
    let score = 0;
    for (const w of refWords) if (lineWords.has(w)) score++;
    if (score > bestScore) { bestScore = score; best = line; }
  }
  return bestScore > 0 ? best : '';
}

// Turns a raw {quote, percent, ...extra} object from the model into a clean,
// display-ready evidence unit. `extraFields` lists additional string fields to
// carry through (e.g. "principle", "interpretation", "explanation").
// `quoteCtx` (from buildQuoteContext) is optional; when present, any quote that
// isn't a real substring of the source conversation is swapped for the closest
// real message line, so every percentage always ships with a genuine example.
function normalizeEvidenceItem(raw, extraFields = [], quoteCtx = null, defaults = {}) {
  const source = raw && typeof raw === 'object' ? raw : {};
  let quote = String(source.quote || '').trim().slice(0, 400);
  const modelPercent = clampPercent(source.percent ?? source.confidence_percent, 0);
  let example_verified = true;
  if (quoteCtx) {
    example_verified = quoteExistsIn(quote, quoteCtx);
    if (!example_verified) {
      // If the model supplied an invented/paraphrased quote, repair it with an
      // exact source line tied to the claim instead of displaying fake evidence.
      const repaired = bestMatchingLine(quoteCtx.lines, [source.point, source.justification, source.interpretation, source.explanation, source.summary, source.conclusion, source.cue].filter(Boolean).join(' '));
      quote = repaired ? repaired.slice(0, 400) : '';
      example_verified = !!quote;
    }
  } else if (!quote) example_verified = false;
  const safePercent = example_verified ? modelPercent : 0;
  const item = {
    quote,
    percent: safePercent,
    label: percentLabel(safePercent),
    has_quote: quote.length > 0,
    example_verified,
    principle: String(source.principle || defaults.principle || 'Direct textual evidence — no psychological principle applied.').trim().slice(0, 240)
  };
  for (const key of extraFields) item[key] = String(source[key] || '').trim().slice(0, 700);
  if (typeof source.detected === 'boolean') item.detected = source.detected;
  if (typeof source.observed === 'boolean') item.observed = source.observed;
  if (typeof source.contradicts === 'boolean') item.contradicts = source.contradicts;
  if (source.evidence_type) item.evidence_type = String(source.evidence_type).toLowerCase()==='indirect'?'indirect':'direct';
  if (source.cue) item.cue = String(source.cue).trim().slice(0,500);
  if (source.previous_quote) item.previous_quote = String(source.previous_quote).trim().slice(0,400);
  if (source.change) item.change = String(source.change).trim().slice(0,500);
  return item;
}

function normalizeEvidenceList(raw, extraFields = [], max = 8, quoteCtx = null, defaults = {}) {
  const arr = Array.isArray(raw) ? raw : [];
  return arr.slice(0, max).map(x => normalizeEvidenceItem(x, extraFields, quoteCtx, defaults));
}

function normalizeSignals(data, quoteCtx = null) {
  const source = data || {};
  const result = {};
  for (const key of ['sarcasm', 'humor', 'warmth', 'frustration', 'formality']) {
    result[key] = normalizeEvidenceItem(source[key], ['explanation'], quoteCtx, { principle: 'Emotional signaling / linguistic incongruity' });
  }
  return result;
}

// ---------------------------------------------------------------------------
// Deterministic message-level analysis. This is deliberately richer than a
// single keyword classifier: every message gets a 20-dimensional tone vector,
// observable signal flags, and a recency-aware contribution. Llama is then
// asked to interpret these measurements rather than rediscovering them from
// scratch. This is especially helpful with a 3B local model.
// ---------------------------------------------------------------------------
function toneVector(body = '') {
  const t = String(body || '');
  const low = t.toLowerCase();
  const scores = Object.fromEntries(TONE_OPTIONS.map(x => [x.id, 0]));
  const add = (id, n) => { scores[id] = Math.min(100, (scores[id] || 0) + n); };
  const ex = (t.match(/!/g) || []).length;
  const q = (t.match(/\?/g) || []).length;
  const laugh = /(\blol\b|\blmao\b|\bhaha+\b|😂|🤣|😭|💀|\brofl\b)/i.test(t);
  const affection = /(❤️|❤|🥰|😍|😘|love you|miss you|proud of you|take care|appreciate you|xoxo)/i.test(t);
  const warm = /(thanks|thank you|appreciate|glad to hear|good to hear|😊|🙂|🤝|great to hear)/i.test(t);
  const sarcasm = /(yeah right|sure\.\.\.|great\.\.\.|wow\.\.\.|obviously|as if|nice one|thanks for nothing|love that for you|of course you did)/i.test(low)
    || (/\b(sure|great|amazing|perfect)\b/i.test(t) && /🙄|😒|🙂/.test(t));
  const playful = /(tease|kidding|joking|😉|😜|😏|😂|🤣)/i.test(t);
  const flirty = /(😉|😏|😜|😘|cute|hot|date me|miss me\?|you look)/i.test(t);
  const curious = q > 0 || /\b(why|how|what|when|where|which|could you explain|curious)\b/i.test(t);
  const enthusiastic = /!{2,}|can't wait|so excited|amazing|awesome|let's go|yay|woo+|🎉|🥳|🤩/i.test(t);
  const excited = /!!!|can't wait|so excited|finally|omg|oh my god|let's go|🎉|🥳|🤩/i.test(t);
  const reassuring = /(don't worry|no worries|it's okay|you'll be fine|i've got you|we can handle|all good|we're okay)/i.test(t);
  const concerned = /(worried|concerned|careful|be careful|are you okay|hope you're okay|risk|danger|concern)/i.test(low);
  const frustrated = /(annoyed|annoying|whatever|seriously|ffs|wtf|ugh|stop|not again|leave it|forget it|frustrat|why would you)/i.test(low) || /!{2,}/.test(t);
  const direct = /^(please )?(send|tell|let|give|do|stop|call|come|check|confirm|use|choose|answer)\b/i.test(low) || /\b(can you|please)\b/i.test(low);
  const professional = /(meeting|project|work|client|deadline|schedule|report|team|office|regards|available at|invoice|proposal)/i.test(low);
  const formal = /(dear |kindly |sincerely|would you be so kind|i would like to|please note|furthermore|therefore)/i.test(low);
  const serious = /(important|need to talk|seriously|deadline|urgent|problem|issue|apolog|sorry|decision|safety)/i.test(low);
  const confident = /\b(i know|i'll|i can|definitely|absolutely|we should|do this|i'm sure)\b/i.test(t) && q === 0;
  const friendly = /\b(hey|hi|how are you|sounds good|sure|cool|nice|thanks)\b/i.test(t);
  const casual = /\b(lol|haha|sure|okay|ok|yeah|yep|nah|btw|idk|gonna|wanna)\b/i.test(t) && t.length < 220;
  if (affection) add('affectionate', 72);
  if (warm) add('warm', 58);
  if (friendly) add('friendly', 48);
  if (playful) add('playful', 65);
  if (laugh) add('humorous', 78);
  if (sarcasm) add('sarcastic', 82);
  if (flirty) add('flirty', 76);
  if (casual) add('casual', 52);
  if (curious) add('curious', 62);
  if (enthusiastic) add('enthusiastic', 72);
  if (excited) add('excited', 80);
  if (confident) add('confident', 60);
  if (direct) add('direct', 66);
  if (professional) add('professional', 58);
  if (formal) add('formal', 78);
  if (serious) add('serious', 70);
  if (reassuring) add('reassuring', 75);
  if (concerned) add('concerned', 74);
  if (frustrated) add('frustrated', 80);
  if (!Object.entries(scores).some(([k,v]) => k !== 'neutral' && v > 0)) add('neutral', 72);
  // Prevent topic words from hijacking tone: work vocabulary is weaker than
  // explicit emotional/language markers, and formal/professional are separate.
  if (professional && !formal) scores.professional = Math.min(scores.professional, 62);
  if (sarcasm) { scores.friendly = Math.min(scores.friendly, 35); scores.enthusiastic = Math.min(scores.enthusiastic, 45); }
  return scores;
}

function extractTextSignals(body = '') {
  const scores = toneVector(body);
  const ranked = Object.entries(scores).sort((a,b) => b[1] - a[1]);
  return ranked.filter(([,v]) => v > 0).slice(0, 8).map(([tone, strength]) => ({
    tone,
    strength: Math.round(strength / 10),
    score: strength,
    reason: `${TONE_BY_ID[tone]?.label || tone} signal`
  }));
}

function messageAnalysis(m, index = 0, total = 1) {
  const body = String(m.body || '').trim();
  const scores = toneVector(body);
  const ranked = Object.entries(scores).sort((a,b) => b[1] - a[1]);
  const dominant = ranked[0]?.[0] || 'neutral';
  const age = Math.max(0, total - 1 - index);
  const recencyWeight = age === 0 ? 0.45 : age === 1 ? 0.20 : age === 2 ? 0.12 : age === 3 ? 0.08 : 0.15 / Math.max(1, total - 4);
  return {
    index: index + 1,
    speaker: m.from_me ? 'ME' : 'THEM',
    timestamp: m.timestamp ? new Date(m.timestamp).toISOString() : '',
    text: body,
    tone_scores: scores,
    dominant_tone: dominant,
    recency_weight: Number(recencyWeight.toFixed(4)),
    question_count: (body.match(/\?/g) || []).length,
    exclamation_count: (body.match(/!/g) || []).length,
    word_count: body ? body.split(/\s+/).length : 0,
    signals: extractTextSignals(body).slice(0, 6)
  };
}

function aggregateToneScores(messages = []) {
  const rows = messages.map((m,i) => messageAnalysis(m,i,messages.length));
  const totals = Object.fromEntries(TONE_OPTIONS.map(x => [x.id, 0]));
  for (const row of rows) for (const [tone, score] of Object.entries(row.tone_scores)) totals[tone] += score * row.recency_weight;
  const ranked = Object.entries(totals).sort((a,b) => b[1]-a[1]);
  const max = Math.max(...Object.values(totals), 1);
  const normalized = Object.fromEntries(Object.entries(totals).map(([k,v]) => [k, Math.round(v / max * 100)]));
  return { rows, scores: normalized, ranked: ranked.slice(0, 6).map(([id,score]) => ({id,label:TONE_BY_ID[id]?.label || id,score:Math.round(score)})) };
}

function buildContactBaseline(chatId) {
  const history = getMessages(chatId, 220);
  const them = history.filter(m => !m.from_me);
  if (!them.length) return { sample_size: 0, tone_scores: {}, typical_length: 0, typical_questions: 0, note: 'Not enough contact history for a personal baseline.' };
  const aggregate = aggregateToneScores(them);
  const lengths = them.map(m => String(m.body || '').trim().split(/\s+/).filter(Boolean).length);
  const questions = them.map(m => (String(m.body || '').match(/\?/g)||[]).length);
  const avg = a => a.reduce((x,y)=>x+y,0)/Math.max(1,a.length);
  return {
    sample_size: them.length,
    tone_scores: aggregate.scores,
    typical_length: Math.round(avg(lengths)),
    typical_questions: Number(avg(questions).toFixed(1)),
    dominant_tones: aggregate.ranked.slice(0,4)
  };
}

function summarizeHeuristicSignals(messages) {
  const aggregate = aggregateToneScores(messages);
  return aggregate.ranked.slice(0, 8).map(x => `${x.label}=${x.score}`).join(', ') || 'no strong lexical signal';
}

function normalizeTimestamp(ts) {
  const n = Number(ts) || 0;
  return n > 0 && n < 100000000000 ? n * 1000 : n;
}

// Split a conversation into calendar-day blocks using the computer's local
// timezone. Each block is independently analyzable, while newer days receive
// more weight than older days. This prevents a long old conversation from
// washing out what happened most recently.
function localDayKey(ts) {
  const d = new Date(normalizeTimestamp(ts));
  if (!Number.isFinite(d.getTime())) return 'unknown-date';
  const parts = new Intl.DateTimeFormat(undefined, { year:'numeric', month:'2-digit', day:'2-digit' }).formatToParts(d);
  const map = Object.fromEntries(parts.map(p => [p.type, p.value]));
  return `${map.year}-${map.month}-${map.day}`;
}

function splitConversationByDay(messages = []) {
  const groups = new Map();
  for (const m of messages) {
    const key = localDayKey(m.timestamp);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(m);
  }
  const days = [...groups.entries()]
    .filter(([date]) => date !== 'unknown-date')
    .sort(([a],[b]) => a.localeCompare(b))
    .map(([date, dayMessages], index, arr) => {
      const ordered = dayMessages.slice().sort((a,b) => normalizeTimestamp(a.timestamp)-normalizeTimestamp(b.timestamp));
      const age = arr.length - 1 - index;
      const dayWeight = age === 0 ? 0.50 : age === 1 ? 0.25 : age === 2 ? 0.13 : 0.07 / Math.max(1, age - 2);
      const incoming = ordered.filter(m => !m.from_me).length;
      const outgoing = ordered.filter(m => m.from_me).length;
      return { date, messages: ordered, message_count: ordered.length, incoming, outgoing, day_weight: Number(dayWeight.toFixed(4)), latest_timestamp: normalizeTimestamp(ordered.at(-1)?.timestamp) };
    });
  return days;
}

function prioritizeDayBlocks(messages = [], maxDays = 7, maxMessagesPerDay = 10) {
  const days = splitConversationByDay(messages);
  const selected = days.slice(-Math.max(1, maxDays)).map(day => ({
    ...day,
    messages: day.messages.slice(-Math.max(1, maxMessagesPerDay))
  }));
  return selected;
}

function buildDayContext(messages = []) {
  const days = prioritizeDayBlocks(messages, Number(process.env.MAX_ANALYSIS_DAYS) || 7, Number(process.env.MAX_MESSAGES_PER_DAY) || 10);
  return days.map((d, i) => ({
    date: d.date,
    priority: i === days.length - 1 ? 'HIGHEST — most recent day' : i === days.length - 2 ? 'HIGH — previous day' : 'CONTEXT — older day',
    day_weight: d.day_weight,
    message_count: d.message_count,
    incoming: d.incoming,
    outgoing: d.outgoing,
    messages: d.messages.map(m => ({ speaker:m.from_me?'ME':'THEM', timestamp:new Date(normalizeTimestamp(m.timestamp)).toISOString(), text:String(m.body||'') }))
  }));
}

function buildEvidenceLedger(messages) {
  return messages.map((m, i) => messageAnalysis(m, i, messages.length));
}

function buildContrastiveCandidates(aggregate, requestedTone='') {
  const ranked = aggregate.ranked.filter(x => x.id !== 'neutral').slice(0, 3);
  if (requestedTone && TONE_BY_ID[requestedTone]) ranked.unshift({id:requestedTone,label:TONE_BY_ID[requestedTone].label,score:aggregate.scores[requestedTone]||0});
  const unique = []; for (const x of ranked) if (!unique.some(y=>y.id===x.id)) unique.push(x);
  if (!unique.length) unique.push({id:'neutral',label:TONE_BY_ID.neutral.label,score:aggregate.scores.neutral||0});
  return unique.slice(0,3);
}

function rankCandidateResponses(candidates, fallbackResponse, instruction='', sourceMessages=[]) {
  const list=(Array.isArray(candidates)?candidates:[]).map((x,i)=>typeof x==='string'?{response:x,model_rank:i+1}:{...x,response:String(x.response||'').trim(),model_rank:Number(x.rank)||i+1}).filter(x=>x.response);
  if(!list.length && fallbackResponse) return [{response:String(fallbackResponse).trim(),rank:1,score:50,why:'Model-selected response.'}];
  const req=String(instruction||'').toLowerCase();
  const latest=String([...sourceMessages].reverse().find(m=>String(m.body||'').trim())?.body||'').toLowerCase();
  const positiveWords=['warm','friendly','casual','playful','funny','humour','humor','enthusiastic','excited','confident','direct','professional','formal','reassuring'];
  return list.map((x,i)=>{
    const r=x.response,low=r.toLowerCase();
    let score=60-(Number(x.model_rank)-1)*5;
    const words=positiveWords.filter(w=>req.includes(w));
    for(const w of words) if(low.includes(w)) score+=3;
    if(r.length<4||r.length>900) score-=10;
    if(/\b(i think|maybe|probably)\b/i.test(r)&&/\b(direct|confident)\b/.test(req)) score-=4;
    if(/\b(according to|you said|you told me)\b/i.test(r)&&latest&&!latest.includes(r.match(/\b(according to|you said|you told me)\b/i)?.[0]?.toLowerCase()||'')) score-=2;
    return {...x,score:Math.max(0,Math.min(100,Math.round(score)))};
  }).sort((a,b)=>b.score-a.score).map((x,i)=>({...x,rank:i+1}));
}

function sectionSignalScore(sectionId, sourceMessages = []) {
  const rows = (sourceMessages || []).map(m => toneVector(m.body));
  if (!rows.length) return 0;
  const avg = id => mean(rows.map(r => Number(r[id] || 0)));
  const max = ids => Math.max(0, ...ids.map(id => avg(id)));
  const alternations = sourceMessages.slice(1).reduce((n, m, i) => n + (Boolean(m.from_me) !== Boolean(sourceMessages[i].from_me) ? 1 : 0), 0);
  const questions = mean(sourceMessages.map(m => (String(m.body || '').match(/\?/g) || []).length));
  const exclaims = mean(sourceMessages.map(m => (String(m.body || '').match(/!/g) || []).length));
  const lengths = sourceMessages.map(m => String(m.body || '').trim().split(/\s+/).filter(Boolean).length).filter(Boolean);
  const avgLen = mean(lengths);
  const variance = lengths.length > 1 ? mean(lengths.map(x => (x - avgLen) ** 2)) ** 0.5 : 0;
  const scale = n => Math.max(0, Math.min(100, n));
  switch (sectionId) {
    case 'overall': return scale(max(['serious','direct','warm','curious','frustrated','concerned','playful','humorous','professional','confident','neutral']));
    case 'attitude': return scale(max(['warm','affectionate','friendly','direct','serious','concerned','frustrated','confident','curious','reassuring']));
    case 'sarcasm_humour': return scale(max(['sarcastic','humorous','playful']) + Math.min(15, exclaims * 5));
    case 'psychology': return scale(25 + Math.min(30, alternations * 5) + Math.min(20, questions * 10) + Math.min(15, variance * 1.5));
    case 'risks': return scale(max(['frustrated','concerned','serious','direct','sarcastic']) + Math.min(15, exclaims * 5));
    case 'evidence': return scale(45 + Math.min(35, sourceMessages.length * 1.5) + Math.min(20, alternations * 3));
    case 'strategy': return scale(35 + max(['direct','curious','concerned','frustrated']) * 0.55 + Math.min(15, alternations * 3));
    case 'alternatives': return scale(40 + Math.min(25, variance * 2) + Math.min(20, questions * 8) + Math.min(15, alternations * 2));
    default: return 35;
  }
}

function computeEvidenceConfidence(section, sourceMessages, modelPercent = 0, sectionId = 'overall') {
  const evidence = Array.isArray(section?.evidence) ? section.evidence : [];
  const verified = evidence.filter(e => e?.example_verified && e?.quote).length;
  const direct = evidence.filter(e => e?.evidence_type !== 'indirect' && e?.quote).length;
  const indirect = evidence.filter(e => e?.evidence_type === 'indirect' && e?.quote).length;
  const principles = evidence.filter(e => String(e?.principle || '').trim()).length;
  const justifications = evidence.filter(e => String(e?.justification || e?.interpretation || e?.point || e?.explanation || '').trim()).length;
  const counter = Array.isArray(section?.counter_evidence) ? section.counter_evidence.filter(e => e?.quote).length : 0;
  if (!verified) return 0;

  // Confidence is now evidence-first. The model's numeric answer is only a
  // small input; it can no longer become a shared default such as 50/54%.
  const evidenceQuality = Math.min(100,
    24 + Math.min(30, verified * 10) + Math.min(14, direct * 5) + Math.min(8, indirect * 3) +
    Math.min(10, principles * 3) + Math.min(10, justifications * 3) + (verified >= 2 ? 4 : 0)
  );
  const signal = sectionSignalScore(sectionId, sourceMessages);
  const model = clampPercent(modelPercent, 0);
  const contradictionPenalty = Math.min(24, counter * 6);
  const raw = (evidenceQuality * 0.42) + (signal * 0.38) + (model * 0.20) - contradictionPenalty;
  // With only one weak quote, confidence should remain modest. With multiple
  // verified quotes and section-specific signals, it can rise naturally.
  const minimum = verified >= 2 ? 35 : 22;
  return Math.round(Math.max(minimum, Math.min(95, raw)));
}
async function analyzeAndDraft(chatId, userInstruction = '', requested = {}, signal = null, selectedText = '') {
  const started = Date.now();
  const chat = getChat(chatId);
  if (!chat) throw new Error('Chat not found. Sync WhatsApp first.');
  const contextType = chat.context_type || 'general';
  const profile = TONE_PROFILES[contextType] || TONE_PROFILES.general;
  const recent = getMessages(chatId, Math.max(MAX_TRANSCRIPT_MESSAGES, 120));
  const selectedSource = String(selectedText || '').trim();
  const dayContext = selectedSource ? [] : buildDayContext(recent);
  const prioritizedMessages = selectedSource ? [] : dayContext.flatMap(d => d.messages.map(m => ({ from_me:m.speaker==='ME', body:m.text, timestamp:m.timestamp })));
  const sourceMessages = selectedSource ? [{ from_me: false, body: selectedSource, timestamp: Date.now() }] : prioritizedMessages.slice(-MAX_TRANSCRIPT_MESSAGES);
  const transcript = sourceMessages.map(m => `${m.from_me ? 'ME' : 'THEM'}: ${m.body}`).join('\n');
  const evidenceLedger = buildEvidenceLedger(sourceMessages);
  const aggregate = aggregateToneScores(sourceMessages);
  const contactBaseline = buildContactBaseline(chatId);
  const heuristicSummary = summarizeHeuristicSignals(sourceMessages);
  const contrastive = buildContrastiveCandidates(aggregate, String(requested.preferred_tone || '').trim());
  const voice = buildVoice(chatId);
  const feedback = buildFeedback(chatId);
  const req = analysisDefaults(requested);
  const standingInstructions = String(chat.ai_instructions || '').trim() || '(none saved)';
  const userProfile = getUserProfile();
  const contactProfile = { gender: chat.contact_gender || String(requested.contact_gender || ''), age: chat.contact_age || requested.contact_age || null };
  const enteredUserProfile = { gender: String(requested.user_gender || userProfile.gender || ''), age: requested.user_age || userProfile.age || null };
  const conversationRole = String(requested.conversation_role || contextType || 'general').trim();
  const analysisFeedback = getAnalysisFeedback(chatId, 12);
  const requestedTone = String(requested.preferred_tone || '').trim();
  const oneOffRequest = String(userInstruction || '').trim() || '(no one-off request — decide what would be most useful for the latest message)';
  const timeContext = `Runtime time: ${new Date().toString()}. Use message timestamps when interpreting relative time.`;

  const prompt = `You are the reasoning stage of a local WhatsApp communication copilot using a small Llama 3.2 model. Your job is to interpret structured signals and conversation evidence, not to invent facts.

CORE PRINCIPLE: OBSERVATION -> EVIDENCE -> INTERPRETATION -> ALTERNATIVE -> DECISION.
Never skip the evidence step. Never treat inferred emotion, motive, personality, diagnosis, or psychological state as fact.

${QUOTE_RULE}

TONE TAXONOMY — exactly 20 distinct tones:
${TONE_GUIDANCE}

TONE BOUNDARIES:
- Professional is about work/business communication; Formal is about linguistic register. Work topic alone does not mean Professional.
- Direct means explicit/low-ambiguity wording; it does not mean hostile.
- Enthusiastic means strong positive interest; Excited means heightened anticipation/celebration.
- Warm means caring/positive; Friendly means socially approachable; Affectionate implies stronger fondness.
- Sarcastic requires a plausible literal-vs-implied mismatch; do not label sarcasm from punctuation alone.
- Humorous means amusement is a central function; Playful means light teasing/energy, which can exist without a joke.
- Neutral is a fallback only after considering stronger candidates. It is appropriate when the message is genuinely matter-of-fact or evidence is contradictory.

ANALYSIS PROTOCOL:
1. Identify the latest meaningful THEM message first. If none, use the latest meaningful message.
2. Use previous messages only to resolve context, intent, references, and ambiguity — do not average unrelated emotions.
3. Consider the deterministic 20-tone vector below as observable signal evidence, not a conclusion.
4. Compare up to three plausible tone interpretations. State what evidence supports each and what evidence contradicts each.
5. Compare the current message with the contact-specific baseline. A change from their own normal style can matter more than a generic keyword.
6. For sarcasm/humour, explicitly test literal meaning versus contextual meaning.
7. For psychology, use a named communication principle only when it genuinely explains an observable pattern.
8. Every conclusion in Deep Analysis needs direct evidence plus a justification. Evidence must say WHY the exact words support the conclusion.
9. Include counter-evidence when available. If there is none, say that no meaningful counter-evidence was found rather than fabricating one.
10. Response generation must use a compact response brief and must not introduce unsupported facts.
11. Before writing the final JSON, silently re-check every quote against RECENT CONVERSATION word-for-word and every percent against the evidence that backs it: if a quote does not appear verbatim, replace it with one that does or clear the field; if a percent is not clearly earned by the cited evidence, lower it. Do this checking internally — the JSON must contain only the corrected result, not your checking process.
12. Two interpretations that both fit the evidence equally well are more useful stated as alternatives than forced into one falsely confident conclusion — use alternative_interpretation and counter_evidence for genuine ambiguity instead of picking arbitrarily.

PSYCHOLOGICAL / COMMUNICATION PRINCIPLES YOU MAY USE:
${PSYCHOLOGY_FRAMEWORK_TEXT}
For each psychological evidence item, provide: principle, exact quote, observable clue, cautious interpretation, and confidence. Do not diagnose mental disorders, attachment styles, personality disorders, trauma, or hidden motives.

REQUESTED TONE: ${requestedTone || '(infer from evidence)'}
CHAT CONTEXT / ROLE: ${conversationRole}
AVAILABLE ROLE STYLE: ${profile.label} — ${profile.style}
USER PROFILE (optional, user-entered): ${JSON.stringify(enteredUserProfile)}
CONTACT PROFILE (optional, user-entered): ${JSON.stringify(contactProfile)}
Use these only to customize wording/style. Never infer gender or age when the fields are blank, and never make stereotypes or unsupported assumptions.
PERSISTENT USER INSTRUCTIONS:
${standingInstructions}
USER'S EXACT REQUEST:
${oneOffRequest}

DETERMINISTIC 20-TONE VECTOR FOR CURRENT MESSAGES:
${JSON.stringify(aggregate.scores)}
TOP DETERMINISTIC CANDIDATES:
${JSON.stringify(contrastive)}

MESSAGE-LEVEL SIGNALS (latest messages weighted most heavily):
${JSON.stringify(evidenceLedger)}

CONTACT-SPECIFIC BASELINE (THEM's prior messages):
${JSON.stringify(contactBaseline)}

DAY-BASED CONVERSATION BLOCKS (newest day has highest priority):
${JSON.stringify(dayContext)}
Rules: treat each calendar day as a separate conversation block; prioritize the newest day, then the previous day, and use older days only for continuity or resolving references. Do not average unrelated days together. A tone shift between days is itself meaningful evidence.

RECENT CONVERSATION:
${transcript || '(no messages)'}

USER'S WRITING EXAMPLES:
${voice}
PAST RESPONSE FEEDBACK:
${feedback}
USER ANALYSIS CORRECTIONS:
${analysisFeedback.length ? analysisFeedback.map(f=>`- ${f.kind}: ${f.note}`).join('\n') : '(none)'}
TIME:
${timeContext}

RESPONSE GENERATION:
Create up to 3 candidate replies internally. Pick the best candidate using: exact instruction adherence, tone match, naturalness, brevity, no invented facts, and fit with the user's demonstrated style. Put the chosen reply in response. Put the other useful candidates in alternatives.

DEEP ANALYSIS EVIDENCE:
Each evidence object MUST contain a psychological/communication principle field. If no psychological principle is genuinely relevant, use exactly "Direct textual observation — no psychological principle applied." Do not force a principle onto purely factual evidence.

Return ONLY JSON:
{
  "response":"sendable WhatsApp reply",
  "response_brief":{"goal":"","must_include":[],"avoid":[],"tone":"","context":""},
  "candidate_responses":[{"response":"","rank":1,"why":"","evidence":[{"quote":"","justification":"","principle":""}]}],
  "primary_tone":{"id":"one allowed tone id","label":"","percent":0,"quote":"verbatim quote","principle":""},
  "secondary_tones":[{"id":"allowed tone id","label":"","percent":0,"quote":"verbatim quote","principle":""}],
  "tone_scores":{"warm":0,"affectionate":0,"friendly":0,"playful":0,"humorous":0,"sarcastic":0,"flirty":0,"casual":0,"curious":0,"enthusiastic":0,"excited":0,"confident":0,"direct":0,"professional":0,"formal":0,"serious":0,"reassuring":0,"concerned":0,"frustrated":0,"neutral":0},
  "tone_comparison":[{"tone":"","supporting_quote":"","supporting_reason":"","contradicting_quote":"","contradicting_reason":"","percent":0}],
  "psychology_summary":"",
  "psychology_lenses":[{"principle":"","quote":"","percent":0,"interpretation":"","observable_clue":""}],
  "likely_attitude":{"summary":"","quote":"","percent":0,"principle":""},
  "intent":{"summary":"","quote":"","percent":0,"principle":""},
  "evidence":[{"quote":"","point":"","justification":"","principle":""}],
  "counter_evidence":[{"quote":"","point":"","justification":"","principle":""}],
  "signals":{"sarcasm":{"detected":false,"percent":0,"quote":"","explanation":"","principle":""},"humor":{"detected":false,"percent":0,"quote":"","explanation":"","principle":""},"warmth":{"detected":false,"percent":0,"quote":"","explanation":"","principle":""},"frustration":{"detected":false,"percent":0,"quote":"","explanation":"","principle":""},"formality":{"detected":false,"percent":0,"quote":"","explanation":"","principle":""}},
  "risks":[{"conclusion":"","percent":0,"evidence":[{"quote":"","justification":"","principle":""}]}],
  "strategy":{"conclusion":"","evidence":[{"quote":"","justification":"","principle":""}],"steps":[]},
  "alternatives":[{"response":"","when":"","evidence":[{"quote":"","justification":"","principle":""}]}],
  "deep_analysis":{
    "overall":{"conclusion":"","percent":0,"evidence":[{"quote":"","justification":"","principle":""}],"counter_evidence":[]},
    "attitude":{"conclusion":"","percent":0,"evidence":[{"quote":"","justification":"","principle":""}],"counter_evidence":[]},
    "sarcasm_humour":{"conclusion":"","percent":0,"evidence":[{"quote":"","justification":"","principle":""}],"counter_evidence":[]},
    "psychology":{"conclusion":"","percent":0,"evidence":[{"quote":"","justification":"","principle":""}],"principles":[],"counter_evidence":[]},
    "risks":{"conclusion":"","percent":0,"evidence":[{"quote":"","justification":"","principle":""}],"counter_evidence":[]},
    "evidence":{"conclusion":"","percent":0,"evidence":[{"quote":"","justification":"","principle":""}],"counter_evidence":[]},
    "strategy":{"conclusion":"","percent":0,"evidence":[{"quote":"","justification":"","principle":""}],"steps":[],"counter_evidence":[]},
    "alternatives":{"conclusion":"","percent":0,"evidence":[{"quote":"","justification":"","principle":""}],"options":[],"counter_evidence":[]}
  },
  "confidence_overall":{"percent":0,"quote":"","principle":""},
  "temporal_context":"",
  "alternative_interpretation":"",
  "notes":""
}
Requested sections: ${JSON.stringify(req)}. Keep the JSON concise. Never fabricate evidence. If a claim cannot be supported, lower its confidence and state the limitation. `;

  let raw;
  try {
    raw = await callOllama(prompt, { json: true, temperature: 0.12, timeoutMs: OLLAMA_TIMEOUT_MS, signal });
  } catch (err) {
    if (String(err?.message) === 'CANCELLED_BY_USER') throw new Error('Stopped by user.');
    if (/timed out|timeout|AbortError/i.test(String(err?.message || err))) throw new Error(`AI response exceeded the ${Math.round(OLLAMA_TIMEOUT_MS / 1000)}-second response limit. Try again with fewer messages or a shorter instruction.`);
    throw err;
  }
  let data = cleanJson(raw);
  if (!data) {
    const match = raw.match(/"response"\s*:\s*"((?:\\.|[^"\\])*)"/s);
    if (match) { try { data = { response: JSON.parse(`"${match[1]}"`) }; } catch (_) {} }
  }
  if (!data) throw new Error(`AI returned an unreadable structured response after ${Date.now() - started}ms.`);
  const quoteCtx = buildQuoteContext(transcript);
  const result = normalizeAnalysis(data, req, quoteCtx, { aggregate, contactBaseline, contrastive, sourceMessages });
  calibrateNeutralTone(result, sourceMessages, requestedTone, aggregate);
  calibrateConfidence(result, sourceMessages);
  result.tone_scores = aggregate.scores;
  result.message_analysis = aggregate.rows;
  result.contact_baseline = contactBaseline;
  result.tone_comparison = Array.isArray(data.tone_comparison) ? data.tone_comparison.slice(0,3) : contrastive.map(x => ({tone:x.label, percent:x.score, supporting_quote:'', supporting_reason:'Deterministic signal candidate; inspect conversation evidence.'}));
  result.candidate_responses = rankCandidateResponses(data.candidate_responses, result.response, oneOffRequest, sourceMessages).slice(0,3);
  if (req.draft && result.candidate_responses[0]?.response) result.response = result.candidate_responses[0].response;
  result.alternative_interpretation = String(data.alternative_interpretation || '').trim();
  result.timing_ms = Date.now() - started;
  result.response_sla_ms = OLLAMA_TIMEOUT_MS;
  return result;
}

function calibrateConfidence(result, sourceMessages) {
  if (!result) return;
  const keys = Object.keys(result.deep_analysis || {});
  for (const key of keys) {
    const section = result.deep_analysis[key];
    section.percent = computeEvidenceConfidence(section, sourceMessages, section.percent, key);
    section.evidence = Array.isArray(section.evidence) ? section.evidence : [];
    section.counter_evidence = Array.isArray(section.counter_evidence) ? section.counter_evidence : [];
  }
  if (result.confidence_overall) result.confidence_overall.percent = computeEvidenceConfidence({evidence:[result.confidence_overall]}, sourceMessages, result.confidence_overall.percent, 'overall');
}

function calibrateNeutralTone(result, sourceMessages, requestedTone = '', aggregate = null) {
  if (!result || requestedTone) return;
  const agg = aggregate || aggregateToneScores(sourceMessages || []);
  if (result.primary_tone?.id !== 'neutral') return;
  const strongest = agg.ranked.find(x => x.id !== 'neutral');
  if (!strongest || strongest.score < 42) return;
  const latest = [...(sourceMessages || [])].reverse().find(m => String(m.body || '').trim());
  if (!latest) return;
  const latestScores = toneVector(latest.body);
  const latestBest = Object.entries(latestScores).filter(([id]) => id !== 'neutral').sort((a,b)=>b[1]-a[1])[0];
  if (!latestBest || latestBest[1] < 60) return;
  const tone = TONE_BY_ID[latestBest[0]];
  if (!tone) return;
  result.primary_tone = { id:tone.id, label:tone.label, description:tone.description, percent:Math.max(58, Math.min(88, latestBest[1])), quote:String(latest.body||'').trim().slice(0,400), has_quote:true, principle:'Emotional signaling / contextual interpretation' };
  result.tone = tone.label;
  result.notes = [result.notes, `Neutral was overridden because the latest message contains a strong ${tone.label} signal supported by the deterministic tone vector.`].filter(Boolean).join(' ');
}

function normalizeTone(raw, quoteCtx) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const rawId = String(source.id || source.label || '').trim().toLowerCase();
  const found = TONE_OPTIONS.find(t => t.id === rawId || t.label.toLowerCase() === rawId);
  const tone = found || TONE_OPTIONS.find(t => normalizeWs(t.label).includes(normalizeWs(rawId))) || TONE_BY_ID.neutral;
  const item = normalizeEvidenceItem(source, [], quoteCtx, { principle:'Emotional signaling / tone interpretation' });
  const finalPercent = item.has_quote ? item.percent : Math.min(item.percent, 25);
  return { id:tone.id, label:tone.label, description:tone.description, percent:finalPercent, quote:item.quote, has_quote:item.has_quote, principle:item.principle };
}

function normalizeConclusionSection(raw, quoteCtx, fallbackConclusion = '', fallbackEvidence = [], defaults = {}, sectionId = 'overall') {
  const source = raw && typeof raw === 'object' ? raw : {};
  const evidenceRaw = Array.isArray(source.evidence) ? source.evidence : fallbackEvidence;
  const evidence = evidenceRaw.filter(Boolean).slice(0, 6).map(e => normalizeEvidenceItem({ ...e, justification:e.justification || e.explanation || e.interpretation || e.point, point:e.point || e.justification }, ['justification','point'], quoteCtx, defaults));
  const requestedPercent = clampPercent(source.percent ?? source.confidence_percent, 0);
  const verifiedCount = evidence.filter(e => e.example_verified && e.quote).length;
  const percent = verifiedCount ? requestedPercent : 0;
  const counter = Array.isArray(source.counter_evidence) ? source.counter_evidence.slice(0,4).map(e => normalizeEvidenceItem(e,['justification','point'],quoteCtx,defaults)) : [];
  return { conclusion:String(source.conclusion || source.summary || fallbackConclusion || '').trim().slice(0,1400), percent, evidence, counter_evidence:counter };
}

function buildDeepAnalysis(data, quoteCtx) {
  const deep = data.deep_analysis && typeof data.deep_analysis === 'object' ? data.deep_analysis : {};
  const evidence = Array.isArray(data.evidence) ? data.evidence : [];
  const strategy = data.strategy && typeof data.strategy === 'object' ? data.strategy : { conclusion:data.strategy || '' };
  const alternatives = Array.isArray(data.alternatives) ? data.alternatives : [];
  const riskItems = Array.isArray(data.risks) ? data.risks : [];
  const altEvidence = alternatives.flatMap(a => Array.isArray(a?.evidence) ? a.evidence : []).slice(0,6);
  const riskEvidence = riskItems.flatMap(r => Array.isArray(r?.evidence) ? r.evidence : []).slice(0,6);
  const principle = 'Direct textual observation — no psychological principle applied.';
  return {
    overall: normalizeConclusionSection(deep.overall,quoteCtx,String(data.psychology_summary||data.intent?.summary||'Overall interpretation derived from the selected conversation evidence.'),evidence,{principle},'overall'),
    attitude: normalizeConclusionSection(deep.attitude,quoteCtx,data.likely_attitude?.summary||'',data.likely_attitude?[data.likely_attitude]:evidence.slice(0,2),{principle:'Emotional signaling / attribution & ambiguity'},'attitude'),
    sarcasm_humour: normalizeConclusionSection(deep.sarcasm_humour,quoteCtx,'Sarcasm and humour are assessed from literal-vs-implied meaning, incongruity, punctuation, emojis and context.',[data.signals?.sarcasm,data.signals?.humor].filter(Boolean),{principle:'Sarcasm & incongruity / humour & play'},'sarcasm_humour'),
    psychology: normalizeConclusionSection(deep.psychology,quoteCtx,String(data.psychology_summary||'Communication patterns are interpreted from observable wording rather than assumed inner states.'),data.psychology_lenses||evidence.slice(0,3),{principle:'Communication principle selected from observable evidence'},'psychology'),
    risks: normalizeConclusionSection(deep.risks,quoteCtx,riskItems.map(r=>typeof r==='string'?r:r?.conclusion).filter(Boolean).join(' · '),riskEvidence.length?riskEvidence:evidence.slice(0,2),{principle:'Conflict & de-escalation / face-saving & face threat'},'risks'),
    evidence: normalizeConclusionSection(deep.evidence,quoteCtx,'The strongest evidence chain linking the conversation text to the analysis.',evidence,{principle},'evidence'),
    strategy: normalizeConclusionSection(deep.strategy,quoteCtx,typeof strategy==='string'?strategy:strategy.conclusion||'',strategy.evidence||evidence.slice(0,2),{principle:'Reciprocity & conversational repair / uncertainty reduction'},'strategy'),
    alternatives: normalizeConclusionSection(deep.alternatives,quoteCtx,alternatives.map(a=>typeof a==='string'?a:a?.response).filter(Boolean).join(' · '),altEvidence.length?altEvidence:evidence.slice(0,2),{principle:'Attribution & ambiguity / uncertainty reduction'},'alternatives')
  };
}

function normalizeAnalysis(data, req, quoteCtx, meta = {}) {
  const primaryTone = normalizeTone(data.primary_tone || {id:data.tone},quoteCtx);
  const secondary = Array.isArray(data.secondary_tones) ? data.secondary_tones.slice(0,2).map(t=>normalizeTone(t,quoteCtx)) : [];
  const strategyObj = data.strategy && typeof data.strategy === 'object' ? data.strategy : {conclusion:String(data.strategy||'')};
  const psychologyLenses = req.psychology ? normalizeEvidenceList(data.psychology_lenses,['principle','interpretation','observable_clue'],8,quoteCtx,{principle:'Communication principle selected from observable evidence'}) : [];
  const evidence = req.evidence ? normalizeEvidenceList(data.evidence,['point','justification'],10,quoteCtx,{principle:'Direct textual observation — no psychological principle applied.'}) : [];
  const counterEvidence = normalizeEvidenceList(data.counter_evidence,['point','justification'],8,quoteCtx,{principle:'Attribution & ambiguity'});
  return {
    response:req.draft?String(data.response||'').trim():'',
    response_brief:data.response_brief||null,
    candidate_responses:Array.isArray(data.candidate_responses)?data.candidate_responses.slice(0,3):[],
    primary_tone:primaryTone,
    secondary_tones:secondary,
    tone:primaryTone.label,
    tone_scores:data.tone_scores && typeof data.tone_scores==='object'?data.tone_scores:{},
    tone_comparison:Array.isArray(data.tone_comparison)?data.tone_comparison.slice(0,3):[],
    psychology_summary:req.psychology?String(data.psychology_summary||data.psychology||'Not requested.').trim():'',
    psychology_lenses:psychologyLenses,
    likely_attitude:req.attitude?normalizeEvidenceItem(data.likely_attitude,['summary'],quoteCtx,{principle:'Emotional signaling / attribution & ambiguity'}):null,
    intent:req.intent?normalizeEvidenceItem(data.intent,['summary'],quoteCtx,{principle:'Uncertainty reduction / reciprocity & conversational repair'}):null,
    evidence,
    counter_evidence:counterEvidence,
    signals:req.signals?normalizeSignals(data.signals,quoteCtx):{},
    risks:req.risks&&Array.isArray(data.risks)?data.risks.slice(0,8).map(r=>typeof r==='string'?{conclusion:r,percent:50,evidence:[]}:{conclusion:String(r.conclusion||r.summary||''),percent:clampPercent(r.percent,50),evidence:Array.isArray(r.evidence)?r.evidence.slice(0,4):[]}):[], 
    strategy:req.strategy?{conclusion:String(strategyObj.conclusion||strategyObj.summary||'').trim(),steps:Array.isArray(strategyObj.steps)?strategyObj.steps.map(String).slice(0,6):[],evidence:Array.isArray(strategyObj.evidence)?strategyObj.evidence.slice(0,6):[]}:null,
    alternatives:req.alternatives&&Array.isArray(data.alternatives)?data.alternatives.slice(0,4).map(a=>typeof a==='string'?{response:a,when:'',evidence:[]}:{response:String(a.response||a.text||''),when:String(a.when||'').trim(),evidence:Array.isArray(a.evidence)?a.evidence.slice(0,4):[]}):[],
    confidence_overall:normalizeEvidenceItem(data.confidence_overall,[],quoteCtx,{principle:'Evidence-weighted confidence'}),
    deep_analysis:buildDeepAnalysis(data,quoteCtx),
    temporal_context:String(data.temporal_context||'').trim(),
    alternative_interpretation:String(data.alternative_interpretation||'').trim(),
    notes:String(data.notes||'').trim()
  };
}

function parseSelectedMessages(rawSelection='') {
  const lines=String(rawSelection||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  return lines.map((line,index)=>{
    const m=line.match(/^(?:\[([^\]]+)\]\s*)?(ME|THEM)\s*:\s*(.*)$/i);
    if(m){
      const parsed=Date.parse(m[1]||'');
      return { index:index+1, from_me:m[2].toUpperCase()==='ME', body:String(m[3]||'').trim(), timestamp:Number.isFinite(parsed)?parsed:index+1, raw:line };
    }
    return { index:index+1, from_me:false, body:line, timestamp:index+1, raw:line };
  }).filter(m=>m.body);
}

function toneDistributionAllMessages(messages=[]) {
  const totals=Object.fromEntries(TONE_OPTIONS.map(t=>[t.id,0]));
  for(const m of messages){
    const v=toneVector(m.body);
    for(const [id,score] of Object.entries(v)) totals[id]+=Number(score)||0;
  }
  let sum=Object.values(totals).reduce((a,b)=>a+b,0);
  if(sum<=0){ totals.neutral=1; sum=1; }
  const out={}; let running=0; const ids=TONE_OPTIONS.map(t=>t.id);
  ids.forEach((id,i)=>{
    let pct=i===ids.length-1?Math.max(0,100-running):Math.round((totals[id]/sum*100)*10)/10;
    out[id]=pct; running=Math.round((running+pct)*10)/10;
  });
  const drift=Math.round((100-Object.values(out).reduce((a,b)=>a+b,0))*10)/10;
  if(Math.abs(drift)>0) {
    const strongest=Object.entries(out).sort((a,b)=>b[1]-a[1])[0]?.[0]||'neutral';
    out[strongest]=Math.max(0,Math.round((out[strongest]+drift)*10)/10);
  }
  return out;
}

function toneShiftEvidence(messages=[]) {
  const rows=messages.map((m,i)=>messageAnalysis(m,i,messages.length));
  const changes=[];
  for(let i=1;i<rows.length;i++){
    const a=rows[i-1], b=rows[i];
    if(a.dominant_tone===b.dominant_tone) continue;
    const aScore=Number(a.tone_scores[a.dominant_tone]||0), bScore=Number(b.tone_scores[b.dominant_tone]||0);
    if(Math.max(aScore,bScore)<45) continue;
    changes.push({
      quote:b.text,
      previous_quote:a.text,
      evidence_type:'indirect',
      cue:`Dominant textual signal changed from ${TONE_BY_ID[a.dominant_tone]?.label||a.dominant_tone} to ${TONE_BY_ID[b.dominant_tone]?.label||b.dominant_tone}.`,
      change:`Message ${a.index} → ${b.index}`,
      point:'Tone shift across adjacent selected messages',
      justification:'The inference comes from a change in wording/punctuation/style relative to the immediately preceding selected message, not from this quote in isolation.',
      principle:'Temporal/context effects + emotional signaling',
      percent:Math.min(90,Math.max(45,Math.round((aScore+bScore)/2)))
    });
  }
  return changes.slice(-18);
}

function deterministicIndirectEvidence(messages=[]) {
  const candidates=[];
  const rows=messages.map((m,i)=>messageAnalysis(m,i,messages.length));
  for(const r of rows){
    const body=r.text; if(!body) continue;
    const top=Object.entries(r.tone_scores).sort((a,b)=>b[1]-a[1])[0]||['neutral',0];
    const cues=[];
    if(r.question_count) cues.push(`${r.question_count} question mark${r.question_count===1?'':'s'} / information-seeking`);
    if(r.exclamation_count) cues.push(`${r.exclamation_count} exclamation mark${r.exclamation_count===1?'':'s'} / intensity`);
    if(r.word_count<=4) cues.push('very short message / possible reduced elaboration');
    if(r.word_count>=35) cues.push('unusually long message / increased elaboration');
    if(/😂|🤣|lol|lmao|haha|💀/i.test(body)) cues.push('laughter marker');
    if(/\.\.\.|…/.test(body)) cues.push('ellipsis / possible hesitation or trailing tone');
    if(/^[A-Z\s!?]{4,}$/.test(body)) cues.push('all-caps emphasis');
    if(cues.length || Number(top[1])>=55){
      candidates.push({quote:body,evidence_type:'indirect',cue:cues.join('; ')||`${TONE_BY_ID[top[0]]?.label||top[0]} textual pattern`,point:'Indirect conversational cue',justification:`This is an indirect signal based on form, intensity, length, punctuation, or style. It supports an interpretation only when consistent with surrounding messages.`,principle:'Emotional signaling / politeness & indirectness / temporal context',percent:Math.max(35,Math.min(82,Number(top[1])||45))});
    }
  }
  return candidates.slice(-30);
}

function defaultSectionEvidence(sectionId, directPool, indirectPool, messages) {
  const all=[...(directPool||[]),...(indirectPool||[])].filter(x=>x&&x.quote);
  const fromPool=all.filter(x=>{
    const text=`${x.principle||''} ${x.cue||''} ${x.point||''} ${x.justification||''}`;
    const patterns={
      overall:/tone|overall|serious|warm|direct|curious|frustr/i,
      attitude:/emotional|tone|friendly|warm|direct|serious|curious|concern|frustr/i,
      sarcasm_humour:/sarcas|humou|laugh|play|jok|teas/i,
      psychology:/psych|communication|uncertainty|politeness|reciprocity|temporal|emotional/i,
      risks:/conflict|frustr|risk|direct|face|short message|escalat/i,
      evidence:/evidence|direct|observable|textual/i,
      strategy:/strategy|repair|uncertainty|direct|request/i,
      alternatives:/ambiguity|alternative|uncertainty|indirect/i
    };
    return (patterns[sectionId]||/./i).test(text);
  });
  const chosen=(fromPool.length?fromPool:all).slice(0,3);
  if(chosen.length) return chosen;

  const relevant={
    overall:['serious','warm','friendly','direct','curious','concerned','frustrated','professional','playful','humorous'],
    attitude:['warm','affectionate','friendly','direct','serious','concerned','frustrated','confident','curious','reassuring'],
    sarcasm_humour:['sarcastic','humorous','playful'],
    psychology:['curious','direct','concerned','frustrated','serious'],
    risks:['frustrated','concerned','serious','direct','sarcastic'],
    evidence:['serious','direct','curious','warm','frustrated','concerned'],
    strategy:['direct','curious','concerned','frustrated'],
    alternatives:['curious','concerned','frustrated','serious']
  }[sectionId]||['serious','direct','curious'];
  const scored=(messages||[]).map((m,index)=>{
    const body=String(m.body||'').trim(); const v=toneVector(body);
    const signal=Math.max(...relevant.map(id=>Number(v[id]||0)),0);
    const punctuation=((body.match(/[!?]/g)||[]).length)*3;
    const words=body.split(/\s+/).filter(Boolean).length;
    const brevity=words<=5?5:0;
    return {m,index,score:signal+punctuation+brevity};
  }).filter(x=>x.m&&String(x.m.body||'').trim()).sort((a,b)=>b.score-a.score||b.index-a.index);
  const selected=scored.slice(0,Math.min(3,scored.length));
  const principles={
    overall:'Emotional signaling / attribution & ambiguity',
    attitude:'Emotional signaling / attribution & ambiguity',
    sarcasm_humour:'Sarcasm & incongruity / humour & play',
    psychology:'Communication principle selected from observable evidence',
    risks:'Conflict & de-escalation / face-saving & face threat',
    evidence:'Direct textual observation',
    strategy:'Reciprocity & conversational repair / uncertainty reduction',
    alternatives:'Attribution & ambiguity / uncertainty reduction'
  };
  const labels={
    overall:'Observable wording anchors the overall interpretation.',
    attitude:'The wording provides an observable signal about textual stance or attitude.',
    sarcasm_humour:'The selected wording is checked for literal-vs-implied meaning, humour, irony, or play.',
    psychology:'The wording is interpreted through a communication principle without diagnosing the person.',
    risks:'This wording is relevant to possible misunderstanding, tension, or escalation risk.',
    evidence:'This is a direct excerpt from the selected text and is used as an evidence anchor.',
    strategy:'This wording helps determine what communication approach is most justified.',
    alternatives:'This wording leaves room for more than one reasonable interpretation, so certainty should remain limited.'
  };
  return selected.map(({m})=>({quote:String(m.body||'').trim(),evidence_type:'direct',point:labels[sectionId],justification:labels[sectionId],principle:principles[sectionId],percent:35}));
}
function mergeChunkDeepSections(chunkResults, messages, evidencePool, indirectPool) {
  const ids=['overall','attitude','sarcasm_humour','psychology','risks','evidence','strategy','alternatives'];
  const defaults={
    overall:'Overall interpretation is based on the strongest observable wording and tone signals in the selected messages.', attitude:'Likely textual attitude is inferred cautiously from observable wording, interaction signals, and competing evidence.',
    sarcasm_humour:'Sarcasm and humour are assessed from literal-vs-implied meaning, incongruity, teasing, laughter markers, and surrounding context.',
    psychology:'Communication dynamics are interpreted from observable wording, reciprocity, ambiguity, indirectness, and changes over time.',
    risks:'Potential misunderstanding or escalation risks inferred from the selected interaction pattern.', evidence:'Strongest direct and indirect evidence from the selected messages.',
    strategy:'Communication strategy derived from the strongest supported signals and uncertainty.', alternatives:'Competing interpretations that remain plausible given ambiguity in the selected messages.'
  };
  const out={};
  for(const id of ids){
    const parts=chunkResults.map(x=>x?.deep?.[id]).filter(Boolean);
    const conclusions=parts.map(x=>String(x.conclusion||'').trim()).filter(Boolean);
    const ev=parts.flatMap(x=>Array.isArray(x.evidence)?x.evidence:[]).filter(e=>e?.quote);
    out[id]={
      conclusion:conclusions.slice(0,4).join(' ' ) || defaults[id],
      percent:parts.length?Math.round(parts.reduce((a,x)=>a+(Number(x.percent)||45),0)/parts.length):40,
      evidence:(ev.length?ev:defaultSectionEvidence(id,evidencePool,indirectPool,messages)).slice(0,6),
      counter_evidence:parts.flatMap(x=>Array.isArray(x.counter_evidence)?x.counter_evidence:[]).filter(e=>e?.quote).slice(0,4)
    };
    if(id==='strategy') out[id].steps=parts.flatMap(x=>Array.isArray(x.steps)?x.steps:[]).filter(Boolean).slice(0,6);
    if(id==='alternatives') out[id].options=parts.flatMap(x=>Array.isArray(x.options)?x.options:[]).filter(Boolean).slice(0,5);
  }
  return out;
}

function ensureDeepSections(rawDeep, fallbackDeep, quoteCtx, messages, evidencePool, indirectPool) {
  const ids=['overall','attitude','sarcasm_humour','psychology','risks','evidence','strategy','alternatives'];
  const out={};
  for(const id of ids){
    const src=rawDeep?.[id]&&typeof rawDeep[id]==='object'?rawDeep[id]:{};
    const fb=fallbackDeep[id]||{};
    let ev=Array.isArray(src.evidence)&&src.evidence.length?src.evidence:(fb.evidence||[]);
    if(!ev.length) ev=defaultSectionEvidence(id,evidencePool,indirectPool,messages);
    ev=normalizeEvidenceList(ev,['point','justification','interpretation','explanation'],6,quoteCtx,{principle:'Evidence-grounded conversational interpretation'});
    ev=ev.filter(x=>x.quote);
    if(!ev.length){
      ev=normalizeEvidenceList(defaultSectionEvidence(id,evidencePool,indirectPool,messages),['point','justification'],3,quoteCtx,{principle:'Direct textual observation'}).filter(x=>x.quote);
    }
    const counter=normalizeEvidenceList(Array.isArray(src.counter_evidence)?src.counter_evidence:(fb.counter_evidence||[]),['point','justification'],4,quoteCtx,{principle:'Attribution & ambiguity'}).filter(x=>x.quote);
    const modelPct=clampPercent(src.percent??fb.percent,0);
    const provisional={evidence:ev,counter_evidence:counter};
    const pct=computeEvidenceConfidence(provisional,messages,modelPct,id);
    const conclusion=String(src.conclusion||fb.conclusion||'').trim().slice(0,1800);
    out[id]={conclusion:conclusion||`No sufficiently supported conclusion was established for ${id.replace(/_/g,' ')}.`,percent:pct,evidence:ev,counter_evidence:counter};
    if(id==='strategy') out[id].steps=(Array.isArray(src.steps)?src.steps:(fb.steps||[])).filter(Boolean).slice(0,6);
    if(id==='alternatives') out[id].options=(Array.isArray(src.options)?src.options:(fb.options||[])).filter(Boolean).slice(0,5);
  }
  return out;
}


function mean(nums){return nums.length?nums.reduce((a,b)=>a+b,0)/nums.length:0;}
function buildAnalysisVisuals(chatId, selectedMessages=[]){
  const selected=selectedMessages.slice().sort((a,b)=>normalizeTimestamp(a.timestamp)-normalizeTimestamp(b.timestamp));
  const earliestSelected=selected.length?normalizeTimestamp(selected[0].timestamp):Infinity;
  const history=getMessages(chatId, 1200).filter(m=>normalizeTimestamp(m.timestamp)<earliestSelected);
  const baselineThem=history.filter(m=>!m.from_me && String(m.body||'').trim()).slice(-500);
  const currentThem=selected.filter(m=>!m.from_me && String(m.body||'').trim());
  const metrics=(arr)=>{
    const rows=arr.map((m,i)=>messageAnalysis(m,i,Math.max(1,arr.length)));
    const lengths=rows.map(x=>x.word_count), questions=rows.map(x=>x.question_count), exclaims=rows.map(x=>x.exclamation_count);
    const tones=aggregateToneScores(arr).scores;
    const top=Object.entries(tones).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([id,value])=>({id,label:TONE_BY_ID[id]?.label||id,value:Number(value)||0}));
    return {sample_size:arr.length,avg_words:Number(mean(lengths).toFixed(1)),avg_questions:Number(mean(questions).toFixed(2)),avg_exclamations:Number(mean(exclaims).toFixed(2)),tone_scores:tones,top_tones:top};
  };
  const base=metrics(baselineThem), current=metrics(currentThem);
  const delta=(a,b)=>a?Number(((b-a)/Math.max(1,Math.abs(a))*100).toFixed(1)):0;
  const baseTop=base.top_tones[0]?.label||'No stable tone'; const curTop=current.top_tones[0]?.label||'No strong tone';
  const changes=[
    {metric:'Average message length',baseline:base.avg_words,current:current.avg_words,unit:'words',change_percent:delta(base.avg_words,current.avg_words),direction:current.avg_words>base.avg_words*1.12?'up':current.avg_words<base.avg_words*.88?'down':'stable'},
    {metric:'Questions per message',baseline:base.avg_questions,current:current.avg_questions,unit:'questions',change_percent:delta(base.avg_questions,current.avg_questions),direction:current.avg_questions>base.avg_questions+.35?'up':current.avg_questions<Math.max(0,base.avg_questions-.35)?'down':'stable'},
    {metric:'Exclamations per message',baseline:base.avg_exclamations,current:current.avg_exclamations,unit:'!',change_percent:delta(base.avg_exclamations,current.avg_exclamations),direction:current.avg_exclamations>base.avg_exclamations+.35?'up':current.avg_exclamations<Math.max(0,base.avg_exclamations-.35)?'down':'stable'},
    {metric:'Dominant tone',baseline:baseTop,current:curTop,unit:'',change_percent:null,direction:baseTop!==curTop&&base.sample_size&&current.sample_size?'changed':'stable'}
  ];
  const toneChanges=Object.entries(current.tone_scores||{}).map(([id,v])=>({id,label:TONE_BY_ID[id]?.label||id,current:Number(v)||0,baseline:Number(base.tone_scores?.[id])||0,delta:Number(((Number(v)||0)-(Number(base.tone_scores?.[id])||0)).toFixed(1))})).sort((a,b)=>Math.abs(b.delta)-Math.abs(a.delta)).slice(0,8);
  const timeline=[];
  const bucketCount=Math.min(14,Math.max(4,Math.ceil(selected.length/35)));
  for(let i=0;i<selected.length;i+=Math.ceil(selected.length/bucketCount)){
    const chunk=selected.slice(i,i+Math.ceil(selected.length/bucketCount));
    const rows=chunk.map((m,j)=>messageAnalysis(m,j,chunk.length));
    const toneCounts={}; rows.forEach(r=>{toneCounts[r.dominant_tone]=(toneCounts[r.dominant_tone]||0)+1;});
    const dominant=Object.entries(toneCounts).sort((a,b)=>b[1]-a[1])[0]?.[0]||'neutral';
    const engagement=mean(rows.map(r=>Math.min(100,20+r.word_count*1.7+r.question_count*12+r.exclamation_count*5)));
    const incoming=chunk.filter(m=>!m.from_me).length, outgoing=chunk.length-incoming;
    const relationshipSignals=[];
    if(rows.some(r=>['affectionate','flirty','friendly','warm','playful'].includes(r.dominant_tone))) relationshipSignals.push('warmth / affiliation');
    if(rows.some(r=>['curious','enthusiastic','excited'].includes(r.dominant_tone))) relationshipSignals.push('engagement / interest');
    if(rows.some(r=>['sarcastic','humorous','playful'].includes(r.dominant_tone))) relationshipSignals.push('humour / play');
    if(rows.some(r=>['concerned','frustrated','serious'].includes(r.dominant_tone))) relationshipSignals.push('tension / seriousness');
    const start=new Date(normalizeTimestamp(chunk[0].timestamp)), end=new Date(normalizeTimestamp(chunk.at(-1).timestamp));
    timeline.push({index:timeline.length+1,start:start.toISOString(),end:end.toISOString(),message_count:chunk.length,incoming,outgoing,dominant_tone:dominant,dominant_tone_label:TONE_BY_ID[dominant]?.label||dominant,engagement:Math.round(engagement),relationship_signals:relationshipSignals,avg_words:Number(mean(rows.map(r=>r.word_count)).toFixed(1))});
  }
  const turningPoints=[];
  for(let i=1;i<timeline.length;i++){
    const a=timeline[i-1],b=timeline[i];
    const reasons=[];
    if(a.dominant_tone!==b.dominant_tone) reasons.push(`tone shifted from ${a.dominant_tone_label} to ${b.dominant_tone_label}`);
    if(Math.abs(b.engagement-a.engagement)>=20) reasons.push(`engagement changed by ${Math.abs(b.engagement-a.engagement)} points`);
    if(Math.abs(b.avg_words-a.avg_words)>=8) reasons.push(`message length changed noticeably`);
    if(reasons.length) turningPoints.push({at:b.start,segment:b.index,reason:reasons.join('; '),tone:b.dominant_tone_label,quote:selected[Math.min(selected.length-1,Math.floor(i*selected.length/timeline.length))]?.body||''});
  }
  const explorer=[];
  const deepIds=['overall','attitude','sarcasm_humour','psychology','risks','evidence','strategy','alternatives'];
  for(const id of deepIds){
    explorer.push({section:id,label:id==='sarcasm_humour'?'Sarcasm & Humour':id.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase()),conclusion:'',confidence:null,supporting_messages:[],counter_evidence:[],alternatives:[]});
  }
  return {baseline:{...base},current:{...current},changes,tone_changes:toneChanges,timeline,turning_points:turningPoints.slice(0,12),evidence_explorer:explorer};
}


function calendarDayDiff(start, end){
  const a=new Date(`${start}T00:00:00`), b=new Date(`${end}T00:00:00`);
  return Math.round((b-a)/86400000);
}

async function summarizeConversationDays(chatId, startDate, endDate, userInstruction='', signal=null){
  const started=Date.now();
  const chat=getChat(chatId); if(!chat) throw new Error('Chat not found.');
  const start=String(startDate||'').trim(), end=String(endDate||'').trim();
  if(!/^\d{4}-\d{2}-\d{2}$/.test(start)||!/^\d{4}-\d{2}-\d{2}$/.test(end)) throw new Error('Choose a valid start and end date.');
  if(end<start) throw new Error('End date must be on or after the start date.');
  const days=calendarDayDiff(start,end)+1;
  if(days>2) throw new Error('Conversation Summary supports a maximum of 2 calendar days.');
  if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
  await ollamaReady(signal);
  const all=getAllMessages(chatId).filter(m=>{
    const d=new Date(normalizeTimestamp(m.timestamp));
    if(!Number.isFinite(d.getTime())) return false;
    const y=d.getFullYear(), mo=String(d.getMonth()+1).padStart(2,'0'), da=String(d.getDate()).padStart(2,'0');
    const key=`${y}-${mo}-${da}`;
    return key>=start&&key<=end&&String(m.body||'').trim();
  }).sort((a,b)=>normalizeTimestamp(a.timestamp)-normalizeTimestamp(b.timestamp));
  if(!all.length) throw new Error(`No text messages were found between ${start} and ${end}.`);
  const selected=all.length>MAX_ANALYSIS_MESSAGES?all.slice(-MAX_ANALYSIS_MESSAGES):all;
  const lines=selected.map(m=>`[${new Date(normalizeTimestamp(m.timestamp)).toISOString()}] ${m.from_me?'ME':'THEM'}: ${String(m.body||'').replace(/\r?\n/g,' ')}`).filter(x=>/:\s+\S/.test(x));
  const batches=batchTextMessages(lines);
  const standing=String(chat.ai_instructions||'').trim()||'(none)';
  const common=`CONVERSATION SUMMARY TASK. Summarize ONLY the supplied WhatsApp messages from ${start} through ${end}, inclusive.\nCHAT RULES:\n${standing}\n\nSUMMARY RULES:\n- Separate facts directly stated in messages from reasonable interpretations.\n- Preserve chronology and distinguish the two calendar days when both are present.\n- Identify main topics, important events, decisions, plans, unresolved questions, requests, commitments, emotional/communication shifts, and notable relationship signals.\n- Do not invent facts, motives, or events.\n- Exact quotes must be copied from the supplied messages.\n- If something is uncertain, label it as uncertain.\n- Treat tone as an observable communication signal, not proof of hidden emotion.`;
  const chunks=[];
  for(let i=0;i<batches.length;i++){
    if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
    if(Date.now()-started>=OLLAMA_SELECTION_TIMEOUT_MS) throw new Error('Conversation Summary reached the configured safety ceiling before every selected message received its batch pass.');
    const batch=batches[i];
    const prompt=`You are summary batch ${i+1}/${batches.length}. EVERY message line below must be considered. Return compact JSON only.\n\n${common}\n\nBATCH:\n${batch}\n\nJSON:\n{"messages_considered":${batch.split(/\n/).filter(Boolean).length},"summary":"","topics":[],"decisions":[],"plans":[],"open_loops":[],"notable_events":[],"tone_changes":[],"quotes":[{"quote":"","why":""}]}`;
    let raw='';
    try{raw=await callOllama(prompt,{json:true,temperature:.08,timeoutMs:OLLAMA_BATCH_TIMEOUT_MS,signal,numPredict:1000,numCtx:OLLAMA_BATCH_NUM_CTX});}
    catch(err){if(signal?.aborted)throw new Error('CANCELLED_BY_USER');const msg=String(err?.message||err);if(!/timeout|OLLAMA request failed \(5|Could not reach Ollama/i.test(msg))throw err;try{raw=await callOllama(`RETRY CONCISELY. Return valid JSON for this summary batch.\n${prompt}`,{json:true,temperature:.03,timeoutMs:OLLAMA_BATCH_RETRY_TIMEOUT_MS,signal,numPredict:650,numCtx:OLLAMA_BATCH_NUM_CTX});}catch(_){raw='';}}
    chunks.push(cleanJson(raw)||{messages_considered:batch.split(/\n/).filter(Boolean).length,summary:'Batch summary unavailable; other batches and deterministic chronology will be used.',topics:[],decisions:[],plans:[],open_loops:[],notable_events:[],tone_changes:[],quotes:[]});
  }
  const compact=chunks.map((x,i)=>({batch:i+1,messages_considered:Number(x.messages_considered)||0,summary:String(x.summary||'').slice(0,650),topics:Array.isArray(x.topics)?x.topics.slice(0,6):[],decisions:Array.isArray(x.decisions)?x.decisions.slice(0,5):[],plans:Array.isArray(x.plans)?x.plans.slice(0,5):[],open_loops:Array.isArray(x.open_loops)?x.open_loops.slice(0,5):[],notable_events:Array.isArray(x.notable_events)?x.notable_events.slice(0,5):[],tone_changes:Array.isArray(x.tone_changes)?x.tone_changes.slice(0,5):[],quotes:Array.isArray(x.quotes)?x.quotes.slice(0,3):[]}));
  const dayCounts={}; selected.forEach(m=>{const d=new Date(normalizeTimestamp(m.timestamp));const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;dayCounts[key]=(dayCounts[key]||0)+1;});
  const finalPrompt=`You are the FINAL CONVERSATION SUMMARY stage. Produce a useful, chronological summary of the supplied WhatsApp conversation for at most two calendar days. Every selected message was assigned to an AI batch. Do not invent anything and do not claim access to messages outside the supplied set.\n\n${common}\n\nSELECTED MESSAGES: ${selected.length}\nORIGINAL MESSAGES IN RANGE: ${all.length}\nBATCHES: ${chunks.length}/${batches.length}\nDAY COUNTS: ${JSON.stringify(dayCounts)}\nUSER EXTRA REQUEST: ${String(userInstruction||'').slice(0,2500)||'(none)'}\n\nBATCH REPORTS:\n${JSON.stringify(compact)}\n\nReturn ONLY JSON:\n{"title":"","executive_summary":"2-6 sentence factual summary","day_summaries":[{"date":"YYYY-MM-DD","summary":"","key_points":[]}],"main_topics":[{"topic":"","details":"","quote":""}],"decisions":[{"decision":"","quote":""}],"plans_and_commitments":[{"item":"","who":"ME|THEM|BOTH|UNCLEAR","quote":""}],"open_questions":[{"question":"","status":"open|answered|unclear","quote":""}],"notable_events":[{"event":"","date":"YYYY-MM-DD","quote":""}],"communication_dynamics":{"tone":"","engagement":"","changes":"","evidence_quote":""},"important_quotes":[{"quote":"","why":""}],"uncertainties":[""],"next_steps":[""],"overall_confidence":{"percent":0,"reason":""}}`;
  let finalRaw=''; try{finalRaw=await callOllama(finalPrompt,{json:true,temperature:.08,timeoutMs:OLLAMA_BATCH_RETRY_TIMEOUT_MS,signal,numPredict:1800,numCtx:OLLAMA_BATCH_NUM_CTX});}catch(_){finalRaw='';}
  const d=cleanJson(finalRaw)||{};
  const validQuotes=new Set(selected.map(m=>String(m.body||'').trim()).filter(Boolean));
  const exactQuote=q=>{q=String(q||'').trim(); if(!q)return ''; const hit=[...validQuotes].find(x=>x===q||x.includes(q)||q.includes(x)); return hit||'';};
  const normalizeList=(arr,keys)=>Array.isArray(arr)?arr.slice(0,12).map(x=>{if(typeof x==='string')return {text:x};const o={...x};if(o.quote)o.quote=exactQuote(o.quote);return o;}).filter(x=>Object.values(x).some(v=>String(v||'').trim())):[];
  const daySummaries=Array.isArray(d.day_summaries)?d.day_summaries.slice(0,2).map(x=>({date:String(x?.date||''),summary:String(x?.summary||''),key_points:Array.isArray(x?.key_points)?x.key_points.slice(0,8):[]})) : [];
  return {mode:'conversation_summary',chat_id:chatId,chat_name:chat.display_name||chat.name||chatId,date_range:{start,end,days},messages_in_range:all.length,messages_selected:selected.length,limited:all.length>MAX_ANALYSIS_MESSAGES,batches_completed:chunks.length,batches_total:batches.length,title:String(d.title||`Conversation summary · ${start} to ${end}`).slice(0,180),executive_summary:String(d.executive_summary||compact.map(x=>x.summary).filter(Boolean).join(' ')).slice(0,3000),day_summaries:daySummaries,main_topics:normalizeList(d.main_topics),decisions:normalizeList(d.decisions),plans_and_commitments:normalizeList(d.plans_and_commitments),open_questions:normalizeList(d.open_questions),notable_events:normalizeList(d.notable_events),communication_dynamics:d.communication_dynamics||{},important_quotes:normalizeList(d.important_quotes),uncertainties:Array.isArray(d.uncertainties)?d.uncertainties.slice(0,8):[],next_steps:Array.isArray(d.next_steps)?d.next_steps.slice(0,8):[],overall_confidence:{percent:Math.min(95,Math.max(20,Number(d.overall_confidence?.percent)||60)),reason:String(d.overall_confidence?.reason||'Summary confidence is based on the selected message set and completed batch coverage.')}};
}


function batchTextMessages(lines, {maxMessages=OLLAMA_BATCH_MESSAGES, maxChars=OLLAMA_BATCH_CHARS, maxBatches=OLLAMA_MAX_BATCHES}={}) {
  const batches=[]; let current=[], chars=0;
  for(const line of lines){
    const cost=String(line).length+1;
    if(current.length && (current.length>=maxMessages || chars+cost>maxChars)){
      batches.push(current.join('\n')); current=[]; chars=0;
    }
    current.push(String(line)); chars+=cost;
  }
  if(current.length)batches.push(current.join('\n'));
  if(batches.length>maxBatches){
    const target=Math.ceil(lines.length/maxBatches), repacked=[];
    for(let i=0;i<lines.length;i+=target) repacked.push(lines.slice(i,i+target).join('\n'));
    return repacked;
  }
  return batches;
}

async function analyzeTextSelection(chatId, selectedText, userInstruction='', signal=null, options={}) {
  const started=Date.now();
  const budgetMs=Number(options?.budget_ms)>0 ? Number(options.budget_ms) : OLLAMA_SELECTION_TIMEOUT_MS;
  const deadline=started+budgetMs;
  const isManualText=Number(options?.budget_ms)>0;
  const standalone=options?.standalone===true;
  const chat=standalone ? {id:null,name:'Pasted text',display_name:'Pasted text',ai_instructions:''} : getChat(chatId);
  if(!chat) throw new Error('Chat not found.');
  const rawSelection=String(selectedText||'').trim();
  if(!rawSelection) throw new Error('Select some message text first.');
  if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
  await ollamaReady(signal);

  let selectedMessages=parseSelectedMessages(rawSelection);
  if(!selectedMessages.length) throw new Error('No readable selected messages were found.');
  if(selectedMessages.length>MAX_ANALYSIS_MESSAGES) selectedMessages=selectedMessages.slice(-MAX_ANALYSIS_MESSAGES);
  const lines=selectedMessages.map(m=>m.raw);
  // IMPORTANT: analysis workload is measured in TEXTS/MESSAGES, not words.
  // We target a fixed number of messages per AI batch so a long message does
  // not consume an unfair share of the analysis quota. Character count is
  // retained only as a secondary Ollama context guard; if it is reached, the
  // batch boundary is moved before that message and no selected message is
  // discarded.
  const batches=batchTextMessages(lines);

  const recent=standalone?[]:getMessages(chatId,24);
  const nearbyContextText=recent.map(m=>`${m.from_me?'ME':'THEM'} [${new Date(m.timestamp||0).toISOString()}]: ${m.body}`).join('\n');
  const standing=String(chat.ai_instructions||'').trim()||'(none)';
  const corrections=standalone?[]:getAnalysisFeedback(chatId,12);
  const aggregate=aggregateToneScores(selectedMessages);
  const toneDistribution=toneDistributionAllMessages(selectedMessages);
  const shifts=toneShiftEvidence(selectedMessages);
  const indirectPool=deterministicIndirectEvidence(selectedMessages);
  const common=`CHAT RULES:\n${standing}\n${corrections.length?corrections.map(f=>`- ${f.kind}: ${f.note}`).join('\n'):'(no corrections)'}\n\n20-TONE TAXONOMY:\n${TONE_GUIDANCE}\n\n${QUOTE_RULE}\n\nINDIRECT-EVIDENCE RULE:\n- Evidence may be DIRECT (literal semantic content) or INDIRECT (change in tone, message length, punctuation, question frequency, reduced/increased warmth, mirroring, teasing, hesitation, abruptness, topic shifts, reciprocity, or sequence effects).\n- Every indirect inference must still cite an EXACT selected-message quote and explain the observable cue.\n- Multiple mutually consistent indirect cues may raise confidence, but ambiguity/counter-evidence must lower it.\n- Never convert indirect evidence into a claim about hidden motives, diagnosis, personality, or certainty.`;

  const chunkResults=[];
  let seenMessages=0;
  for(let i=0;i<batches.length;i++){
    if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
    if(Date.now()>=deadline) throw new Error(`${isManualText?'Text Analysis':'Deep Analysis'} reached its ${Math.round(budgetMs/1000)}-second safety ceiling before every selected message could receive its AI batch pass. Select a shorter passage and try again.`);
    const remainingBeforeBatch=Math.max(1000,deadline-Date.now());
    const batch=batches[i];
    const batchCount=batch.split(/\r?\n/).filter(Boolean).length;
    seenMessages+=batchCount;
    const prompt=`You are batch ${i+1} of ${batches.length} in a larger WhatsApp Deep Analysis. EVERY line in this batch is a selected message and MUST be considered before you answer. Do not cherry-pick only the dramatic lines. Examine direct wording AND indirect changes relative to surrounding messages. Keep this intermediate report compact but cover all eight analytical jobs separately.\n\n${common}\n\nBATCH ${i+1}/${batches.length} — ${batchCount} selected messages (${batch.length} characters):\n${batch}\n\nReturn ONLY JSON:\n{\n "messages_considered":${batchCount},\n "tone_scores":{"warm":0,"affectionate":0,"friendly":0,"playful":0,"humorous":0,"sarcastic":0,"flirty":0,"casual":0,"curious":0,"enthusiastic":0,"excited":0,"confident":0,"direct":0,"professional":0,"formal":0,"serious":0,"reassuring":0,"concerned":0,"frustrated":0,"neutral":0},\n "deep":{\n  "overall":{"conclusion":"","percent":0,"evidence":[{"quote":"","evidence_type":"direct|indirect","cue":"","justification":"","principle":""}],"counter_evidence":[]},\n  "attitude":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},\n  "sarcasm_humour":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},\n  "psychology":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},\n  "risks":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},\n  "evidence":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},\n  "strategy":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[],"steps":[]},\n  "alternatives":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[],"options":[]}\n },\n "tone_shifts":[{"quote":"","previous_quote":"","change":"","cue":"","percent":0}],\n "summary":""\n}`;
    let raw='';
    try {
      raw=await callOllama(prompt,{json:true,temperature:0.10,timeoutMs:Math.min(OLLAMA_BATCH_TIMEOUT_MS,Math.max(1000,remainingBeforeBatch-500)),signal,numPredict:1350,numCtx:OLLAMA_BATCH_NUM_CTX});
    } catch(err){
      if(String(err?.message)==='CANCELLED_BY_USER'||signal?.aborted) throw new Error('Stopped by user.');
      const msg=String(err?.message||err);
      if(!/timeout|OLLAMA request failed \(5|Could not reach Ollama/i.test(msg)) throw err;
      await new Promise(r=>setTimeout(r,800));
      try { raw=await callOllama(`RETRY: Be concise, but still return all 8 deep sections and consider every batch message. Valid JSON only.\n${prompt}`,{json:true,temperature:0.05,timeoutMs:Math.min(OLLAMA_BATCH_RETRY_TIMEOUT_MS,Math.max(1000,deadline-Date.now()-500)),signal,numPredict:850,numCtx:OLLAMA_BATCH_NUM_CTX}); }
      catch(retryErr){ if(signal?.aborted) throw new Error('Stopped by user.'); raw=''; }
    }
    const d=cleanJson(raw) || {messages_considered:batchCount,deep:{},tone_scores:{},tone_shifts:[],summary:'Local AI did not complete this batch; deterministic evidence will cover its selected messages.'};
    d.messages_considered=Number(d.messages_considered)||batchCount;
    chunkResults.push(d);
  }

  const quoteCtx=buildQuoteContext(rawSelection);
  const directPool=chunkResults.flatMap((x,i)=>Object.values(x.deep||{}).flatMap(sec=>(Array.isArray(sec?.evidence)?sec.evidence:[]).map(e=>({...e,batch:i+1})))).filter(e=>e?.quote).slice(0,120);
  const combinedIndirect=[...shifts,...indirectPool,...chunkResults.flatMap(x=>Array.isArray(x.tone_shifts)?x.tone_shifts.map(e=>({...e,evidence_type:'indirect',justification:e.justification||'This evidence comes from a change between selected messages.',principle:e.principle||'Temporal/context effects + emotional signaling'})):[])].filter(e=>e?.quote).slice(0,80);
  const fallbackDeep=mergeChunkDeepSections(chunkResults,selectedMessages,directPool,combinedIndirect);
  const compactChunks=chunkResults.map((x,i)=>({batch:i+1,messages_considered:x.messages_considered,summary:String(x.summary||'').slice(0,700),deep:Object.fromEntries(Object.entries(x.deep||{}).map(([k,v])=>[k,{conclusion:String(v?.conclusion||'').slice(0,500),percent:v?.percent,evidence:(v?.evidence||[]).slice(0,2),counter_evidence:(v?.counter_evidence||[]).slice(0,1)}]))}));

  const synthesisPrompt=`You are the FINAL synthesis stage of a WhatsApp Deep Analysis. The batch stage considered the selected conversation in bounded chronological batches. Produce EIGHT DISTINCT sections; do not collapse one section into another. Use the batch reports plus the verified direct/indirect evidence pools. Every section must have at least one exact evidence quote, and preferably 2-4. Indirect evidence is allowed and important when it is based on observable change in tone, brevity, punctuation, questioning, mirroring, hesitation, teasing, reciprocity, or sequence. Calculate each section's confidence independently from that section's evidence; never copy a confidence value across categories and never use 50/54/60/etc. as a default. If evidence is weak or mixed, use a lower confidence and explicitly state the limitation. Every conclusion must be traceable to its listed evidence items. Before finalizing, silently verify each quote you are about to output actually appears in the selected messages or the batch reports above; if unsure, fix it to the exact wording or drop it and lower that section's confidence.\n\n${common}\n\nUSER EXTRA REQUEST:\n${String(userInstruction||'').slice(0,4000)||'(none)'}\n\nTOTAL SELECTED MESSAGES: ${selectedMessages.length}\nBATCHES COMPLETED: ${chunkResults.length}/${batches.length}\nBATCH REPORTS:\n${JSON.stringify(compactChunks)}\n\nDETERMINISTIC TONE-SHIFT / INDIRECT CUES:\n${JSON.stringify(combinedIndirect.slice(0,40))}\n\nNEARBY CONTEXT (ambiguity only; evidence must still come from selected messages):\n${nearbyContextText}\n\nReturn ONLY JSON:\n{\n "tone":"one allowed tone label",\n "secondary_tones":["up to three allowed tone labels"],\n "attitude":{"summary":"","quote":"","percent":0,"principle":"Emotional signaling / attribution & ambiguity"},\n "reasoning":"brief overall observation -> direct/indirect evidence -> interpretation -> alternative",\n "psychology_lenses":[{"principle":"","quote":"","percent":0,"interpretation":"","observable_clue":"","evidence_type":"direct|indirect","cue":""}],\n "evidence":[{"quote":"","point":"","justification":"","principle":"","evidence_type":"direct|indirect","cue":""}],\n "counter_evidence":[{"quote":"","point":"","justification":"","principle":"Attribution & ambiguity"}],\n "sarcasm":{"detected":false,"percent":0,"quote":"","explanation":"","principle":"Sarcasm & incongruity"},\n "humor":{"detected":false,"percent":0,"quote":"","explanation":"","principle":"Humour & play"},\n "argumentative":{"detected":false,"percent":0,"quote":"","explanation":"","principle":"Conflict & de-escalation"},\n "deep_analysis":{\n  "overall":{"conclusion":"overall meaning across the whole selection","percent":0,"evidence":[],"counter_evidence":[]},\n  "attitude":{"conclusion":"likely textual stance/attitude, not hidden emotion","percent":0,"evidence":[],"counter_evidence":[]},\n  "sarcasm_humour":{"conclusion":"literal-vs-implied meaning, teasing, irony and humour","percent":0,"evidence":[],"counter_evidence":[]},\n  "psychology":{"conclusion":"communication mechanisms only, no diagnosis","percent":0,"evidence":[],"counter_evidence":[]},\n  "risks":{"conclusion":"specific misunderstanding/escalation/boundary risks","percent":0,"evidence":[],"counter_evidence":[]},\n  "evidence":{"conclusion":"strongest evidence chain and why it matters","percent":0,"evidence":[],"counter_evidence":[]},\n  "strategy":{"conclusion":"next communication approach justified by evidence","percent":0,"evidence":[],"counter_evidence":[],"steps":[]},\n  "alternatives":{"conclusion":"credible competing interpretations","percent":0,"evidence":[],"counter_evidence":[],"options":["at least 2 plausible alternatives"]}\n },\n "temporal_context":"describe meaningful tone/interaction changes across the selected sequence",\n "alternative_interpretation":"",\n "overall_confidence":{"percent":0,"quote":"","principle":"Evidence-weighted confidence"}\n}`;

  let finalRaw='';
  if(Date.now()>=deadline){
    if(isManualText){
      finalRaw='';
    } else {
      throw new Error(`Deep Analysis reached its ${Math.round(budgetMs/1000)}-second safety ceiling before final synthesis.`);
    }
  } else {
    try { finalRaw=await callOllama(synthesisPrompt,{json:true,temperature:0.08,timeoutMs:Math.min(OLLAMA_BATCH_TIMEOUT_MS,Math.max(1000,deadline-Date.now()-500)),signal,numPredict:1900,numCtx:OLLAMA_BATCH_NUM_CTX}); }
    catch(err){
      if(String(err?.message)==='CANCELLED_BY_USER'||signal?.aborted) throw new Error('Stopped by user.');
      const msg=String(err?.message||err);
      if(/timeout|OLLAMA request failed \(5|Could not reach Ollama/i.test(msg)){
        const retryBudget=Math.max(1000,deadline-Date.now()-500);
        if(retryBudget>=5000){
          try { finalRaw=await callOllama(`FINAL RETRY: Return the same schema compactly. Every one of the 8 sections needs evidence.\n${synthesisPrompt}`,{json:true,temperature:0.04,timeoutMs:Math.min(OLLAMA_BATCH_RETRY_TIMEOUT_MS,retryBudget),signal,numPredict:1100,numCtx:OLLAMA_BATCH_NUM_CTX}); }
          catch(_){ finalRaw=''; }
        }
      } else throw err;
    }
  }

  const d=cleanJson(finalRaw)||{};
  d.deep_analysis=ensureDeepSections(d.deep_analysis||{},fallbackDeep,quoteCtx,selectedMessages,directPool,combinedIndirect);
  if(!d.attitude?.summary) d.attitude={summary:d.deep_analysis.attitude.conclusion,quote:d.deep_analysis.attitude.evidence[0]?.quote||'',percent:d.deep_analysis.attitude.percent,principle:'Emotional signaling / attribution & ambiguity'};
  if(!Array.isArray(d.evidence)||!d.evidence.length) d.evidence=d.deep_analysis.evidence.evidence;
  if(!Array.isArray(d.psychology_lenses)||!d.psychology_lenses.length) d.psychology_lenses=d.deep_analysis.psychology.evidence.map(e=>({principle:e.principle,quote:e.quote,percent:e.percent,interpretation:e.justification||e.interpretation||e.point,observable_clue:e.cue||'',evidence_type:e.evidence_type,cue:e.cue}));
  if(!d.reasoning) d.reasoning=d.deep_analysis.overall.conclusion;
  if(!d.tone) d.tone=Object.entries(toneDistribution).sort((a,b)=>b[1]-a[1])[0]?.[0]||'neutral';
  d.tone_scores=toneDistribution;
  d.temporal_context=String(d.temporal_context||shifts.slice(-5).map(x=>x.cue).join(' ')).trim();
  d.alternative_interpretation=String(d.alternative_interpretation||d.deep_analysis.alternatives.options?.[0]||d.deep_analysis.alternatives.conclusion).trim();
  if(!d.overall_confidence?.quote) d.overall_confidence={percent:d.deep_analysis.overall.percent,quote:d.deep_analysis.overall.evidence[0]?.quote||selectedMessages[selectedMessages.length-1].body,principle:'Evidence-weighted confidence'};

  const result=normalizeSelectionAnalysis(d,quoteCtx);
  result.deep_analysis=d.deep_analysis;
  result.tone_scores=toneDistribution;
  result.tone_distribution=toneDistribution;
  result.tone_comparison=Array.isArray(d.tone_comparison)?d.tone_comparison.slice(0,3):[];
  result.counter_evidence=normalizeEvidenceList(d.counter_evidence,['point','justification'],6,quoteCtx,{principle:'Attribution & ambiguity'});
  result.contact_baseline=standalone?{sample_size:0,tone_scores:{},typical_length:0,typical_questions:0,note:'Standalone pasted text has no contact-history baseline.'}:buildContactBaseline(chatId);
  result.alternative_interpretation=String(d.alternative_interpretation||'').trim();
  const processedMessages=chunkResults.reduce((n,x)=>n+(Number(x.messages_considered)||0),0);
  result.analysis_scope={selected_messages:selectedMessages.length,messages_considered:Math.min(selectedMessages.length,processedMessages),batches_total:batches.length,batches_completed:chunkResults.length,characters:rawSelection.length,method:'Message-count based: every selected text is processed; fixed message-count batches with character count used only as an Ollama context safety guard → 8-section synthesis + deterministic direct/indirect evidence completion',confidence_method:'Evidence-first calibration: verified quote quality + section-specific observable signals + limited model score; fixed/default confidence values are never accepted as final scores',coverage_percent:selectedMessages.length?Math.round(Math.min(1,processedMessages/selectedMessages.length)*100):100};
  result.tone_shifts=shifts;
  result.analysis_visuals=standalone?{baseline:{sample_size:0},current:{sample_size:selectedMessages.length},changes:[],tone_changes:[],timeline:[],turning_points:[],evidence_explorer:[]}:buildAnalysisVisuals(chatId,selectedMessages);
  return result;
}

function normalizeSelectionAnalysis(d, quoteCtx) {
  return {
    tone: normalizeTone({id:d.tone,label:d.tone,quote:d.attitude?.quote,percent:d.attitude?.percent,principle:d.attitude?.principle},quoteCtx).label,
    secondary_tones:Array.isArray(d.secondary_tones)?d.secondary_tones.slice(0,3).map(t=>normalizeTone(typeof t==='string'?{id:t,label:t}:t,quoteCtx)):[],
    tone_scores:d.tone_scores&&typeof d.tone_scores==='object'?d.tone_scores:{},
    tone_comparison:Array.isArray(d.tone_comparison)?d.tone_comparison.slice(0,3):[],
    attitude:normalizeEvidenceItem(d.attitude,['summary'],quoteCtx,{principle:'Emotional signaling / attribution & ambiguity'}),
    reasoning:String(d.reasoning||'').trim(),
    psychology_lenses:normalizeEvidenceList(d.psychology_lenses,['principle','interpretation','observable_clue'],10,quoteCtx,{principle:'Communication principle selected from observable evidence'}),
    evidence:normalizeEvidenceList(d.evidence,['point','justification'],12,quoteCtx,{principle:'Direct/indirect textual observation'}),
    counter_evidence:normalizeEvidenceList(d.counter_evidence,['point','justification'],8,quoteCtx,{principle:'Attribution & ambiguity'}),
    sarcasm:normalizeEvidenceItem(d.sarcasm,['explanation'],quoteCtx,{principle:'Sarcasm & incongruity'}),
    humor:normalizeEvidenceItem(d.humor,['explanation'],quoteCtx,{principle:'Humour & play'}),
    playfulness:normalizeEvidenceItem(d.playfulness,[],quoteCtx,{principle:'Humour & play'}),
    grumpiness:normalizeEvidenceItem(d.grumpiness,[],quoteCtx,{principle:'Emotional signaling / conflict & de-escalation'}),
    argumentative:normalizeEvidenceItem(d.argumentative,['explanation'],quoteCtx,{principle:'Conflict & de-escalation'}),
    temporal_context:String(d.temporal_context||'').trim(),
    alternative_interpretation:String(d.alternative_interpretation||'').trim(),
    overall_confidence:normalizeEvidenceItem(d.overall_confidence,[],quoteCtx,{principle:'Evidence-weighted confidence'})
  };
}


// ---------------------------------------------------------------------------
// COUNTERFACTUAL SIMULATOR
// Tests a user-specified alternate version of one message and estimates how
// the observable conversation could plausibly unfold differently. This is a
// simulation, not a prediction of another person's private thoughts.
// ---------------------------------------------------------------------------
async function simulateCounterfactual(chatId, targetMessageId, hypotheticalText, objective='', signal=null) {
  const started=Date.now();
  const chat=getChat(chatId); if(!chat) throw new Error('Chat not found.');
  const targetId=String(targetMessageId||'').trim();
  const hypothetical=String(hypotheticalText||'').trim();
  if(!targetId) throw new Error('Choose a message to change.');
  if(!hypothetical) throw new Error('Enter the hypothetical replacement message.');
  if(hypothetical.length>4000) throw new Error('The hypothetical message is limited to 4,000 characters.');
  if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
  await ollamaReady(signal);
  const all=getAllMessages(chatId).filter(m=>String(m.body||'').trim()).sort((a,b)=>normalizeTimestamp(a.timestamp)-normalizeTimestamp(b.timestamp));
  const idx=all.findIndex(m=>String(m.id)===targetId);
  if(idx<0) throw new Error('The selected message is no longer available. Sync the conversation and try again.');
  const target=all[idx];
  const start=Math.max(0,idx-35), end=Math.min(all.length,idx+36);
  const context=all.slice(start,end);
  const contextLines=context.map((m,i)=>`${i===idx?'TARGET':'CONTEXT'} | ${m.from_me?'ME':'THEM'} | ${new Date(normalizeTimestamp(m.timestamp)).toISOString()} | #${start+i} | ${String(m.body||'').replace(/\r?\n/g,' ')}`);
  const standing=String(chat.ai_instructions||'').trim()||'(none)';
  const corrections=getAnalysisFeedback(chatId,12);
  const baseline=buildContactBaseline(chatId);
  const prompt=`You are a counterfactual conversation simulator for a WhatsApp analysis tool.\n\nGOAL: Compare the real conversation with a hypothetical replacement for exactly ONE target message. Simulate plausible downstream communication patterns, not private thoughts. Never present a hypothetical outcome as a fact.\n\nCHAT RULES:\n${standing}\n${corrections.length?corrections.map(f=>`- ${f.kind}: ${f.note}`).join('\\n'):'(no corrections)'}\n\nUSER OBJECTIVE:\n${String(objective||'').slice(0,3000)||'(no extra objective)'}\n\nREAL TARGET MESSAGE:\n${target.from_me?'ME':'THEM'}: ${target.body}\n\nHYPOTHETICAL REPLACEMENT:\n${hypothetical}\n\nLOCAL CONVERSATION WINDOW (real messages; do not invent quotes):\n${contextLines.join('\\n')}\n\nCONTACT BASELINE (if available):\n${JSON.stringify(baseline||{})}\n\nSIMULATION RULES:\n- First identify what changes between the real target and hypothetical replacement: directness, warmth, ambiguity, humor, pressure, question/request, boundary, etc.\n- Then simulate 2-3 plausible downstream branches. Each branch must explain why it is plausible from observable conversation patterns.\n- Do not claim to know what the other person will feel, think, or do. Use language such as likely response pattern, plausible branch, or uncertainty.\n- Do not diagnose psychology. Discuss communication mechanisms only.\n- Preserve chronology.\n- Exact real-message quotes must be copied from the supplied context. The hypothetical text is not evidence from the real conversation.\n- Include a base-case branch and at least one materially different branch when uncertainty warrants it.\n- The simulator should be useful for deciding what to say, not merely restating the analysis.\n\nReturn ONLY JSON:\n{\n "change_analysis":{"what_changed":"","communication_effect":"","risk_change":"","confidence":0},\n "branches":[{"name":"","likelihood_percent":0,"likely_next_response_pattern":"","downstream_effect":"","why_plausible":"","supporting_real_quotes":[{"quote":"","why":""}],"uncertainties":[""]}],\n "most_plausible_branch":"",\n "decision_guidance":"",\n "alternative_hypotheticals":[{"message":"","expected_effect":""}],\n "simulation_limits":[""]\n}`;
  let raw='';
  try{raw=await callOllama(prompt,{json:true,temperature:.18,timeoutMs:OLLAMA_BATCH_TIMEOUT_MS,signal,numPredict:1800,numCtx:OLLAMA_BATCH_NUM_CTX});}
  catch(err){
    if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
    const msg=String(err?.message||err);
    if(!/timeout|OLLAMA request failed \(5|Could not reach Ollama/i.test(msg)) throw err;
    raw=await callOllama(`RETRY CONCISELY. Return valid JSON only.\n${prompt}`,{json:true,temperature:.08,timeoutMs:OLLAMA_BATCH_RETRY_TIMEOUT_MS,signal,numPredict:1200,numCtx:OLLAMA_BATCH_NUM_CTX}).catch(()=> '');
  }
  const d=cleanJson(raw)||{};
  const validQuotes=new Set(context.map(m=>String(m.body||'').trim()).filter(Boolean));
  const exactQuote=q=>{q=String(q||'').trim(); if(!q)return ''; const hit=[...validQuotes].find(x=>x===q||x.includes(q)||q.includes(x)); return hit||'';};
  const branches=Array.isArray(d.branches)?d.branches.slice(0,4).map((b,i)=>({
    name:String(b?.name||`Plausible branch ${i+1}`).slice(0,180),
    likelihood_percent:Math.min(90,Math.max(5,Number(b?.likelihood_percent)||Math.round(100/Math.max(1,Math.min(3,d.branches.length))))),
    likely_next_response_pattern:String(b?.likely_next_response_pattern||'').slice(0,1000),
    downstream_effect:String(b?.downstream_effect||'').slice(0,1200),
    why_plausible:String(b?.why_plausible||'').slice(0,1200),
    supporting_real_quotes:Array.isArray(b?.supporting_real_quotes)?b.supporting_real_quotes.slice(0,4).map(q=>({quote:exactQuote(q?.quote),why:String(q?.why||'').slice(0,700)})).filter(q=>q.quote):[],
    uncertainties:Array.isArray(b?.uncertainties)?b.uncertainties.slice(0,5).map(x=>String(x).slice(0,500)):[]
  })):[];
  return {
    mode:'counterfactual', chat_id:chatId, chat_name:chat.display_name||chat.name||chatId,
    target_message:{id:target.id,sender:target.from_me?'ME':'THEM',timestamp:target.timestamp,real_text:String(target.body||''),hypothetical_text:hypothetical},
    objective:String(objective||'').trim(), context_messages:context.length, context_start:start, context_end:end,
    change_analysis:{what_changed:String(d.change_analysis?.what_changed||'').slice(0,1500),communication_effect:String(d.change_analysis?.communication_effect||'').slice(0,1500),risk_change:String(d.change_analysis?.risk_change||'').slice(0,1200),confidence:Math.min(95,Math.max(15,Number(d.change_analysis?.confidence)||45))},
    branches,
    most_plausible_branch:String(d.most_plausible_branch||branches[0]?.name||'').slice(0,500),
    decision_guidance:String(d.decision_guidance||'').slice(0,1800),
    alternative_hypotheticals:Array.isArray(d.alternative_hypotheticals)?d.alternative_hypotheticals.slice(0,5).map(x=>({message:String(x?.message||'').slice(0,1000),expected_effect:String(x?.expected_effect||'').slice(0,1000)})).filter(x=>x.message):[],
    simulation_limits:Array.isArray(d.simulation_limits)?d.simulation_limits.slice(0,8).map(x=>String(x).slice(0,600)):['A simulation describes plausible communication paths; it cannot know another person’s private thoughts or guarantee a future response.'],
    analysis_scope:{messages_in_context:context.length,method:'One-message replacement + local chronological context + contact baseline + bounded Ollama simulation',elapsed_ms:Date.now()-started}
  };
}

async function draftReply(chatId, instruction = '') {
  const result = await analyzeAndDraft(chatId, instruction, {
    draft: true, psychology: false, attitude: false, intent: false,
    evidence: false, signals: false, risks: false, strategy: false, alternatives: false
  });
  return result.response;
}

async function prioritize() {
  const chats = listChats();
  const pending = chats.filter(c => c.unread_from_them > 0);
  if (!pending.length) return { summary: 'You are caught up — nothing waiting on a reply.', items: [] };
  const scored = pending.map(c => {
    const unread = getMessages(c.id, 30).filter(m => !m.from_me);
    const { score, factors } = scoreChat(c, unread);
    return { chat: c, score, factors, tier: priorityTier(score) };
  }).sort((a, b) => b.score - a.score).slice(0, 15);
  const items = scored.map(s => ({
    chat_id: s.chat.id, chat_name: s.chat.name, priority: s.tier, score: s.score,
    factors: s.factors,
    reason: fallbackReason(s.factors),
    suggested_action: s.factors.open_loop ? 'Answer the direct question or request first.' : 'Reply when practical, starting with the most overdue conversation.'
  }));
  return { summary: `${pending.length} chat(s) waiting on you, ranked using response-time, reciprocity, open-loop and reactivation signals.`, items };
}

function fallbackReason(f) {
  if (f.open_loop) return 'There is a direct question or request waiting.';
  if (f.z_score > 1) return `You have waited longer than usual here (~${f.wait_hours}h vs ~${f.baseline_mean_hours}h typical).`;
  if (f.equity_debt > 0.5) return 'Several incoming messages are waiting without a recent reply from you.';
  if (f.weak_tie_reactivation > 0.5) return 'They reached out after an unusually long quiet period.';
  return 'Worth reviewing when you have a moment.';
}


// ---------------------------------------------------------------------------
// RELATIONSHIP MODE — deliberately separate from ordinary Deep Analysis.
// It compares up to two chosen conversations against a user-stated objective.
// Every stored message in every chosen conversation receives a bounded batch
// pass. The final stage only sees compact batch findings + verified evidence,
// so the final prompt stays small without silently dropping messages.
// ---------------------------------------------------------------------------
const RELATIONSHIP_STATUSES = [
  {id:'currently_with',label:'Currently with'},
  {id:'trying_to_get_with',label:'Trying to get with'},
  {id:'talking_exploring',label:'Talking / exploring'},
];
const RELATIONSHIP_TONES = [
  ['flirtatious','Flirtatious'],['affectionate','Affectionate'],['interested','Interested'],
  ['insecure_uncertain','Insecure / uncertain'],['complimentary','Complimentary'],['teasing','Teasing'],
  ['playful','Playful'],['vulnerable','Vulnerable'],['warm','Warm'],['attentive','Attentive'],
  ['curious','Curious'],['enthusiastic','Enthusiastic'],['excited','Excited'],['reassuring','Reassuring'],
  ['reserved','Reserved'],['distant','Distant'],['frustrated','Frustrated'],['ambivalent','Ambivalent'],
  ['jealous','Jealous / possessive'],['supportive','Supportive']
];
const RELATIONSHIP_TONE_GUIDANCE = RELATIONSHIP_TONES.map(([id,label])=>`- ${label} (${id})`).join('\n');
const RELATIONSHIP_PRINCIPLES = [
  ['Reciprocity & investment','Compare initiation, follow-up, responsiveness, effort and mutual conversational contribution.'],
  ['Self-disclosure & vulnerability','Look for increasing personal disclosure, admissions, uncertainty, openness and risk-taking in what is actually said.'],
  ['Uncertainty reduction','Track questions, clarification, reassurance-seeking and attempts to establish where the relationship stands.'],
  ['Flirting & courtship signaling','Look for teasing, compliments, playful escalation, personal attention and romantic ambiguity; never treat one cue alone as proof of attraction.'],
  ['Affiliative humor & teasing','Assess whether jokes/teasing are reciprocal, warm, one-sided, defensive, or followed by repair.'],
  ['Positive regard & complimenting','Distinguish generic politeness from specific, personal, repeated or effortful positive regard.'],
  ['Attachment-related signaling','Use only observable communication patterns such as reassurance-seeking, closeness bids, withdrawal and repair; never diagnose attachment style.'],
  ['Face-saving & dignity','Notice softening, indirectness, embarrassment management, boundaries and language that protects social image.'],
  ['Emotional signaling','Use wording, punctuation, emojis, timing, repetition and intensity as signals rather than proof of private feelings.'],
  ['Mirroring & accommodation','Look for changes toward the other person’s vocabulary, message length, humor, emoji use or conversational rhythm.'],
  ['Responsiveness & availability','Compare whether bids for connection are answered, ignored, delayed, expanded or redirected.'],
  ['Relational repair','Look for apologies, clarification, reassurance and attempts to restore warmth after friction or misunderstanding.'],
  ['Boundary signaling','Identify explicit or indirect limits, topic avoidance, reduced engagement and respect for stated boundaries.'],
  ['Investment asymmetry','Compare effort and initiative over time without assuming motive from silence alone.'],
  ['Approach–avoidance tension','Identify sequences where closeness bids are followed by hesitation, retreat or renewed approach.'],
  ['Social proof & contextual calibration','Interpret behavior relative to the same person’s baseline and the surrounding conversational context.'],
  ['Temporal escalation','Look for meaningful changes across days/weeks rather than treating every message as equally representative.'],
  ['Attribution & alternative explanations','Separate what the messages show from why a person may have behaved that way; keep competing explanations alive.']
];
const RELATIONSHIP_PRINCIPLE_TEXT = RELATIONSHIP_PRINCIPLES.map(x=>`- ${x[0]}: ${x[1]}`).join('\n');

function relationshipToneVector(body='') {
  const t=String(body||'').trim().toLowerCase();
  const s=Object.fromEntries(RELATIONSHIP_TONES.map(([id])=>[id,0]));
  if(!t) return s;
  const add=(id,n)=>{s[id]=Math.min(100,s[id]+n)};
  if(/\b(love|miss you|miss u|baby|babe|darling|cutie|sweetheart)\b|❤️|💕|💗|🥰|😘|😍/i.test(body)) {add('affectionate',55);add('warm',22);}
  if(/\b(hot|cute|gorgeous|handsome|beautiful|pretty|stunning|sexy)\b/i.test(body)) {add('complimentary',60);add('flirtatious',24);}
  if(/\b(flirt|date|kiss|kissing|crush|like you|into you|miss me|us\?|together)\b/i.test(body)) add('flirtatious',55);
  if(/😂|🤣|😏|😉|😜|lmao|lol|haha|hehe/i.test(body)) {add('playful',38);add('teasing',24);}
  if(/\b(i'm insecure|im insecure|i feel insecure|worried|scared|afraid|overthinking|do you still|are you mad|you don't like|you hate me|am i)\b/i.test(body)) {add('insecure_uncertain',62);add('vulnerable',25);}
  if(/\b(thank you|thanks|proud of you|here for you|take care|don't worry|it's okay|you got this)\b/i.test(body)) add('supportive',52);
  if(/\?|\b(what|why|how|when|where|who)\b/i.test(body)) add('curious',25);
  if(/\b(can't wait|cant wait|so excited|yay|omg|amazing)\b|🎉|🥳/i.test(body)) {add('excited',55);add('enthusiastic',25);}
  if(/\b(maybe|idk|not sure|we'll see|we will see|i guess)\b/i.test(body)) {add('ambivalent',45);add('reserved',20);}
  if(/\b(leave me|whatever|k|ok\.|fine\.|don't care|busy|later)\b/i.test(body) && t.length<100) add('distant',38);
  if(/\b(why her|why him|who is she|who is he|your ex|are you talking to)\b/i.test(body)) add('jealous',48);
  if(/\b(annoyed|irritated|frustrated|seriously|ugh)\b/i.test(body)) add('frustrated',45);
  if(/\b(attention|you remembered|you noticed|you always|you know me)\b/i.test(body)) add('attentive',38);
  if(/\b(want to|would you|let's|lets|come over|see you|call me|text me)\b/i.test(body)) add('interested',32);
  if(t.length<5) add('reserved',12);
  if(Object.values(s).every(v=>v===0)) add('warm',8);
  return s;
}
function relationshipToneDistribution(messages=[]) {
  const totals=Object.fromEntries(RELATIONSHIP_TONES.map(([id])=>[id,0]));
  for(const m of messages){const v=relationshipToneVector(m.body);for(const [id,n] of Object.entries(v)) totals[id]+=n;}
  let sum=Object.values(totals).reduce((a,b)=>a+b,0); if(!sum){totals.reserved=1;sum=1;}
  const out={}; let running=0; const ids=RELATIONSHIP_TONES.map(x=>x[0]);
  ids.forEach((id,i)=>{const pct=i===ids.length-1?Math.max(0,100-running):Math.round(totals[id]/sum*1000)/10;out[id]=pct;running=Math.round((running+pct)*10)/10;});
  const drift=Math.round((100-Object.values(out).reduce((a,b)=>a+b,0))*10)/10;if(Math.abs(drift)>0){const k=Object.entries(out).sort((a,b)=>b[1]-a[1])[0]?.[0]||'reserved';out[k]=Math.max(0,Math.round((out[k]+drift)*10)/10);}return out;
}
function relationshipIndirectEvidence(messages=[]) {
  const out=[]; const rows=messages.map((m,i)=>({m,i,v:relationshipToneVector(m.body)}));
  for(let i=0;i<rows.length;i++){
    const r=rows[i], body=String(r.m.body||'').trim(); if(!body) continue;
    const top=Object.entries(r.v).sort((a,b)=>b[1]-a[1])[0]; const cues=[];
    if(/[!?]{2,}/.test(body)) cues.push('repeated punctuation / intensity');
    if(/😂|🤣|😏|😉|😜|lol|lmao|haha|hehe/i.test(body)) cues.push('humour/play marker');
    if(/❤️|💕|💗|🥰|😘|😍/i.test(body)) cues.push('affection-coded emoji');
    if(/\?/.test(body)) cues.push('question / engagement bid');
    if(/\.\.\.|…/.test(body)) cues.push('ellipsis / possible hesitation');
    if(body.split(/\s+/).filter(Boolean).length<=4) cues.push('very short reply / reduced elaboration');
    if(i>0){const prev=rows[i-1].m.body||'';const pv=rows[i-1].v;const prevTop=Object.entries(pv).sort((a,b)=>b[1]-a[1])[0];if(prevTop&&top&&prevTop[0]!==top[0]&&Math.max(prevTop[1],top[1])>=35)cues.push(`shift from ${prevTop[0]} to ${top[0]}`);}
    if(cues.length||((top?.[1]||0)>=50)) out.push({quote:body,evidence_type:'indirect',cue:cues.join('; ')||`${top[0]} textual signal`,justification:'Observable change in wording, form, intensity or sequence. This is evidence about communication behavior, not proof of a hidden feeling.',principle:'Emotional signaling / temporal escalation',percent:Math.min(86,Math.max(35,top?.[1]||40)),previous_quote:i>0?String(rows[i-1].m.body||'').trim():''});
  }
  return out.slice(-80);
}
function relationshipEvidenceNormalize(items, quoteCtx, fallback=[]) {
  const src=(Array.isArray(items)&&items.length?items:fallback).filter(Boolean);
  return src.slice(0,8).map(e=>normalizeEvidenceItem({...e,justification:e.justification||e.interpretation||e.point||e.explanation||'Evidence-linked relationship inference.'},['justification','interpretation','point','explanation'],quoteCtx,{principle:'Relationship psychology / attribution & ambiguity'}));
}
function relationshipMergeSections(chunks, selectedMessages, evidencePool, indirectPool) {
  const ids=['objective_alignment','relationship_dynamic','attraction_interest','insecurity_vulnerability','flirting_affection','reciprocity_effort','barriers_risks','strategy'];
  const defaults={
    objective_alignment:'The objective should be evaluated against observable patterns of interest, reciprocity and boundaries.',
    relationship_dynamic:'The conversations show a relationship pattern that should be interpreted from repeated behavior rather than isolated messages.',
    attraction_interest:'Interest is assessed from repeated attention, engagement and context rather than a single flirtatious line.',
    insecurity_vulnerability:'Uncertainty or vulnerability is assessed only from observable reassurance-seeking, hesitation or self-disclosure.',
    flirting_affection:'Flirting and affection are assessed from reciprocal teasing, compliments, warmth and romantic ambiguity.',
    reciprocity_effort:'Relational investment is assessed by initiation, responsiveness, follow-up and conversational effort.',
    barriers_risks:'Potential barriers are framed as observable friction, asymmetry or boundary signals, not diagnoses.',
    strategy:'Suggested next steps are calibrated to the objective, evidence, reciprocity and boundaries.'
  };
  const out={};
  for(const id of ids){const parts=chunks.map(x=>x.relationship?.[id]).filter(Boolean);const ev=parts.flatMap(x=>Array.isArray(x.evidence)?x.evidence:[]).filter(e=>e?.quote);const fb=evidencePool.filter(e=>e?.quote).slice(0,3);const fallbackRaw=(fb.length?fb:indirectPool); const fallbackAny=fallbackRaw.length?fallbackRaw:[...selectedMessages].slice(0,2).map(m=>({quote:m.raw,evidence_type:'indirect',cue:'Contextual baseline evidence from the selected conversation.',justification:'This message is included as contextual evidence because the section had no stronger relationship-specific signal. It should not be treated as proof of a hidden feeling.',principle:'Attribution & alternative explanations',percent:22})); const evidence=relationshipEvidenceNormalize(ev,buildQuoteContext(selectedMessages.map(m=>m.raw).join('\n')),fallbackAny);const pct=Math.min(94,Math.max(20,Math.round((parts.length?parts.reduce((a,x)=>a+(Number(x.percent)||45),0)/parts.length:40)+(evidence.filter(x=>x.example_verified).length*4))));out[id]={conclusion:parts.map(x=>String(x.conclusion||'')).filter(Boolean).join(' ').slice(0,1800)||defaults[id],percent:pct,evidence,counter_evidence:parts.flatMap(x=>Array.isArray(x.counter_evidence)?x.counter_evidence:[]).filter(e=>e?.quote).slice(0,4)};}
  return out;
}

async function analyzeRelationshipMode(chatIds=[], objective='', relationshipStatus='talking_exploring', signal=null) {
  const started=Date.now();
  const ids=[...new Set((Array.isArray(chatIds)?chatIds:[]).map(String).map(x=>x.trim()).filter(Boolean))].slice(0,2);
  if(!ids.length) throw new Error('Choose at least one conversation.');
  if(!String(objective||'').trim()) throw new Error('List the relationship objective you want the analysis to evaluate.');
  if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
  await ollamaReady(signal);
  const conversations=[]; const allMessages=[];
  for(let ci=0;ci<ids.length;ci++){
    const chat=getChat(ids[ci]); if(!chat) throw new Error(`Conversation ${ids[ci]} was not found.`);
    const ms=getAllMessages(ids[ci]);
    conversations.push({chat_id:ids[ci],name:chat.display_name||chat.name||ids[ci],messages:ms});
    ms.forEach((m,index)=>allMessages.push({...m,__conversation_index:ci+1,__conversation_name:chat.display_name||chat.name||ids[ci],__index:index+1}));
  }
  if(!allMessages.length) throw new Error('The chosen conversation(s) contain no stored messages. Sync WhatsApp history first.');
  // Hard safety ceiling: relationship mode considers the 5,000 most recent messages across the chosen conversations.
  allMessages.sort((a,b)=>Number(a.timestamp||0)-Number(b.timestamp||0));
  const selectedMessages=allMessages.length>MAX_ANALYSIS_MESSAGES?allMessages.slice(-MAX_ANALYSIS_MESSAGES):allMessages;
  const lines=selectedMessages.map(m=>`CONVERSATION ${m.__conversation_index} — ${m.__conversation_name} — ${m.from_me?'ME':'THEM'} [${new Date(m.timestamp||0).toISOString()}] #${m.__index}: ${String(m.body||'').replace(/\r?\n/g,' ')}`).filter(x=>/:\s+\S/.test(x));
  const batches=batchTextMessages(lines);
  const toneDist=relationshipToneDistribution(selectedMessages); const indirect=relationshipIndirectEvidence(selectedMessages); const quoteCtx=buildQuoteContext(lines.join('\n'));
  const common=`RELATIONSHIP MODE ONLY.\nRELATIONSHIP STATUS: ${RELATIONSHIP_STATUSES.find(x=>x.id===relationshipStatus)?.label||'Talking / exploring'}\nUSER OBJECTIVE: ${String(objective).slice(0,3000)}\n\nRELATIONSHIP TONES:\n${RELATIONSHIP_TONE_GUIDANCE}\n\nRELATIONSHIP PSYCHOLOGY PRINCIPLES:\n${RELATIONSHIP_PRINCIPLE_TEXT}\n\nRULES:\n- Analyze observable communication, not private mental states. Do not diagnose.\n- A relationship inference may use direct or indirect evidence. Indirect evidence must identify an observable cue and an exact quote.\n- Flirting, insecurity, complimenting, affection, jealousy, withdrawal and vulnerability are possibilities to test, not facts to assume.\n- Repeated mutually consistent signals can raise confidence; contradictory signals lower it.\n- Compare the person against their own conversation pattern where possible.\n- If two conversations are selected, compare patterns but never assume the two people know about each other.\n- Do not let one dramatic message dominate the conclusion.\n- Every section must contain evidence. If direct evidence is weak, use verified indirect evidence and explicitly label it indirect.\n- Never invent a quote.`;
  const chunks=[];
  for(let i=0;i<batches.length;i++){
    if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
    if(Date.now()-started>=OLLAMA_SELECTION_TIMEOUT_MS) throw new Error(`Relationship Analysis reached the ${Math.round(OLLAMA_SELECTION_TIMEOUT_MS/60000)}-minute safety ceiling. The server is still running; try fewer messages or one conversation.`);
    const batch=batches[i];
    const prompt=`You are relationship-analysis batch ${i+1}/${batches.length}. EVERY message line below is part of the user's selected relationship conversation set and must be considered. Do not cherry-pick. Identify patterns relevant to the objective. Return compact JSON only.\n\n${common}\n\nBATCH:\n${batch}\n\nJSON schema:\n{"messages_considered":${batch.split(/\n/).length},"relationship_tones":{},"relationship":{"objective_alignment":{"conclusion":"","percent":0,"evidence":[{"quote":"","evidence_type":"direct|indirect","cue":"","justification":"","principle":""}],"counter_evidence":[]},"relationship_dynamic":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"attraction_interest":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"insecurity_vulnerability":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"flirting_affection":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"reciprocity_effort":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"barriers_risks":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"strategy":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]}},"summary":""}`;
    let raw='';try{raw=await callOllama(prompt,{json:true,temperature:.08,timeoutMs:OLLAMA_BATCH_TIMEOUT_MS,signal,numPredict:1200,numCtx:OLLAMA_BATCH_NUM_CTX});}catch(err){if(signal?.aborted)throw new Error('CANCELLED_BY_USER');const msg=String(err?.message||err);if(!/timeout|OLLAMA request failed \(5|Could not reach Ollama/i.test(msg))throw err;try{raw=await callOllama(`RETRY CONCISELY. Return valid JSON for all eight relationship sections.\n${prompt}`,{json:true,temperature:.03,timeoutMs:OLLAMA_BATCH_RETRY_TIMEOUT_MS,signal,numPredict:750,numCtx:OLLAMA_BATCH_NUM_CTX});}catch(_){raw='';}}
    chunks.push(cleanJson(raw)||{messages_considered:batch.split(/\n/).length,relationship:{},relationship_tones:{},summary:'Batch AI pass unavailable; deterministic relationship evidence will still be used.'});
  }
  const compact=chunks.map((x,i)=>({batch:i+1,messages_considered:Number(x.messages_considered)||0,summary:String(x.summary||'').slice(0,500),relationship:Object.fromEntries(Object.entries(x.relationship||{}).map(([k,v])=>[k,{conclusion:String(v?.conclusion||'').slice(0,400),percent:v?.percent,evidence:(v?.evidence||[]).slice(0,2),counter_evidence:(v?.counter_evidence||[]).slice(0,1)}]))}));
  const evidencePool=chunks.flatMap(x=>Object.values(x.relationship||{}).flatMap(s=>Array.isArray(s?.evidence)?s.evidence:[])).filter(e=>e?.quote).slice(0,100);
  const finalPrompt=`You are the FINAL RELATIONSHIP MODE synthesis stage. Produce a distinct, evidence-backed relationship analysis for the user's objective. Every one of the ${selectedMessages.length} selected messages was assigned to an AI batch; do not claim otherwise. Do not invent evidence. Before finalizing, silently confirm every quote you output is exact and every percent is earned by its evidence; fix or drop anything that fails this check rather than let it reach the JSON.\n\n${common}\n\nTOTAL MESSAGES: ${selectedMessages.length}\nBATCHES COMPLETED: ${chunks.length}/${batches.length}\nBATCH SUMMARIES:\n${JSON.stringify(compact)}\n\nDETERMINISTIC RELATIONSHIP TONE DISTRIBUTION:\n${JSON.stringify(toneDist)}\n\nVERIFIED INDIRECT CUES:\n${JSON.stringify(indirect.slice(0,45))}\n\nEVIDENCE POOL:\n${JSON.stringify(evidencePool.slice(0,60))}\n\nReturn ONLY JSON:\n{"overall_conclusion":"","objective_assessment":"","objective_percent":0,"relationship_tones":{},"psychology":[{"principle":"","interpretation":"","observable_clue":"","quote":"","evidence_type":"direct|indirect","cue":"","percent":0}],"sections":{"objective_alignment":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"relationship_dynamic":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"attraction_interest":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"insecurity_vulnerability":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"flirting_affection":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"reciprocity_effort":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"barriers_risks":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"strategy":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]}},"alternative_explanations":[{"explanation":"","quote":"","principle":"Attribution & alternative explanations","percent":0}],"analysis_scope":{"selected_conversations":${ids.length},"messages_selected":${allMessages.length},"messages_considered":${allMessages.length},"coverage_percent":100,"batches_completed":${chunks.length}}}`;
  let finalRaw='';try{finalRaw=await callOllama(finalPrompt,{json:true,temperature:.08,timeoutMs:OLLAMA_BATCH_RETRY_TIMEOUT_MS,signal,numPredict:1800,numCtx:OLLAMA_BATCH_NUM_CTX});}catch(_){finalRaw='';}
  const finalData=cleanJson(finalRaw)||{};
  const merged=relationshipMergeSections(chunks,selectedMessages,evidencePool,indirect);
  const finalSections=finalData.sections&&typeof finalData.sections==='object'?finalData.sections:{};
  const sections={};for(const id of Object.keys(merged)){const src=finalSections[id]||{};const ev=relationshipEvidenceNormalize(src.evidence,quoteCtx,merged[id].evidence);sections[id]={conclusion:String(src.conclusion||merged[id].conclusion||'').slice(0,1800),percent:Math.min(95,Math.max(20,Number(src.percent)||merged[id].percent),),evidence:ev.length?ev:merged[id].evidence,counter_evidence:relationshipEvidenceNormalize(src.counter_evidence,quoteCtx,merged[id].counter_evidence)};}
  const tones=finalData.relationship_tones&&typeof finalData.relationship_tones==='object'&&Object.keys(finalData.relationship_tones).length?finalData.relationship_tones:toneDist;
  return {mode:'relationship',relationship_status:relationshipStatus,relationship_status_label:RELATIONSHIP_STATUSES.find(x=>x.id===relationshipStatus)?.label||'Talking / exploring',objective:String(objective).trim(),conversations:conversations.map(c=>({chat_id:c.chat_id,name:c.name,message_count:c.messages.length})),overall_conclusion:String(finalData.overall_conclusion||sections.relationship_dynamic.conclusion).slice(0,2000),objective_assessment:String(finalData.objective_assessment||sections.objective_alignment.conclusion).slice(0,1800),objective_percent:Math.min(95,Math.max(20,Number(finalData.objective_percent)||sections.objective_alignment.percent)),relationship_tones:tones,psychology:Array.isArray(finalData.psychology)?finalData.psychology.slice(0,20).map(x=>normalizeEvidenceItem(x,['interpretation','observable_clue','cue'],quoteCtx,{principle:'Relationship psychology'})):[],alternative_explanations:Array.isArray(finalData.alternative_explanations)?finalData.alternative_explanations.slice(0,5).map(x=>normalizeEvidenceItem(x,['explanation'],quoteCtx,{principle:'Attribution & alternative explanations'})):[],sections,analysis_scope:{selected_conversations:ids.length,messages_selected:selectedMessages.length,messages_considered:selectedMessages.length,coverage_percent:100,batches_completed:chunks.length,batches_total:batches.length},tone_taxonomy:RELATIONSHIP_TONES.map(([id,label])=>({id,label}))};
}


const { getAryAIWorkspaceFacts, searchAryAIMessages } = require('./db');

// Ary AI — general conversation-aware assistant. It can answer ordinary questions
// like a chat assistant, but it is grounded in the locally stored WhatsApp data
// instead of pretending it knows anything outside the data supplied in the prompt.
function buildAryGenericLocalFallback(question){
  const q=String(question||'').trim();
  const lower=q.toLowerCase();
  if(/start.*conversation|conversation.*relative|talk.*relative|haven't spoken|havent spoken|years/i.test(lower)){
    return `A simple, low-pressure approach usually works best. You could say: “Hey! It’s been a really long time — how have you been?” Then ask about something specific in their life, such as work, family, or what they’ve been up to. Keep the first message warm and easy to answer; you don't need to explain the gap in detail.`;
  }
  if(/how\s+(do|can|should)|what\s+should|advice|help|suggest/i.test(lower)){
    return `A good general approach is to keep it simple, be clear about what you want, and give the other person an easy way to respond. Start with the most important point, avoid over-explaining, and adjust your tone to the situation. If you share more details, I can make the advice more specific.`;
  }
  if(/write|draft|reply|respond|message|text|email/i.test(lower)){
    return `Keep the response clear, natural, and easy to answer. Lead with the main point, use a tone that fits the relationship, and avoid unnecessary explanation. If you provide the situation or draft, I can turn it into a more specific message.`;
  }
  if(/why\b|explain|meaning|difference/i.test(lower)){
    return `The best way to approach that is to separate what is directly known from what is being inferred, then consider the most plausible explanations. I can give you a more precise explanation if you provide the relevant details.`;
  }
  return `Yes — I can still give you a useful general answer without additional context. Start with the main goal, use the simplest practical approach, and avoid making assumptions that aren't supported by the information available. If you add details later, I can refine the answer.`;
}

async function askAryAI(question, { chatId=null, scope='workspace', history=[], signal=null, userContext='' } = {}) {
  const q=String(question||'').trim();
  if(!q) throw new Error('Ask Ary AI a question first.');
  if(signal?.aborted) throw new Error('CANCELLED_BY_USER');

  const lower=q.toLowerCase();
  const explicitWhatsAppIntent=/\b(whatsapp|my\s+(?:whatsapp|contacts?|chats?|conversations?|messages?|texts?)|this\s+(?:chat|conversation)|active\s+(?:chat|conversation)|in\s+(?:my|our)\s+(?:chat|conversation)|my\s+workspace|stored\s+messages?|contact\s+count|conversation\s+count|message\s+count|how\s+many\s+(?:contacts?|conversations?|chats?|messages?)|number\s+of\s+(?:contacts?|conversations?|chats?|messages?)|what\s+did\s+.*\s+say|messages?\s+with\s+)/i.test(lower);
  const dataIntent=scope==='conversation' || (scope!=='none' && explicitWhatsAppIntent);
  const psychologyIntent=/\b(psycholog|principle|bias|attachment|reciprocity|communication pattern|tone|attitude|sarcasm|humou?r|intent|meaning|evidence)\b/i.test(lower);
  const aryTimeoutMs=dataIntent ? OLLAMA_ARY_WHATSAPP_TIMEOUT_MS : OLLAMA_ARY_GENERIC_TIMEOUT_MS;
  const context=String(userContext||'').trim().slice(0, dataIntent ? 6000 : 3500);

  // Do no workspace/database work at all for generic questions. This is the
  // critical fast path: question + optional user context + tiny conversation
  // memory -> lightweight model. A word like "conversation" is not enough to
  // trigger WhatsApp retrieval.
  const chats=dataIntent ? listChats() : [];
  const visibleChats=dataIntent ? chats.filter(c=>!isChatHiddenSafe(c.id)) : [];
  const authoritativeFacts=dataIntent ? getAryAIWorkspaceFacts() : null;
  const active=dataIntent && chatId ? getChat(chatId) : null;
  const activeInventory=active ? visibleChats.find(c=>c.id===active.id) : null;
  const requestedChat=dataIntent ? visibleChats.find(c=>{
    const names=[c.display_name,c.name,c.whatsapp_name,c.whatsapp_pushname,c.id].filter(Boolean).map(String).map(x=>x.toLowerCase());
    return names.some(n=>n.length>=3 && lower.includes(n));
  }) : null;
  const targetChat=active || requestedChat || null;

  let dataBlock='';
  if(dataIntent){
    const facts={
      conversation_count:authoritativeFacts.conversation_count,
      contact_count:authoritativeFacts.contact_count,
      group_count:authoritativeFacts.group_count,
      total_stored_messages:authoritativeFacts.total_stored_messages,
      messages_from_me:authoritativeFacts.messages_from_me,
      messages_from_them:authoritativeFacts.messages_from_them,
      active_conversation:activeInventory?.display_name||active?.display_name||null,
      active_message_count:Number(activeInventory?.message_count||0),
      conversations:authoritativeFacts.conversations.slice(0,100).map(c=>({name:c.name,message_count:c.message_count,my_message_count:c.my_message_count,is_group:c.is_group}))
    };
    dataBlock+=`\nLOCAL WHATSAPP FACTS (computed directly; use these numbers exactly):\n${JSON.stringify(facts)}\n`;
    if(targetChat && (psychologyIntent || /\b(this chat|active chat|this conversation|active conversation|message|text|evidence|said|tone|attitude)\b/i.test(lower))){
      const msgs=getMessages(targetChat.id,40).slice(-24);
      const compact=msgs.map(m=>`${m.from_me?'ME':'THEM'} [${new Date(m.timestamp||0).toISOString()}]: ${String(m.body||'').slice(0,700)}`).join('\n');
      dataBlock+=`\nACTIVE CONVERSATION EVIDENCE:\n${compact}\n`;
    }
    if(!targetChat && psychologyIntent){
      const retrieved=searchAryAIMessages(q,12).map(m=>({chat:m.chat_name,from_me:!!m.from_me,timestamp:m.timestamp,body:String(m.body||'').slice(0,700)}));
      dataBlock+=`\nTARGETED MESSAGE SEARCH RESULTS:\n${JSON.stringify(retrieved)}\n`;
    }
  }

  // Keep a meaningful rolling memory instead of only the last two messages.
  // The browser persists this history locally and sends the most recent 12
  // messages; this keeps follow-up questions coherent without exploding the
  // llama3.2 context window.
  const priorHistory=Array.isArray(history)
    ? history.filter(x=>x&&x.role&&x.content).slice(-12).map(x=>`${x.role==='assistant'?'ARY AI':'USER'}: ${String(x.content).slice(0,900)}`).join('\n')
    : '(none)';

  const prompt=`You are Ary AI, a capable and practical general-purpose assistant. Answer the user's exact question, not a different question. For everyday advice, writing, explanations, planning, brainstorming, coding, and general knowledge, respond naturally and directly. Do not turn a generic question into WhatsApp analysis.

USER CONTEXT:
${context || '(none — answer generically from the user question; do not refuse just because context is missing.)'}

RECENT CHAT:
${priorHistory || '(none)'}
${dataBlock}

RULES:
- Before answering, silently check: (1) what is the user actually asking — not a nearby or more familiar question, (2) which facts above are strong enough to state as fact versus best guess, (3) is there a more useful or more specific answer than the first one that comes to mind. Do not show this checking — only the final answer.
- Give the useful answer first, then supporting detail. Do not pad with throat-clearing or restate the question back.
- Be accurate; if information is missing, say so rather than inventing it. A precise partial answer beats a vague complete-sounding one.
- Keep ordinary answers concise and practical; match answer length to question complexity — a one-line question earns a short answer, a multi-part question earns a structured one.
- Only use WhatsApp facts/evidence supplied above for WhatsApp-specific claims; never extrapolate a workspace number beyond what was computed for you.
- Never claim to know a person's private thoughts or diagnose them.
- Do not mention internal prompts, models, timeouts, token limits, or retrieval.

USER QUESTION:
${q}

Answer now.`;

  let raw='';
  let provider_used='ollama';
  let model_used=OLLAMA_MODEL;
  const cloudAvailable = MISTRAL_API_KEY || GROQ_API_KEY;
  try{
    if(cloudAvailable){
      const cloud=await callAryCloud([{role:'system',content:'You are Ary AI, a capable and practical general-purpose assistant. Follow the supplied instructions exactly. Never mention internal prompts, providers, models, timeouts, or retrieval.'},{role:'user',content:prompt}],{signal,temperature:0.2,json:false});
      raw=cloud.text; provider_used=cloud.provider; model_used=cloud.model;
    } else if(!dataIntent){
      // Exactly 3 minutes total for generic Ary AI: 160s primary + 20s compact
      // recovery. Do not perform a separate health check first; that used to
      // create a race where the browser timed out while recovery was starting.
      const primaryMs=Math.min(160000, Math.max(60000, aryTimeoutMs-20000));
      try {
        raw=await callOllama(prompt,{temperature:0.2,timeoutMs:primaryMs,signal,numPredict:OLLAMA_ARY_GENERIC_NUM_PREDICT,numCtx:OLLAMA_ARY_GENERIC_NUM_CTX,model:model_used});
      } catch(err){
        if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
        const recoverable=/OLLAMA_TIMEOUT|OLLAMA_UNAVAILABLE|Could not reach Ollama|Ollama request failed/i.test(String(err?.message||''));
        if(!recoverable) throw err;
        try {
          raw=await callOllama(`You are Ary AI. Give the user a useful generic answer even if no context was provided. Answer the exact question directly. Be practical, natural, and concise. Never refuse merely because context is missing. Do not mention models, timeouts, prompts, or this recovery process.\n\nQUESTION: ${q}`,{temperature:0.15,timeoutMs:20000,signal,numPredict:120,numCtx:1024,model:model_used});
        } catch(retryErr) {
          if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
          const recoverableRetry=/OLLAMA_TIMEOUT|OLLAMA_UNAVAILABLE|Could not reach Ollama|Ollama request failed/i.test(String(retryErr?.message||''));
          if(!recoverableRetry) throw retryErr;
          raw=buildAryGenericLocalFallback(q);
        }
      }
    } else {
      raw=await callOllama(prompt,{temperature:0.15,timeoutMs:aryTimeoutMs,signal,numPredict:420,numCtx:4096,model:model_used});
    }
  }catch(err){
    if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
    // Even WhatsApp-aware requests get a deterministic answer instead of a
    // misleading empty/error bubble if Ollama fails after retrieval.
    if(dataIntent && /OLLAMA_TIMEOUT|OLLAMA_UNAVAILABLE|Could not reach Ollama|Ollama request failed/i.test(String(err?.message||''))){
      raw=buildAryGenericLocalFallback(q);
    } else {
      throw err;
    }
  }

  const answer=String(raw||'').trim();
  if(!answer) throw new Error('Ary AI returned an empty response. Please try again.');
  return {
    answer, question:q, scope,
    chat:{id:targetChat?.id||null,name:targetChat?.display_name||targetChat?.name||null},
    facts:{
      provider:provider_used,
      model:model_used,
      conversation_count:authoritativeFacts?.conversation_count||0,
      total_stored_messages:authoritativeFacts?.total_stored_messages||0,
      active_message_count:Number(activeInventory?.message_count||0),
      group_count:authoritativeFacts?.group_count||0,
      retrieved_evidence_count:dataIntent ? (targetChat ? Math.min(24,Number(activeInventory?.message_count||0)) : 0) : 0,
      response_sla_ms:aryTimeoutMs, whatsapp_mode:dataIntent, model_used:model_used
    }
  };
}


function buildCorporateFallback(input, {recipient='Unknown', objective='Sound more professional'}={}) {
  const words=input.split(/\s+/).filter(Boolean);
  const hasHedge=/\b(i think|i feel|perhaps|maybe|a little|hopefully|just|somewhat)\b/i.test(input);
  const hasDirectRequest=/\b(could you|can you|please|would you|let me know|i'd like|i would like)\b/i.test(input);
  const hasConcern=/\b(concerned|concern|worried|problem|issue|delay|delays|outstanding|behind|risk)\b/i.test(input);
  const hasBlame=/\b(you failed|you didn't|your fault|you never|you always|unacceptable|incompetent)\b/i.test(input);
  const hasCollaboration=/\b(happy to|help|discuss|work together|we can|we need|agree|support)\b/i.test(input);
  const hasTimeline=/\b(by friday|deadline|timeline|when|completed|completion|schedule|plan)\b/i.test(input);
  const sentences=input.match(/[^.!?]+[.!?]?/g)||[input];
  const quote=(sentences.find(x=>/concern|concerned|worried|delay|delays|outstanding|problem|issue/i.test(x))||sentences[0]).trim().slice(0,220);
  const professionalism=hasBlame?58:hasHedge?84:90;
  const clarity=hasTimeline&&hasDirectRequest?92:(hasDirectRequest?87:78);
  const assertiveness=hasDirectRequest?82:(hasHedge?62:72);
  const diplomacy=hasBlame?48:(hasCollaboration?88:78);
  const collaboration=hasCollaboration?91:(hasBlame?45:68);
  const corporateRisk=hasBlame?55:(hasConcern&&hasDirectRequest?25:18);
  const rewrite=input
    .replace(/I'm a little concerned/ig,'I wanted to raise a concern')
    .replace(/I haven't received/ig,'I have not yet received')
    .replace(/I think we need to/ig,'I recommend that we')
    .replace(/Could you please let me know/ig,'Could you please confirm')
    .replace(/I'd like us to agree/ig,'I would like us to agree');
  const safeRewrite=rewrite===input ? input : rewrite;
  const evidence=[{quote,finding:hasConcern?'The wording explicitly raises a concern or problem.':'The opening establishes the subject directly.',why:hasConcern?'This makes the message appropriately serious, but the concern should stay focused on the work rather than the person.':'A direct opening helps the recipient understand the purpose quickly.',confidence:88}];
  if(hasDirectRequest) evidence.push({quote:(sentences.find(x=>/could you|can you|please|let me know|i'd like/i.test(x))||sentences[0]).trim(),finding:'A clear request or desired outcome is stated.',why:'Specific requests make workplace communication easier to act on.',confidence:92});
  if(hasCollaboration) evidence.push({quote:(sentences.find(x=>/happy to|help|discuss|agree|support/i.test(x))||sentences[0]).trim(),finding:'The message includes a cooperative signal.',why:'Offering discussion or help reduces the chance that a concern is read as purely adversarial.',confidence:90});
  const risks=hasBlame?[{level:'high',issue:'Potentially blame-oriented wording may trigger defensiveness.',quote,reason:'Focus on the situation and next action rather than the recipient.'}]:[{level:hasConcern?'low':'low',issue:hasConcern?'The concern could feel more serious than intended.':'No major corporate communication risk is apparent from the text alone.',quote,reason:hasConcern?'Keep the wording specific and solution-oriented.':'The message can be refined further for the stated objective, but the wording is not inherently problematic.'}];
  const patterns=[];
  if(hasHedge) patterns.push({pattern:'Hedging / softening',quote:(sentences.find(x=>/i think|i feel|perhaps|maybe|a little|just/i.test(x))||sentences[0]).trim(),explanation:'Softening can protect diplomacy, but too much can weaken the request.'});
  if(hasDirectRequest) patterns.push({pattern:'Direct request',quote:(sentences.find(x=>/could you|can you|please|let me know|i'd like/i.test(x))||sentences[0]).trim(),explanation:'The recipient is given a concrete action or decision to respond to.'});
  return {scores:{professionalism,clarity,assertiveness,diplomacy,collaboration,corporate_risk:corporateRisk},overall:`The message is generally workplace-appropriate and ${hasConcern?'appropriately concerned':'clear in purpose'}. The strongest improvement is to keep the request specific while avoiding wording that could sound personal or accusatory.`,recipient_perception:`A reasonable ${recipient.toLowerCase()} may read this as a ${hasConcern?'serious but solution-oriented':'straightforward and work-focused'} request. The stated objective is best supported by concise, specific next steps.`,evidence:evidence.slice(0,4),language_patterns:patterns.slice(0,4),risks:risks.slice(0,3),principles:[{name:'Politeness & indirectness',explanation:'Softening and direct requests can be balanced so the message stays diplomatic without becoming vague.',quote:evidence[0].quote},...(hasCollaboration?[{name:'Conflict & de-escalation',explanation:'Cooperative language keeps attention on solving the work problem rather than assigning personal blame.',quote:(sentences.find(x=>/happy to|help|discuss|agree|support/i.test(x))||sentences[0]).trim()}]:[])],recommended_changes:[hasDirectRequest?'Keep the request and make the desired response or deadline explicit.':'State the requested action or decision explicitly.',hasHedge?'Use one or two softeners, but remove unnecessary hedging.':'Keep the tone confident and specific.',hasBlame?'Replace person-focused wording with situation-focused wording.':'Keep the focus on the work, timeline, and next action.'],rewrite:safeRewrite,alternatives:{executive:'Please confirm the current status, remaining blockers, and revised timeline so we can align on next steps.',diplomatic:'I wanted to check in on the current status. Please let me know if there are any blockers or changes to the expected timeline so we can agree on the best way forward.',assertive:'Please provide an updated timeline and identify any outstanding blockers. I would like us to agree on clear next steps and ownership.',concise:'Please confirm the updated timeline, outstanding blockers, and next steps.'},confidence:78,limitations:['This fallback evaluates wording only; it does not infer private intentions or workplace context that is not present in the text.'],word_count:words.length,response_sla_ms:0,model_used:'local-evidence-fallback',analysis_mode:'Local evidence fallback',objective:String(objective),fallback:true};
}

// PROFESSIONAL MODE — one compact, fast analysis of <=150 words. This is
// deliberately independent of WhatsApp retrieval so the mode stays useful
// and predictable even when no chat is selected.
async function analyzeCorporateText(text, {recipient='Unknown', objective='Sound more professional', signal=null}={}) {
  const input=String(text||'').trim();
  const words=input ? input.split(/\s+/).filter(Boolean) : [];
  if(!input) throw new Error('Paste some workplace text first.');
  if(words.length>150) throw new Error(`Professional Mode accepts up to 150 words. You pasted ${words.length}.`);
  if(signal?.aborted) throw new Error('CANCELLED_BY_USER');

  // Keep the AI pass fast, but never let a slow local model turn Professional Mode into an error.
  const timeout=Math.min(48000,Math.max(20000,Number(process.env.OLLAMA_CORPORATE_TIMEOUT_MS)||48000));
  const model=await pickAryGenericModel(signal);
  const prompt=`You are Ary AI Professional Mode. Analyze ONLY the workplace message below. Return compact valid JSON. Do not invent context or quotes. Do not diagnose.
RECIPIENT: ${String(recipient).slice(0,80)}
OBJECTIVE: ${String(objective).slice(0,120)}
TEXT:
${input}

Required JSON:
{"scores":{"professionalism":0,"clarity":0,"assertiveness":0,"diplomacy":0,"collaboration":0,"corporate_risk":0},"overall":"","recipient_perception":"","evidence":[{"quote":"exact quote","finding":"","why":"","confidence":0}],"language_patterns":[{"pattern":"","quote":"exact quote","explanation":""}],"risks":[{"level":"low|medium|high","issue":"","quote":"exact quote","reason":""}],"principles":[{"name":"","explanation":"","quote":"exact quote"}],"recommended_changes":[""],"rewrite":"","alternatives":{"executive":"","diplomatic":"","assertive":"","concise":""},"confidence":0,"limitations":[""]}
RULES: Quotes must be copied character-for-character from TEXT. Scores are communication-quality estimates, not personality measurements. Keep every field concise. Use 2-4 evidence items and only genuinely relevant principles. If no quote supports a claim, omit the claim.`;
  try {
    await ollamaReady(signal);
    const raw=await callOllama(prompt,{json:true,temperature:0.08,timeoutMs:timeout,signal,numPredict:600,numCtx:3072,model});
    const parsed=cleanJson(raw);
    if(parsed && typeof parsed==='object') return {...parsed,word_count:words.length,response_sla_ms:timeout,model_used:model,analysis_mode:'Ollama AI'};
    throw new Error('INVALID_CORPORATE_JSON');
  } catch(err) {
    if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
    const msg=String(err?.message||err);
    if(/OLLAMA_TIMEOUT|OLLAMA_UNAVAILABLE|Could not reach Ollama|Ollama request failed|INVALID_CORPORATE_JSON/i.test(msg)) {
      console.warn('Professional Mode AI unavailable; using local evidence fallback:',msg);
      return buildCorporateFallback(input,{recipient,objective});
    }
    throw err;
  }
}

function isChatHiddenSafe(id){ try { return isChatHidden(id); } catch(_) { return false; } }

module.exports = {
  splitConversationByDay, prioritizeDayBlocks, buildDayContext, batchTextMessages, providerStatus, localDayKey, normalizeTimestamp, analyzeAndDraft, analyzeTextSelection, summarizeConversationDays, simulateCounterfactual, analyzeRelationshipMode, askAryAI, analyzeCorporateText, draftReply, prioritize, classifyChatContext, TONE_PROFILES, TONE_OPTIONS, RELATIONSHIP_STATUSES, RELATIONSHIP_TONES, OLLAMA_MODEL, OLLAMA_TIMEOUT_MS, OLLAMA_ARY_TIMEOUT_MS, OLLAMA_ARY_GENERIC_TIMEOUT_MS, OLLAMA_ARY_WHATSAPP_TIMEOUT_MS, OLLAMA_ARY_GENERIC_MODEL, OLLAMA_SELECTION_TIMEOUT_MS, OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS, OLLAMA_BATCH_TIMEOUT_MS, OLLAMA_BATCH_RETRY_TIMEOUT_MS };
