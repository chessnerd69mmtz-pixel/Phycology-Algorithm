// backup.js — periodically copies the local database so history survives
// even accidental deletion of the live file. Backups stay entirely on your
// machine, in data/backups/. Oldest backups beyond MAX_BACKUPS are pruned.
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_PATH = path.join(DATA_DIR, 'copilot.db');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
const MAX_BACKUPS = 20;
const BACKUP_INTERVAL_MS = 6 * 60 * 60 * 1000; // every 6 hours

function backupNow() {
  if (!fs.existsSync(DB_PATH)) return;
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const dest = path.join(BACKUP_DIR, `copilot-${stamp}.db`);
  try {
    fs.copyFileSync(DB_PATH, dest);
    pruneOldBackups();
  } catch (err) {
    console.error('Backup failed:', err.message);
  }
}

function pruneOldBackups() {
  const files = fs.readdirSync(BACKUP_DIR)
    .filter(f => f.startsWith('copilot-') && f.endsWith('.db'))
    .map(f => ({ f, t: fs.statSync(path.join(BACKUP_DIR, f)).mtimeMs }))
    .sort((a, b) => b.t - a.t);
  for (const old of files.slice(MAX_BACKUPS)) {
    fs.unlinkSync(path.join(BACKUP_DIR, old.f));
  }
}

function startPeriodicBackups() {
  backupNow(); // one immediately on startup
  setInterval(backupNow, BACKUP_INTERVAL_MS);
}

module.exports = { startPeriodicBackups, backupNow };
