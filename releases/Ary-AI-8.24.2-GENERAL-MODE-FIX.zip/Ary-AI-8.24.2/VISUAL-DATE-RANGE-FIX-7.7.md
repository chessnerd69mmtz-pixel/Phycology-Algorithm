# 7.7 — Relationship visual repair + Deep Analysis date-range selection

## Relationship Mode visual repairs
- Removed a raw JavaScript template expression that was accidentally embedded in static HTML and could render as broken text instead of tone chips.
- Added real 20-tone chips in the Relationship Mode guide.
- Added the missing 8-color chart variables and matching legend swatches so relationship/deep-analysis pie charts render consistently.
- Normalized Relationship Mode tone percentages to 100% in the browser before drawing/labeling the pie chart.
- Added selected-conversation highlighting, a checkmark, selection counter, disabled-state styling after 2 conversations, safer overflow/wrapping, stronger mobile layouts, cleaner result cards, and better evidence-card spacing.
- Updated CSS/JS cache-busting versions so browsers do not keep stale 7.6 frontend assets.

## Deep Analysis date-range selection
The Full Conversation page now keeps the existing **Select all** option and adds:
- Start date
- End date
- Select date range

The range is inclusive and is evaluated using the computer's local calendar date for each stored message. Pressing **Select date range** replaces the current checkbox selection with every message whose date falls inside that period. The user can then manually add/remove individual messages before pressing **Analyze selected messages**.

The selector displays the available stored date span and the number of messages selected by the chosen range. Invalid ranges are rejected before analysis.
