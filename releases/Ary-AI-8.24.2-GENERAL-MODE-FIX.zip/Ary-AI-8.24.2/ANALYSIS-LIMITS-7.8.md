# 7.8 Analysis Limits

- Deep Analysis hard cap: 5,000 selected messages.
- Select all: 5,000 most recent stored messages.
- Date range: maximum 5,000 most recent messages inside the inclusive range.
- Relationship Mode: maximum 5,000 most recent messages across the selected conversations.
- Overall Ollama analysis safety ceiling: 15 minutes.
- Per-batch timeout: 45 seconds.
- Per-batch retry timeout: 30 seconds.
- Batch target: 11,000 characters; max 24 batches.
- Model remains llama3.2 by default.
