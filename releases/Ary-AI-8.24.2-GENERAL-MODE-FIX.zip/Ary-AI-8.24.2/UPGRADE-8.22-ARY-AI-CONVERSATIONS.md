# 8.22 — Ary AI: New chat + view past conversations (server-persisted)

## What changed
Ary AI's memory used to be a single rolling list kept in the browser's
localStorage (`ary-ai-memory-v8.20`, capped at 30 messages) — one thread,
lost the moment you cleared browser data, invisible to anything except that
one browser tab.

That's now a real, server-persisted, multi-conversation model:

- **New chat** (`+ New chat` button) starts a fresh thread with no memory
  bleed from whatever you were discussing before.
- **History** button opens a panel listing every past conversation (title,
  last message, last-updated time), newest first. Click one to reopen it
  exactly where you left off; the ✕ deletes it.
- Every question and answer is stored in two new tables, `ary_conversations`
  and `ary_messages` (see `server/db.js`), not in the browser. Reloading the
  page, restarting the server, or opening the app from a different tab all
  show the same conversation list and the same message history.
- A conversation is auto-titled from its first message (e.g. "How many
  conversations do I have?" becomes the title), so the history list is
  actually scannable instead of a wall of "New conversation".
- If a stale or deleted `conversation_id` is ever sent (e.g. a tab was left
  open after a conversation was deleted elsewhere), the server quietly starts
  a new conversation instead of erroring.

## New API surface (server/index.js)
- `GET /api/ary/conversations` — list, newest-updated first.
- `POST /api/ary/conversations` — create one (used internally; the ask
  endpoint also creates one automatically if you don't pass an id).
- `GET /api/ary/conversations/:id/messages` — full thread.
- `PATCH /api/ary/conversations/:id` — rename.
- `DELETE /api/ary/conversations/:id` — delete a thread and its messages.
- `POST /api/ary-ai/ask` now accepts `conversation_id` in the body. The
  server — not the browser — builds the last 12 turns of working memory from
  the database and appends both the question and the answer to that thread
  after the model responds.

## Why server-side instead of a bigger localStorage cap
A single client-side history array can't represent "multiple conversations"
— there's only one array. Moving memory into SQLite is what actually makes
"new conversation" and "view past conversations" meaningful rather than
cosmetic, and it's a small addition on top of the caching work from 8.21
(the conversation list query is cheap and indexed the same way).

## Verified with live smoke tests (no Ollama required for these)
- New conversation created on first message with no `conversation_id`.
- Second message on the same thread receives the first Q+A as history.
- "New chat" produces a distinct thread with empty history — no bleed from
  the previous conversation.
- Sending a `conversation_id` that was since deleted recovers gracefully by
  starting a new thread instead of throwing.
- Listing and reopening a past conversation returns the exact stored
  messages in order.
- An empty question is rejected before any conversation/message row is
  created, avoiding orphan empty threads.

## Left unchanged
- The model (`llama3.2`), all timeouts/SLAs, and the rest of Ary AI's prompt
  logic (workspace facts, WhatsApp-data intent detection, generic-vs-grounded
  routing) are exactly as they were in 8.21.
- Every other mode's API and behavior — Deep Analysis, Text Analysis,
  Relationship Mode, Professional Mode, Contacts, Reports — is untouched by
  this pass.
