# Transport architecture

Old architecture: WhatsApp Web browser automation through Chromium/Puppeteer.

Current architecture: Baileys 7.0.0-rc14 over WebSockets, with npm-published libsignal 6.0.0 forced through an npm override.

This removes the browser frame lifecycle that produced `Attempted to use detached Frame`.
