ARY AI v5.4 — START HERE

This release specifically fixes the previous Windows failure where the supervisor repeatedly launched Node with:
  Error: Cannot find module 'express'

1. Extract this ZIP into a completely new folder.
2. Do NOT copy node_modules, package-lock.json, or old project files into it.
3. Install Node.js 24 LTS or newer and Ollama.
4. Double-click START-COPILOT.cmd.
5. The launcher now verifies EVERY required dependency before the server is allowed to start.
6. If dependencies are missing/incomplete, it automatically removes the broken tree and installs the pinned versions from the npm registry.
7. If installation fails, the server does NOT enter an endless restart loop.
8. Wait for http://localhost:3010.
9. Scan the WhatsApp QR code using WhatsApp > Linked Devices.

CURRENT DEPENDENCIES
- Node.js: 24 LTS minimum (current LTS line verified against nodejs.org)
- Express: 5.2.1
- better-sqlite3: 13.0.3
- CORS: 2.8.6
- Pino: 10.3.1
- QRCode: 1.5.4
- Baileys: 7.0.0-rc14 (current npm latest)
- libsignal: 6.0.0 (npm registry override required by Baileys)

TRANSPORT
This build does NOT use Puppeteer, Chromium, Selenium, or whatsapp-web.js. WhatsApp transport is browser-free Baileys WebSocket.

AI
The main response-analysis path has one Ollama generation call with a hard 240-second (4-minute) model timeout. The browser waits slightly longer than 4 minutes. Analyze-selected-text is a separate action with a 900-second (15-minute) limit instead. Both limits are synced from the server at runtime, a Stop button can cancel either one mid-run, and the on-screen timer shows an estimate from your past runs before you click.
