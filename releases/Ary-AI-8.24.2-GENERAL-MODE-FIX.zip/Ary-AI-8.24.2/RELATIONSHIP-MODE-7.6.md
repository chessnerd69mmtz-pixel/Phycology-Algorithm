# Relationship Mode 7.6

Relationship Mode is intentionally separate from ordinary Deep Analysis.

## Inputs
- Up to 2 conversations.
- Relationship situation: Currently with / Trying to get with / Talking & exploring.
- A user-written objective.

## Coverage
Every stored message in both selected conversations is assigned to a bounded chronological Ollama batch. The final result reports the exact message count and 100% coverage when all stored messages have been assigned a batch pass. No sampling or newest-message-only shortcut is used.

## Relationship psychology
The mode evaluates observable communication through 18 principles including reciprocity, self-disclosure/vulnerability, uncertainty reduction, flirting/courtship signaling, humor/teasing, complimenting/positive regard, attachment-related communication signals without diagnosis, face-saving, emotional signaling, mirroring, responsiveness, repair, boundaries, investment asymmetry, approach-avoidance tension, contextual calibration, temporal escalation, and alternative explanations.

## Relationship tone distribution
20 relationship-specific observable tones are scored: flirtatious, affectionate, interested, insecure/uncertain, complimentary, teasing, playful, vulnerable, warm, attentive, curious, enthusiastic, excited, reassuring, reserved, distant, frustrated, ambivalent, jealous/possessive, supportive.

The UI shows a normalized 100% distribution. These are communication-signal proportions, not claims about private feelings.

## Evidence
Every relationship section has evidence. Evidence may be direct or indirect. Indirect evidence must identify an observable cue such as a tone shift, question/engagement bid, punctuation/intensity, humor marker, affection-coded emoji, short/reduced reply, hesitation, or sequence change. Quotes are verified against the actual selected messages. Weak contextual fallback evidence is explicitly marked as such and carries low confidence.

## Stability
- One AI analysis at a time.
- Bounded per-batch timeout and compact retry.
- User cancellation via AbortController.
- Express uncaught-exception/unhandled-rejection handlers remain active.
- Relationship Mode uses the existing local Ollama/Llama 3.2 setup.
