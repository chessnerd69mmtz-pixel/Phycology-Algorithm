@echo off
call "%~dp0Ary AI Execute.cmd"
