# Contacts Grid + WhatsApp Names — 8.0

- My Contacts no longer uses a wide two-column layout with a large informational side panel.
- Contact cards are side by side: 3 columns on large screens, 2 on medium screens, 1 on small screens.
- The informational panel is now a compact full-width header above the contact grid.
- Existing contact search, sync, rename, remove and View conversation actions are preserved.
- Chat display names now prefer: local custom rename → WhatsApp contact/saved name when supplied by Baileys → WhatsApp profile/push name → existing chat name / ID fallback.
- Incoming direct messages can contribute their WhatsApp pushName as a best-effort fallback.
- contacts.upsert and contacts.update are both persisted so names can improve after initial sync.
- A small “WhatsApp” badge identifies names obtained from WhatsApp rather than a local rename.

Note: WhatsApp does not always expose the phone's local address-book name to linked-device clients. When it is unavailable, the app cannot reliably recover it; profile/push name is used as the next-best fallback.
