# Ary AI Restore 8.19

This build restores the compact Ary AI path used before the recent evidence-calibration changes while retaining all 8.16/8.17 analysis updates.

## Ary AI fix
- Generic Ary AI uses the configured laptop-friendly `llama3.2` model.
- 90-second primary generation budget.
- 25-second compact recovery attempt.
- Browser timeout now includes the recovery window; it no longer gets reduced to 58 seconds by `/api/status`.
- If both AI attempts time out, generic Ary AI uses a small deterministic local fallback rather than showing a timeout error.
- WhatsApp-aware Ary AI remains separate at its existing 295-second budget.

## Root cause fixed
The previous client started with a long timeout but `syncAryAiLimit()` replaced it with `server_timeout + 3 seconds`. Because the launcher reported 55 seconds, the browser was reset to 58 seconds and aborted Ary AI before its recovery attempt could finish.


## Superseded by 8.20
8.20 expands the generic Ary AI window to 3 minutes, adds persistent local conversation memory, a live timer, and a guaranteed generic fallback path when Ollama times out or context is absent.
