# Ary AI — one-click Windows setup

## First run
1. Make sure Node.js 24 LTS or newer and Ollama are installed.
2. Make sure `llama3.2` is available in Ollama. The launcher checks and pulls it automatically if needed.
3. Double-click **RUN-COPILOT.cmd**.
4. A minimized server window starts and the browser opens to `http://localhost:3010` automatically.
5. On the first connection, scan the WhatsApp QR code from WhatsApp > Linked Devices.

## Every later run
Just double-click **RUN-COPILOT.cmd** again. No PowerShell command is required. If Copilot is already running, the launcher simply opens the dashboard instead of starting a second server.

## Stop
Double-click **STOP-COPILOT.cmd**.

## AI model
The launcher explicitly sets `OLLAMA_MODEL=llama3.2`, prioritizing the stronger local model for interpretation accuracy.

## Response generation
The AI response lab still supports:
- exact one-off response instructions
- persistent per-chat AI instructions
- response drafting
- evidence-based psychology/communication analysis
- likely textual attitude and intent
- sarcasm and humour analysis
- evidence, risks, strategy and alternatives
- selected-text analysis
- conversation stats and reports
- feedback/edit learning for the chat
- WhatsApp history/contact sync
- live incoming message persistence
- sending the generated response through WhatsApp

The local AI layer makes one bounded generation call on the main response path; malformed structured output is handled locally without issuing a second model request.


## Response-time guarantee
The main Analyze + draft path uses one Ollama generation request only. Automatic context classification is not run inside that path. Ollama has a hard 240-second (4-minute) timeout, capped output length, and a warmed model. The browser waits slightly longer than 4 minutes so a single bounded request can complete. Analyze-selected-text is a separate action with a 15-minute limit instead, since it's a deliberate deep read rather than something on the send path. Both limits come from the server (/api/status) so the UI can't drift out of sync, a Stop button can cancel either request, and the timer shows an estimate based on your past runs before you click.

## Browser-free transport
WhatsApp uses Baileys WebSocket transport only. Puppeteer, Chromium, and whatsapp-web.js are not dependencies and are not used by the server.
