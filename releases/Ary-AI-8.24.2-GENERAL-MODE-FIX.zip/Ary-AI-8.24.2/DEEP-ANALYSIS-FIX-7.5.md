# Confidential Algorithm 7.5 — Evidence-Complete 8-Part Deep Analysis

This build reworks selected-message Deep Analysis so the eight categories are real analytical outputs rather than browser-created placeholders.

## Every selected message is considered
- Selection text now carries message timestamps when opened from the full conversation viewer.
- Every selected message is packed into exactly one bounded chronological AI batch.
- The API returns selection coverage metadata (`messages_considered`, `selected_messages`, `coverage_percent`).
- No selected message is silently dropped when the selection is repacked into the configured batch ceiling.

## Eight distinct Deep Analysis components
Each bounded batch returns partial findings for all eight jobs, and the final synthesis returns all eight independently:
1. Overall Interpretation
2. Likely Attitude
3. Sarcasm & Humour
4. Psychology / Communication
5. Risks
6. Evidence
7. Strategy
8. Alternatives

If the final Ollama synthesis times out, the UI no longer falls back to the old generic “could not be fully synthesized” result. The server merges the completed batch-level eight-section reports and fills missing evidence from verified selected-message cues.

## Direct and indirect evidence
- Exact-message quotes remain mandatory evidence anchors.
- Evidence can be marked Direct or Indirect.
- Indirect cues include changes in dominant tone, brevity/length, punctuation intensity, question frequency, laughter markers, ellipses/hesitation, abruptness, mirroring/reciprocity and sequence effects.
- Tone-shift evidence can compare the current quote with the preceding selected quote.
- Confidence may rise modestly when multiple verified cues agree, and is reduced by counter-evidence.
- The algorithm is instructed never to turn indirect cues into claims of hidden motives, personality, diagnosis or certainty.

## 20-feeling pie chart
The dashboard now shows all 20 tone categories as percentages normalized to 100%. Every selected message contributes to this deterministic distribution, so a failed final synthesis does not erase the tone profile.

## Stability
- 6,500-character default batch size
- one Deep Analysis request at a time
- Ollama health check before work starts
- bounded batch and compact retry calls
- 45-minute total analysis ceiling
- Express process exception/rejection guards retained
- missing final synthesis no longer discards completed batch evidence
