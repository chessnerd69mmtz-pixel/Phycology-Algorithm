'use strict';
const fs = require('fs');
const path = require('path');
const pkg = require(path.join(__dirname, '..', 'package.json'));
const files = ['server/index.js','server/whatsapp.js','server/llm.js','server/db.js','public/app.js'];
for (const f of files) {
  if (!fs.existsSync(path.join(__dirname, '..', f))) throw new Error(`Missing required file: ${f}`);
}
if (pkg.dependencies['puppeteer'] || pkg.dependencies['whatsapp-web.js']) throw new Error('Browser WhatsApp dependency detected.');
if (pkg.dependencies['@whiskeysockets/baileys'] !== '7.0.0-rc14') throw new Error('Expected Baileys 7.0.0-rc14.');
if (pkg.overrides?.libsignal !== '6.0.0') throw new Error('npm-only libsignal override missing.');
const llm = fs.readFileSync(path.join(__dirname, '..', 'server/llm.js'), 'utf8');
if (!llm.includes('timeoutMs = OLLAMA_TIMEOUT_MS')) throw new Error('4-minute AI timeout default missing from callOllama.');
if (!llm.includes('Number(process.env.OLLAMA_TIMEOUT_MS) || 240000')) throw new Error('4-minute AI timeout configuration missing.');
if (!llm.includes('Number(process.env.OLLAMA_SELECTION_TIMEOUT_MS) || 900000')) throw new Error('15-minute total selection-analysis timeout configuration missing.');
if (!llm.includes('OLLAMA_BATCH_TIMEOUT_MS')) throw new Error('Bounded batch Ollama timeout missing.');
if (!llm.includes('OLLAMA_BATCH_RETRY_TIMEOUT_MS')) throw new Error('Bounded retry timeout missing.');
if (!llm.includes('numPredict:1350')) throw new Error('Bounded 8-section batch generation budget missing.');
if (!llm.includes('OLLAMA_ARY_GENERIC_MODEL')) throw new Error('Fast generic Ary AI model configuration missing.');
if (!llm.includes('pickAryGenericModel')) throw new Error('Fast generic model selection missing.');
if (!llm.includes('OLLAMA_ARY_GENERIC_NUM_PREDICT')) throw new Error('Fast generic Ary AI generation budget missing.');
if (!llm.includes('OLLAMA_BATCH_CHARS')) throw new Error('Batch size guard missing.');
if (!llm.includes('ollamaReady')) throw new Error('Ollama health check missing.');
if (!llm.includes('ensureDeepSections')) throw new Error('Evidence-complete 8-section fallback missing.');
if (!llm.includes('function computeEvidenceConfidence') || !llm.includes('sectionSignalScore')) throw new Error('Evidence-first confidence calibration missing.');
if (!llm.includes('fixed/default confidence values are never accepted as final scores')) throw new Error('Default-confidence prevention guard missing.');
if (!llm.includes('raw.includes(q)')) throw new Error('Strict exact-quote verification missing.');
if (!llm.includes('bestMatchingLine')) throw new Error('Invalid-quote repair path missing.');
if (!llm.includes('OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS') || !llm.includes('120000')) throw new Error('120-second Text Analysis budget missing.');
if (llm.includes("OLLAMA_ARY_GENERIC_MODEL || 'llama3.2:1b'")) throw new Error('Deprecated 1B Ary AI default detected.');
if (!llm.includes('toneDistributionAllMessages')) throw new Error('20-tone normalized distribution missing.');
if (!llm.includes('toneShiftEvidence')) throw new Error('Tone-shift evidence pass missing.');
if (!llm.includes('coverage_percent:selectedMessages.length?Math.round')) throw new Error('Full selected-message coverage metadata missing.');
if (!llm.includes('CANCELLED_BY_USER')) throw new Error('Stop/cancel support missing from callOllama.');
if (!llm.includes('const contextType = chat.context_type || \'general\'')) throw new Error('Response path still has a hidden classification call.');
const index = fs.readFileSync(path.join(__dirname, '..', 'server/index.js'), 'utf8');
if (!index.includes("app.post('/api/cancel/")) throw new Error('Cancel-request endpoint missing.');
if (!index.includes('let deepAnalysisBusy = false')) throw new Error('Deep-analysis concurrency guard missing.');
if (!llm.includes('180000')) throw new Error('3-minute generic Ary AI budget missing.');
if (!llm.includes('primaryMs=Math.min(160000')) throw new Error('Generic Ary AI primary/recovery budget split missing.');
if (!llm.includes('buildAryGenericLocalFallback')) throw new Error('Deterministic generic Ary AI fallback missing.');
if (!llm.includes('none — answer generically')) throw new Error('Missing-context generic-answer rule missing.');
if (!index.includes("build: '8.23-speed-pass'")) throw new Error('8.23 build identifier missing.');
const app = fs.readFileSync(path.join(__dirname, '..', 'public/app.js'), 'utf8');
// Ary AI memory moved from a single client-side localStorage array (8.20) to
// real, server-persisted, multi-conversation threads (8.22): server/db.js
// owns ary_conversations/ary_messages, and the browser only remembers which
// conversation id is currently open.
const db = fs.readFileSync(path.join(__dirname, '..', 'server/db.js'), 'utf8');
if (!db.includes('createAryConversation') || !db.includes('listAryConversations') || !db.includes('getAryMessages') || !db.includes('appendAryMessage') || !db.includes('deleteAryConversation')) throw new Error('Ary AI conversation persistence functions missing from db.js.');
if (!db.includes('CREATE TABLE IF NOT EXISTS ary_conversations') || !db.includes('CREATE TABLE IF NOT EXISTS ary_messages')) throw new Error('Ary AI conversation tables missing from db.js schema.');
if (!index.includes("app.get('/api/ary/conversations'") || !index.includes("app.get('/api/ary/conversations/:id/messages'") || !index.includes("app.delete('/api/ary/conversations/:id'")) throw new Error('Ary AI conversation API endpoints missing from index.js.');
if (!index.includes('req.body?.conversation_id')) throw new Error('Ary AI ask endpoint no longer threads conversation_id.');
if (!app.includes("ARY_AI_ACTIVE_CONVO_KEY='ary-ai-active-conversation-id'")) throw new Error('Client-side active-conversation pointer missing.');
if (!app.includes('function startNewAryChat')) throw new Error('New chat function missing.');
if (!app.includes('function openAryConversation')) throw new Error('Open past conversation function missing.');
if (!app.includes('function loadAryConversationList')) throw new Error('Conversation history list loader missing.');
if (!app.includes('conversation_id:aryAiConversationId')) throw new Error('Ask request no longer sends the active conversation id.');
if (!app.includes('id=\"ary-ai-timer\"')) { const html=fs.readFileSync(path.join(__dirname, '..', 'public/index.html'),'utf8'); if(!html.includes('id="ary-ai-timer"')) throw new Error('Ary AI timer UI missing.'); }
const html = fs.readFileSync(path.join(__dirname, '..', 'public/index.html'), 'utf8');
if (!html.includes('id="ary-ai-new-chat"') || !html.includes('id="ary-ai-history-toggle"') || !html.includes('id="ary-ai-history-panel"')) throw new Error('New chat / history UI missing from index.html.');
console.log('Build verification passed: browser-free transport + bounded, cancellable, concurrency-limited AI analysis path + 8 evidence-complete sections + strict quote verification + evidence-first confidence calibration + 20-tone distribution (15-minute total selection ceiling) + server-persisted Ary AI conversations (new chat + history).');
