'use strict';
const fs = require('fs');
const path = require('path');
const pkg = require(path.join(__dirname, '..', 'package.json'));
if (pkg.dependencies['whatsapp-web.js'] || pkg.dependencies['puppeteer']) {
  console.error('ERROR: Browser-based WhatsApp transport is still present. This build requires Baileys only.');
  process.exit(1);
}
if (pkg.dependencies['@whiskeysockets/baileys'] !== '7.0.0-rc14') {
  console.error('ERROR: Baileys transport dependency is missing.');
  process.exit(1);
}
if (pkg.overrides?.libsignal !== '6.0.0') {
  console.error('ERROR: npm libsignal override is missing.');
  process.exit(1);
}
console.log('WhatsApp transport verified: browser-free Baileys WebSocket + npm-only libsignal.');
