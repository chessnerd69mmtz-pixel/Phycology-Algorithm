@echo off
setlocal EnableExtensions
cd /d "%~dp0.."

REM Never start Node until dependencies are actually installed and verified.
call scripts\DEPENDENCY-BOOTSTRAP.cmd
if errorlevel 1 (
  echo.
  echo Server start aborted because dependency installation/verification failed.
  echo This prevents the endless "Cannot find module express" restart loop.
  pause
  exit /b 1
)

:LOOP
call npm.cmd run check
if errorlevel 1 (
  echo.
  echo Project validation failed. Server will NOT be started.
  pause
  exit /b 2
)

echo [%date% %time%] Starting Ary AI server
node server\index.js
set "EXITCODE=%ERRORLEVEL%"
echo [%date% %time%] Server exited with code %EXITCODE%.
if "%EXITCODE%"=="0" exit /b 0

echo Restarting in 5 seconds. Press Ctrl+C to stop.
timeout /t 5 /nobreak >nul
goto LOOP
