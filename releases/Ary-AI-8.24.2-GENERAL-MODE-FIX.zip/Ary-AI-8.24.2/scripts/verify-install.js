'use strict';
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const root = path.join(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const banned = JSON.stringify(pkg).match(/(?:github:|git\+|git@|ssh:\/\/|https?:\/\/github\.com\/)/i);
if (banned) throw new Error('A Git/GitHub dependency is present in the project manifest. This build must install entirely from npm.');

const required = [
  ['express', '5.2.1'],
  ['cors', '2.8.6'],
  ['qrcode', '1.5.4'],
  ['pino', '10.3.1'],
  ['better-sqlite3', '13.0.3'],
  ['@whiskeysockets/baileys', '7.0.0-rc14'],
  ['libsignal', '6.0.0'],
];

for (const [name, expected] of required) {
  let pkgPath;
  try {
    const entry = require.resolve(name, { paths: [root] });
    let dir = path.dirname(entry);
    while (dir !== root && dir !== path.dirname(dir)) {
      const candidate = path.join(dir, 'package.json');
      if (fs.existsSync(candidate)) { pkgPath = candidate; break; }
      dir = path.dirname(dir);
    }
  } catch (_) {}
  if (!pkgPath) throw new Error(`Missing dependency: ${name}. npm install did not finish successfully.`);
  const installed = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  if (installed.version !== expected) throw new Error(`Wrong ${name} version: expected ${expected}, found ${installed.version}`);
}

const nodeMajor = Number(process.versions.node.split('.')[0]);
if (nodeMajor < 24) throw new Error(`Node.js 24 LTS or newer is required. Found ${process.version}.`);

try {
  const npmVersion = execFileSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['--version'], { encoding: 'utf8' }).trim();
  console.log(`Dependencies verified. Node ${process.version}; npm ${npmVersion}; all direct packages match the pinned current versions.`);
} catch (_) {
  console.log(`Dependencies verified. Node ${process.version}.`);
}
