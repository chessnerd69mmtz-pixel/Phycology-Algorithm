@echo off
setlocal EnableExtensions
cd /d "%~dp0.."

echo.
echo ============================================================
echo Ary AI dependency check
echo ============================================================
echo This build installs everything from the npm registry.
echo Git is NOT required.
echo.

where node.exe >nul 2>&1 || (echo ERROR: Node.js 24 LTS or newer is required.&exit /b 10)
for /f "tokens=1" %%V in ('node -p "process.versions.node"') do set "NODE_VERSION=%%V"
echo Node.js: %NODE_VERSION%
node -e "if (Number(process.versions.node.split('.')[0]) < 24) process.exit(1)"
if errorlevel 1 (echo ERROR: Please install Node.js 24 LTS or newer, then run START-COPILOT.cmd again.&exit /b 11)

where npm.cmd >nul 2>&1 || (echo ERROR: npm.cmd was not found.&exit /b 12)

node scripts\verify-install.js >nul 2>&1
if not errorlevel 1 (
  echo Existing dependency tree is complete and valid.
  node scripts\verify-no-git-deps.js
  if not errorlevel 1 exit /b 0
  echo Existing dependency metadata contains a Git reference. Rebuilding dependency tree...
)

if exist node_modules (
  echo Removing incomplete/stale node_modules...
  rmdir /s /q node_modules
)
if exist package-lock.json (
  echo Removing stale package-lock.json...
  del /q /f package-lock.json >nul 2>&1
)

call npm.cmd cache verify
if errorlevel 1 echo npm cache verification reported a problem; continuing with a fresh registry install.

echo Installing pinned dependencies from the npm registry...
call npm.cmd install --registry=https://registry.npmjs.org/ --no-audit --no-fund --prefer-online --progress=false
if errorlevel 1 (
  echo.
  echo ERROR: npm dependency installation failed.
  echo IMPORTANT: Do NOT install Git as a workaround. This package intentionally has no Git dependency.
  echo The exact npm error above is what must be fixed if installation fails.
  exit /b 20
)

node scripts\verify-install.js
if errorlevel 1 exit /b 21
node scripts\verify-no-git-deps.js
if errorlevel 1 exit /b 22

echo.
echo Dependency bootstrap completed successfully.
exit /b 0
