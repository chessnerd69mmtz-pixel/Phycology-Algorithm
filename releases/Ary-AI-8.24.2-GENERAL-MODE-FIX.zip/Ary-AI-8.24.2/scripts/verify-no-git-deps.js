'use strict';
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const gitRef = /(?:^git\+|^git@|^github:|^ssh:\/\/|^https?:\/\/github\.com\/)/i;
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
for (const section of ['dependencies', 'optionalDependencies', 'devDependencies', 'overrides']) {
  for (const [name, value] of Object.entries(pkg[section] || {})) {
    if (typeof value === 'string' && gitRef.test(value)) throw new Error(`Git/GitHub dependency reference found: ${name} -> ${value}`);
  }
}
for (const name of ['package-lock.json', 'npm-shrinkwrap.json']) {
  const p = path.join(root, name);
  if (!fs.existsSync(p)) continue;
  const lock = JSON.parse(fs.readFileSync(p, 'utf8'));
  for (const [location, meta] of Object.entries(lock.packages || {})) {
    if (meta && typeof meta.resolved === 'string' && gitRef.test(meta.resolved)) throw new Error(`Git/GitHub package resolution found in ${name}: ${location}: ${meta.resolved}`);
  }
}
console.log('Dependency source check passed: project and lock metadata contain no Git/GitHub dependency URLs.');
