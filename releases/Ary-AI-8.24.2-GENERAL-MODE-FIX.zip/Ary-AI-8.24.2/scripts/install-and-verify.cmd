@echo off
setlocal EnableExtensions
cd /d "%~dp0.."
call scripts\DEPENDENCY-BOOTSTRAP.cmd
exit /b %ERRORLEVEL%
