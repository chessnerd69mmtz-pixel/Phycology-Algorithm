@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Ary AI - WhatsApp AI
if not exist data mkdir data
set "PORT=3011"
set "OLLAMA_MODEL=llama3.2"
set "OLLAMA_URL=http://127.0.0.1:11434"
set "OLLAMA_TIMEOUT_MS=240000"
set "OLLAMA_ARY_GENERIC_TIMEOUT_MS=180000"
set "OLLAMA_ARY_GENERIC_MODEL=llama3.2"
set "OLLAMA_ARY_GENERIC_NUM_PREDICT=220"
set "OLLAMA_ARY_GENERIC_NUM_CTX=2048"
set "OLLAMA_ARY_WHATSAPP_TIMEOUT_MS=295000"
set "OLLAMA_SELECTION_TIMEOUT_MS=900000"
set "OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS=120000"
set "OLLAMA_BATCH_TIMEOUT_MS=120000"
set "OLLAMA_BATCH_RETRY_TIMEOUT_MS=75000"
set "OLLAMA_BATCH_CHARS=9000"
set "OLLAMA_MAX_BATCHES=32"
set "MAX_TRANSCRIPT_MESSAGES=28"
set "INITIAL_SYNC_BUDGET_MS=1800000"
set "INITIAL_LOAD_CALLS_PER_TURN=1"
set "PER_CHAT_TIME_BUDGET_MS=300000"
set "PER_CHAT_BATCH_MESSAGES=150"
set "INCREMENTAL_MESSAGES_PER_CHAT=80"

where node.exe >nul 2>&1 || (echo Node.js 24 LTS or newer was not found.&pause&exit /b 1)
node -e "if (Number(process.versions.node.split('.')[0]) < 24) process.exit(1)"
if errorlevel 1 (echo Node.js 24 LTS or newer is required. Current: & node -v & pause & exit /b 1)

if not exist ".env" (
  if /I "%~1"=="NO_KEY_SETUP" (echo Missing .env. Run SET AI API KEYS.cmd first.&pause&exit /b 1)
  call "%~dp0SET AI API KEYS.cmd"
  if errorlevel 1 exit /b 1
)

rem Import the local .env into this Windows process so the Node server inherits it.
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
  if not "%%A"=="" if /I not "%%A:~0,1%%"=="#" set "%%A=%%B"
)

curl.exe -s --max-time 2 http://127.0.0.1:%PORT%/api/status >nul 2>&1
if not errorlevel 1 (
  start "" "http://localhost:%PORT%"
  exit /b 0
)

call scripts\DEPENDENCY-BOOTSTRAP.cmd
if errorlevel 1 (echo Dependency setup failed. & pause & exit /b 1)

call npm.cmd run check
if errorlevel 1 (echo Project validation failed. Check data\copilot.log. & pause & exit /b 1)

set "SERVER_ENV=set PORT=%PORT%&& set OLLAMA_MODEL=%OLLAMA_MODEL%&& set OLLAMA_URL=%OLLAMA_URL%&& set OLLAMA_TIMEOUT_MS=%OLLAMA_TIMEOUT_MS%&& set OLLAMA_ARY_GENERIC_TIMEOUT_MS=%OLLAMA_ARY_GENERIC_TIMEOUT_MS%&& set OLLAMA_ARY_GENERIC_MODEL=%OLLAMA_ARY_GENERIC_MODEL%&& set OLLAMA_ARY_GENERIC_NUM_PREDICT=%OLLAMA_ARY_GENERIC_NUM_PREDICT%&& set OLLAMA_ARY_GENERIC_NUM_CTX=%OLLAMA_ARY_GENERIC_NUM_CTX%&& set OLLAMA_ARY_WHATSAPP_TIMEOUT_MS=%OLLAMA_ARY_WHATSAPP_TIMEOUT_MS%&& set OLLAMA_SELECTION_TIMEOUT_MS=%OLLAMA_SELECTION_TIMEOUT_MS%&& set OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS=%OLLAMA_TEXT_ANALYSIS_TIMEOUT_MS%&& set OLLAMA_BATCH_TIMEOUT_MS=%OLLAMA_BATCH_TIMEOUT_MS%&& set OLLAMA_BATCH_RETRY_TIMEOUT_MS=%OLLAMA_BATCH_RETRY_TIMEOUT_MS%&& set OLLAMA_BATCH_CHARS=%OLLAMA_BATCH_CHARS%&& set OLLAMA_MAX_BATCHES=%OLLAMA_MAX_BATCHES%&& set MAX_TRANSCRIPT_MESSAGES=%MAX_TRANSCRIPT_MESSAGES%&& set INITIAL_SYNC_BUDGET_MS=%INITIAL_SYNC_BUDGET_MS%&& set INITIAL_LOAD_CALLS_PER_TURN=%INITIAL_LOAD_CALLS_PER_TURN%&& set PER_CHAT_TIME_BUDGET_MS=%PER_CHAT_TIME_BUDGET_MS%&& set PER_CHAT_BATCH_MESSAGES=%PER_CHAT_BATCH_MESSAGES%&& set INCREMENTAL_MESSAGES_PER_CHAT=%INCREMENTAL_MESSAGES_PER_CHAT%&& set AI_PROVIDER=%AI_PROVIDER%&& set UNLIMITLESS_API_KEY=%UNLIMITLESS_API_KEY%&& set MISTRAL_API_KEY=%MISTRAL_API_KEY%&& set MISTRAL_MODEL=%MISTRAL_MODEL%&& set GROQ_API_KEY=%GROQ_API_KEY%&& set GROQ_MODEL=%GROQ_MODEL%&& set MISTRAL_TIMEOUT_MS=%MISTRAL_TIMEOUT_MS%&& set GROQ_TIMEOUT_MS=%GROQ_TIMEOUT_MS%&&"
start "Ary AI Server" /min cmd /c "%SERVER_ENV%call scripts\SERVER-SUPERVISOR.cmd"

for /l %%N in (1,1,45) do (
  curl.exe -s --max-time 2 http://127.0.0.1:%PORT%/api/status >nul 2>&1
  if not errorlevel 1 goto OPEN
  timeout /t 1 /nobreak >nul
)
echo Server did not become reachable. Open data\copilot.log for details.
if exist data\copilot.log start "" notepad.exe "%~dp0data\copilot.log"
pause
exit /b 1
:OPEN
start "" "http://localhost:%PORT%"
echo Ary AI is running on http://localhost:%PORT%
exit /b 0
