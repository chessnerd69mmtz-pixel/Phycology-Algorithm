# 8.21 — Speed, memory, UI, and smarter Ary AI / Deep Analysis

Same models (`llama3.2` throughout, unchanged), same features, same API surface — this
pass only makes the existing pipeline faster and the reasoning tighter.

## Speed & memory (server/db.js)
- `listChats()` — the single most expensive query (it aggregates the whole `messages`
  table per chat) and the single most frequently called one (every page load, every
  Ary AI data-grounded question, every dashboard refresh) — is now cached in memory
  and invalidated by a version counter that bumps on every write that could change
  it (new/renamed chat, new contact, new message, hidden chat). Reads between writes
  are now free instead of re-scanning `messages` every time.
- Added `synchronous = NORMAL`, a 32MB page cache, `temp_store = MEMORY`, and a 256MB
  mmap — safe defaults under WAL for a single-writer local app — to cut disk I/O on
  every read and write.
- Added a composite index on `messages(chat_id, from_me, timestamp)` so the
  my-message-count and unread-from-them subqueries in `listChats()` no longer have
  to fall back to scanning every message in a chat to count one side of it.
- Verified with a live smoke test: inserts, cache hits (same reference returned when
  nothing changed), and cache invalidation (rename produces a fresh, correct result)
  all behave as intended.

## Smarter Ary AI (server/llm.js)
- Added an explicit self-check step to the Ary AI prompt: before answering, it now
  silently confirms what's actually being asked, which facts are strong enough to
  state as fact vs. a best guess, and whether a more specific answer exists — without
  showing that reasoning in the reply. Same latency budget, same model.

## Smarter Deep Analysis, Text Analysis, and Relationship Mode (server/llm.js)
- Each of the three analysis pipelines (single-chat Deep Analysis, manual Text
  Analysis, and Relationship Mode) now includes an explicit final self-verification
  instruction: before the JSON is returned, the model is told to re-check every quote
  against the actual source text and every confidence percentage against the evidence
  that's supposed to justify it, and to fix or drop anything that doesn't hold up
  rather than let it reach the output. This is on top of the evidence-verification
  code that already runs after the model responds — it's a second layer, not a
  replacement.
- Added a note distinguishing genuine ambiguity (two evidence-backed interpretations)
  from false confidence, so close calls are reflected as alternatives/counter-evidence
  rather than forced into one answer.

## UI refresh (public/style.css)
- New typography pairing (Sora for headings, Inter for body) instead of a single
  system stack for everything.
- Calmer, shorter shadows and a less generic accent color; consistent transitions on
  buttons, nav tabs, and cards instead of a mix of instant and abrupt state changes.
- Visible keyboard focus states added across every interactive element.
- One deliberate load-in animation for the app shell (respecting
  `prefers-reduced-motion`) instead of no motion at all or per-card fades everywhere.
- Long analysis text is now capped at a readable line length instead of stretching
  edge-to-edge on wide screens.
- All existing layout, classes, and page structure are untouched — this is additive
  CSS appended after the existing rules, so nothing that already worked can break.

## What was deliberately left alone
- The AI models: still `llama3.2` end to end, no silent upgrade to a bigger model.
- All timeouts/SLAs (4 min analyze+draft, 15 min selection analysis, 3 min generic
  Ary AI, 5 min WhatsApp-grounded Ary AI, 1 min Professional Mode) are unchanged.
- The evidence-verification and confidence-calibration code that runs after each
  model call — the self-check additions above sit on top of it, not instead of it.
