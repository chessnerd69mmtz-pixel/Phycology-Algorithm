# Confidential Algorithm 7.9 — Analysis Visuals

Adds three analysis representations while preserving the existing 8-category Deep Analysis, 20-tone taxonomy, evidence validation, relationship mode, date selection and 5,000-message cap.

## 1. Baseline + Change Detection
- Builds a personal baseline from prior incoming messages before the selected period.
- Compares average message length, question frequency, exclamation frequency and tone distribution.
- Shows observable increases, decreases, stable metrics and tone movement.
- Uses cautious language; it does not claim hidden motives or emotions.

## 2. Evidence Explorer
- Every Deep Analysis conclusion remains clickable.
- Dedicated explorer lists conclusion, confidence, supporting evidence and counter-evidence.
- Clicking a conclusion opens its full evidence trail with exact quotes, evidence type, observable cue and psychological/communication principle.

## 3. Conversation Timeline
- Splits the selected messages into chronological visual segments.
- Shows dominant tone, engagement proxy, YOU/THEM message counts and observable relationship-signal categories.
- Flags actual turning points where tone, engagement or message-length patterns change materially.
- Turning-point quotes are exact selected messages.

All visual summaries are derived from the selected messages and deterministic text signals; they supplement rather than replace the AI evidence analysis.
