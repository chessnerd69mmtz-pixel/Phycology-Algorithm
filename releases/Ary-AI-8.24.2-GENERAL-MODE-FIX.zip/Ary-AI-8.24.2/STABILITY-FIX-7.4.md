# Confidential Algorithm 7.4 — Stable Batched Deep Analysis

## Why the previous build showed `OLLAMA_TIMEOUT after 180000ms`
The 7.3 build allowed each individual Ollama batch request to run for 180 seconds. With a large Select All operation, one batch could consume the entire three-minute allowance, and the retry could repeat the expensive request. The browser then displayed the server error as a JavaScript alert.

## What changed
- Deep Analysis batches are smaller by default (9,000 characters).
- Each normal batch has a 120-second budget and a 75-second compact retry.
- Batch generation is capped at 1,000 tokens, with a 550-token retry.
- Final synthesis is capped at 1,600 tokens, with an 850-token retry.
- Ollama is health-checked before Deep Analysis begins.
- A transient Ollama failure in one batch no longer aborts the whole server request.
- If the final synthesis is unavailable, the app creates an explicitly lower-confidence deterministic fallback from completed evidence and tone scoring. It never invents missing evidence.
- Only one Deep Analysis request may run at a time, preventing multiple large local inference jobs from competing for laptop resources.
- Ollama errors are returned as retryable HTTP 503 responses rather than generic 500 errors.
- Express has a last-resort JSON error boundary.
- Existing process-level exception/rejection logging keeps the Node process alive.
- The existing 30-minute total analysis budget remains, so Select All can cover thousands of messages without a single unbounded Ollama call.

## Important
No software can guarantee that Windows, Node.js, hardware, or Ollama will never fail. This build specifically prevents Deep Analysis timeouts and transient Ollama failures from taking down the Express server and prevents repeated oversized inference calls from accumulating.
