@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=Get-NetTCPConnection -LocalPort 3011 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty OwningProcess; if($p){Stop-Process -Id $p -Force}; Get-CimInstance Win32_Process -Filter \"Name='cmd.exe'\" -ErrorAction SilentlyContinue | Where-Object {$_.CommandLine -like '*SERVER-SUPERVISOR.cmd*'} | ForEach-Object {Stop-Process -Id $_.ProcessId -Force}; Write-Host 'Ary AI stopped.'"
pause
