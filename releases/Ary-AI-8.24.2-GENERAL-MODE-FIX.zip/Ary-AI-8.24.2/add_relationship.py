from pathlib import Path
p=Path('/mnt/data/work76/server/llm.js')
s=p.read_text()
s=s.replace('  getMessages, getMyPastMessages, getMyGlobalStyleSamples, getRecentFeedback,\n', '  getMessages, getAllMessages, getMyPastMessages, getMyGlobalStyleSamples, getRecentFeedback,\n')
insert=r'''

// ---------------------------------------------------------------------------
// RELATIONSHIP MODE — deliberately separate from ordinary Deep Analysis.
// It compares up to two chosen conversations against a user-stated objective.
// Every stored message in every chosen conversation receives a bounded batch
// pass. The final stage only sees compact batch findings + verified evidence,
// so the final prompt stays small without silently dropping messages.
// ---------------------------------------------------------------------------
const RELATIONSHIP_STATUSES = [
  {id:'currently_with',label:'Currently with'},
  {id:'trying_to_get_with',label:'Trying to get with'},
  {id:'talking_exploring',label:'Talking / exploring'},
];
const RELATIONSHIP_TONES = [
  ['flirtatious','Flirtatious'],['affectionate','Affectionate'],['interested','Interested'],
  ['insecure_uncertain','Insecure / uncertain'],['complimentary','Complimentary'],['teasing','Teasing'],
  ['playful','Playful'],['vulnerable','Vulnerable'],['warm','Warm'],['attentive','Attentive'],
  ['curious','Curious'],['enthusiastic','Enthusiastic'],['excited','Excited'],['reassuring','Reassuring'],
  ['reserved','Reserved'],['distant','Distant'],['frustrated','Frustrated'],['ambivalent','Ambivalent'],
  ['jealous','Jealous / possessive'],['supportive','Supportive']
];
const RELATIONSHIP_TONE_GUIDANCE = RELATIONSHIP_TONES.map(([id,label])=>`- ${label} (${id})`).join('\n');
const RELATIONSHIP_PRINCIPLES = [
  ['Reciprocity & investment','Compare initiation, follow-up, responsiveness, effort and mutual conversational contribution.'],
  ['Self-disclosure & vulnerability','Look for increasing personal disclosure, admissions, uncertainty, openness and risk-taking in what is actually said.'],
  ['Uncertainty reduction','Track questions, clarification, reassurance-seeking and attempts to establish where the relationship stands.'],
  ['Flirting & courtship signaling','Look for teasing, compliments, playful escalation, personal attention and romantic ambiguity; never treat one cue alone as proof of attraction.'],
  ['Affiliative humor & teasing','Assess whether jokes/teasing are reciprocal, warm, one-sided, defensive, or followed by repair.'],
  ['Positive regard & complimenting','Distinguish generic politeness from specific, personal, repeated or effortful positive regard.'],
  ['Attachment-related signaling','Use only observable communication patterns such as reassurance-seeking, closeness bids, withdrawal and repair; never diagnose attachment style.'],
  ['Face-saving & dignity','Notice softening, indirectness, embarrassment management, boundaries and language that protects social image.'],
  ['Emotional signaling','Use wording, punctuation, emojis, timing, repetition and intensity as signals rather than proof of private feelings.'],
  ['Mirroring & accommodation','Look for changes toward the other person’s vocabulary, message length, humor, emoji use or conversational rhythm.'],
  ['Responsiveness & availability','Compare whether bids for connection are answered, ignored, delayed, expanded or redirected.'],
  ['Relational repair','Look for apologies, clarification, reassurance and attempts to restore warmth after friction or misunderstanding.'],
  ['Boundary signaling','Identify explicit or indirect limits, topic avoidance, reduced engagement and respect for stated boundaries.'],
  ['Investment asymmetry','Compare effort and initiative over time without assuming motive from silence alone.'],
  ['Approach–avoidance tension','Identify sequences where closeness bids are followed by hesitation, retreat or renewed approach.'],
  ['Social proof & contextual calibration','Interpret behavior relative to the same person’s baseline and the surrounding conversational context.'],
  ['Temporal escalation','Look for meaningful changes across days/weeks rather than treating every message as equally representative.'],
  ['Attribution & alternative explanations','Separate what the messages show from why a person may have behaved that way; keep competing explanations alive.']
];
const RELATIONSHIP_PRINCIPLE_TEXT = RELATIONSHIP_PRINCIPLES.map(x=>`- ${x[0]}: ${x[1]}`).join('\n');

function relationshipToneVector(body='') {
  const t=String(body||'').trim().toLowerCase();
  const s=Object.fromEntries(RELATIONSHIP_TONES.map(([id])=>[id,0]));
  if(!t) return s;
  const add=(id,n)=>{s[id]=Math.min(100,s[id]+n)};
  if(/\b(love|miss you|miss u|baby|babe|darling|cutie|sweetheart)\b|❤️|💕|💗|🥰|😘|😍/i.test(body)) {add('affectionate',55);add('warm',22);}
  if(/\b(hot|cute|gorgeous|handsome|beautiful|pretty|stunning|sexy)\b/i.test(body)) {add('complimentary',60);add('flirtatious',24);}
  if(/\b(flirt|date|kiss|kissing|crush|like you|into you|miss me|us\?|together)\b/i.test(body)) add('flirtatious',55);
  if(/😂|🤣|😏|😉|😜|lmao|lol|haha|hehe/i.test(body)) {add('playful',38);add('teasing',24);}
  if(/\b(i'm insecure|im insecure|i feel insecure|worried|scared|afraid|overthinking|do you still|are you mad|you don't like|you hate me|am i)\b/i.test(body)) {add('insecure_uncertain',62);add('vulnerable',25);}
  if(/\b(thank you|thanks|proud of you|here for you|take care|don't worry|it's okay|you got this)\b/i.test(body)) add('supportive',52);
  if(/\?|\b(what|why|how|when|where|who)\b/i.test(body)) add('curious',25);
  if(/\b(can't wait|cant wait|so excited|yay|omg|amazing)\b|🎉|🥳/i.test(body)) {add('excited',55);add('enthusiastic',25);}
  if(/\b(maybe|idk|not sure|we'll see|we will see|i guess)\b/i.test(body)) {add('ambivalent',45);add('reserved',20);}
  if(/\b(leave me|whatever|k|ok\.|fine\.|don't care|busy|later)\b/i.test(body) && t.length<100) add('distant',38);
  if(/\b(why her|why him|who is she|who is he|your ex|are you talking to)\b/i.test(body)) add('jealous',48);
  if(/\b(annoyed|irritated|frustrated|seriously|ugh)\b/i.test(body)) add('frustrated',45);
  if(/\b(attention|you remembered|you noticed|you always|you know me)\b/i.test(body)) add('attentive',38);
  if(/\b(want to|would you|let's|lets|come over|see you|call me|text me)\b/i.test(body)) add('interested',32);
  if(t.length<5) add('reserved',12);
  if(Object.values(s).every(v=>v===0)) add('warm',8);
  return s;
}
function relationshipToneDistribution(messages=[]) {
  const totals=Object.fromEntries(RELATIONSHIP_TONES.map(([id])=>[id,0]));
  for(const m of messages){const v=relationshipToneVector(m.body);for(const [id,n] of Object.entries(v)) totals[id]+=n;}
  let sum=Object.values(totals).reduce((a,b)=>a+b,0); if(!sum){totals.reserved=1;sum=1;}
  const out={}; let running=0; const ids=RELATIONSHIP_TONES.map(x=>x[0]);
  ids.forEach((id,i)=>{const pct=i===ids.length-1?Math.max(0,100-running):Math.round(totals[id]/sum*1000)/10;out[id]=pct;running=Math.round((running+pct)*10)/10;});
  const drift=Math.round((100-Object.values(out).reduce((a,b)=>a+b,0))*10)/10;if(Math.abs(drift)>0){const k=Object.entries(out).sort((a,b)=>b[1]-a[1])[0]?.[0]||'reserved';out[k]=Math.max(0,Math.round((out[k]+drift)*10)/10);}return out;
}
function relationshipIndirectEvidence(messages=[]) {
  const out=[]; const rows=messages.map((m,i)=>({m,i,v:relationshipToneVector(m.body)}));
  for(let i=0;i<rows.length;i++){
    const r=rows[i], body=String(r.m.body||'').trim(); if(!body) continue;
    const top=Object.entries(r.v).sort((a,b)=>b[1]-a[1])[0]; const cues=[];
    if(/[!?]{2,}/.test(body)) cues.push('repeated punctuation / intensity');
    if(/😂|🤣|😏|😉|😜|lol|lmao|haha|hehe/i.test(body)) cues.push('humour/play marker');
    if(/❤️|💕|💗|🥰|😘|😍/i.test(body)) cues.push('affection-coded emoji');
    if(/\?/.test(body)) cues.push('question / engagement bid');
    if(/\.\.\.|…/.test(body)) cues.push('ellipsis / possible hesitation');
    if(body.split(/\s+/).filter(Boolean).length<=4) cues.push('very short reply / reduced elaboration');
    if(i>0){const prev=rows[i-1].m.body||'';const pv=rows[i-1].v;const prevTop=Object.entries(pv).sort((a,b)=>b[1]-a[1])[0];if(prevTop&&top&&prevTop[0]!==top[0]&&Math.max(prevTop[1],top[1])>=35)cues.push(`shift from ${prevTop[0]} to ${top[0]}`);}
    if(cues.length||((top?.[1]||0)>=50)) out.push({quote:body,evidence_type:'indirect',cue:cues.join('; ')||`${top[0]} textual signal`,justification:'Observable change in wording, form, intensity or sequence. This is evidence about communication behavior, not proof of a hidden feeling.',principle:'Emotional signaling / temporal escalation',percent:Math.min(86,Math.max(35,top?.[1]||40)),previous_quote:i>0?String(rows[i-1].m.body||'').trim():''});
  }
  return out.slice(-80);
}
function relationshipEvidenceNormalize(items, quoteCtx, fallback=[]) {
  const src=(Array.isArray(items)&&items.length?items:fallback).filter(Boolean);
  return src.slice(0,8).map(e=>normalizeEvidenceItem({...e,justification:e.justification||e.interpretation||e.point||e.explanation||'Evidence-linked relationship inference.'},['justification','interpretation','point','explanation'],quoteCtx,{principle:'Relationship psychology / attribution & ambiguity'}));
}
function relationshipMergeSections(chunks, selectedMessages, evidencePool, indirectPool) {
  const ids=['objective_alignment','relationship_dynamic','attraction_interest','insecurity_vulnerability','flirting_affection','reciprocity_effort','barriers_risks','strategy'];
  const defaults={
    objective_alignment:'The objective should be evaluated against observable patterns of interest, reciprocity and boundaries.',
    relationship_dynamic:'The conversations show a relationship pattern that should be interpreted from repeated behavior rather than isolated messages.',
    attraction_interest:'Interest is assessed from repeated attention, engagement and context rather than a single flirtatious line.',
    insecurity_vulnerability:'Uncertainty or vulnerability is assessed only from observable reassurance-seeking, hesitation or self-disclosure.',
    flirting_affection:'Flirting and affection are assessed from reciprocal teasing, compliments, warmth and romantic ambiguity.',
    reciprocity_effort:'Relational investment is assessed by initiation, responsiveness, follow-up and conversational effort.',
    barriers_risks:'Potential barriers are framed as observable friction, asymmetry or boundary signals, not diagnoses.',
    strategy:'Suggested next steps are calibrated to the objective, evidence, reciprocity and boundaries.'
  };
  const out={};
  for(const id of ids){const parts=chunks.map(x=>x.relationship?.[id]).filter(Boolean);const ev=parts.flatMap(x=>Array.isArray(x.evidence)?x.evidence:[]).filter(e=>e?.quote);const fb=evidencePool.filter(e=>e?.quote).slice(0,3);const evidence=relationshipEvidenceNormalize(ev,buildQuoteContext(selectedMessages.map(m=>m.raw).join('\n')),fb.length?fb:indirectPool);const pct=Math.min(94,Math.max(20,Math.round((parts.length?parts.reduce((a,x)=>a+(Number(x.percent)||45),0)/parts.length:40)+(evidence.filter(x=>x.example_verified).length*4))));out[id]={conclusion:parts.map(x=>String(x.conclusion||'')).filter(Boolean).join(' ').slice(0,1800)||defaults[id],percent:pct,evidence,counter_evidence:parts.flatMap(x=>Array.isArray(x.counter_evidence)?x.counter_evidence:[]).filter(e=>e?.quote).slice(0,4)};}
  return out;
}

async function analyzeRelationshipMode(chatIds=[], objective='', relationshipStatus='talking_exploring', signal=null) {
  const started=Date.now();
  const ids=[...new Set((Array.isArray(chatIds)?chatIds:[]).map(String).map(x=>x.trim()).filter(Boolean))].slice(0,2);
  if(!ids.length) throw new Error('Choose at least one conversation.');
  if(!String(objective||'').trim()) throw new Error('List the relationship objective you want the analysis to evaluate.');
  if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
  await ollamaReady(signal);
  const conversations=[]; const allMessages=[];
  for(let ci=0;ci<ids.length;ci++){
    const chat=getChat(ids[ci]); if(!chat) throw new Error(`Conversation ${ids[ci]} was not found.`);
    const ms=getAllMessages(ids[ci]);
    conversations.push({chat_id:ids[ci],name:chat.display_name||chat.name||ids[ci],messages:ms});
    ms.forEach((m,index)=>allMessages.push({...m,__conversation_index:ci+1,__conversation_name:chat.display_name||chat.name||ids[ci],__index:index+1}));
  }
  if(!allMessages.length) throw new Error('The chosen conversation(s) contain no stored messages. Sync WhatsApp history first.');
  const lines=allMessages.map(m=>`CONVERSATION ${m.__conversation_index} — ${m.__conversation_name} — ${m.from_me?'ME':'THEM'} [${new Date(m.timestamp||0).toISOString()}] #${m.__index}: ${String(m.body||'').replace(/\r?\n/g,' ')}`).filter(x=>/:\s+\S/.test(x));
  const batches=[];let cur=[],chars=0;for(const line of lines){const cost=line.length+1;if(cur.length&&chars+cost>6500){batches.push(cur.join('\n'));cur=[];chars=0;}cur.push(line);chars+=cost;}if(cur.length)batches.push(cur.join('\n'));
  const toneDist=relationshipToneDistribution(allMessages); const indirect=relationshipIndirectEvidence(allMessages); const quoteCtx=buildQuoteContext(lines.join('\n'));
  const common=`RELATIONSHIP MODE ONLY.\nRELATIONSHIP STATUS: ${RELATIONSHIP_STATUSES.find(x=>x.id===relationshipStatus)?.label||'Talking / exploring'}\nUSER OBJECTIVE: ${String(objective).slice(0,3000)}\n\nRELATIONSHIP TONES:\n${RELATIONSHIP_TONE_GUIDANCE}\n\nRELATIONSHIP PSYCHOLOGY PRINCIPLES:\n${RELATIONSHIP_PRINCIPLE_TEXT}\n\nRULES:\n- Analyze observable communication, not private mental states. Do not diagnose.\n- A relationship inference may use direct or indirect evidence. Indirect evidence must identify an observable cue and an exact quote.\n- Flirting, insecurity, complimenting, affection, jealousy, withdrawal and vulnerability are possibilities to test, not facts to assume.\n- Repeated mutually consistent signals can raise confidence; contradictory signals lower it.\n- Compare the person against their own conversation pattern where possible.\n- If two conversations are selected, compare patterns but never assume the two people know about each other.\n- Do not let one dramatic message dominate the conclusion.\n- Every section must contain evidence. If direct evidence is weak, use verified indirect evidence and explicitly label it indirect.\n- Never invent a quote.`;
  const chunks=[];
  for(let i=0;i<batches.length;i++){
    if(signal?.aborted) throw new Error('CANCELLED_BY_USER');
    if(Date.now()-started>=OLLAMA_SELECTION_TIMEOUT_MS) throw new Error(`Relationship Analysis reached the ${Math.round(OLLAMA_SELECTION_TIMEOUT_MS/60000)}-minute safety ceiling. The server is still running; try fewer messages or one conversation.`);
    const batch=batches[i];
    const prompt=`You are relationship-analysis batch ${i+1}/${batches.length}. EVERY message line below is part of the user's selected relationship conversation set and must be considered. Do not cherry-pick. Identify patterns relevant to the objective. Return compact JSON only.\n\n${common}\n\nBATCH:\n${batch}\n\nJSON schema:\n{"messages_considered":${batch.split(/\n/).length},"relationship_tones":{},"relationship":{"objective_alignment":{"conclusion":"","percent":0,"evidence":[{"quote":"","evidence_type":"direct|indirect","cue":"","justification":"","principle":""}],"counter_evidence":[]},"relationship_dynamic":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"attraction_interest":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"insecurity_vulnerability":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"flirting_affection":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"reciprocity_effort":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"barriers_risks":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"strategy":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]}},"summary":""}`;
    let raw='';try{raw=await callOllama(prompt,{json:true,temperature:.08,timeoutMs:OLLAMA_BATCH_TIMEOUT_MS,signal,numPredict:1200});}catch(err){if(signal?.aborted)throw new Error('CANCELLED_BY_USER');const msg=String(err?.message||err);if(!/timeout|OLLAMA request failed \(5|Could not reach Ollama/i.test(msg))throw err;try{raw=await callOllama(`RETRY CONCISELY. Return valid JSON for all eight relationship sections.\n${prompt}`,{json:true,temperature:.03,timeoutMs:OLLAMA_BATCH_RETRY_TIMEOUT_MS,signal,numPredict:750});}catch(_){raw='';}}
    chunks.push(cleanJson(raw)||{messages_considered:batch.split(/\n/).length,relationship:{},relationship_tones:{},summary:'Batch AI pass unavailable; deterministic relationship evidence will still be used.'});
  }
  const compact=chunks.map((x,i)=>({batch:i+1,messages_considered:Number(x.messages_considered)||0,summary:String(x.summary||'').slice(0,500),relationship:Object.fromEntries(Object.entries(x.relationship||{}).map(([k,v])=>[k,{conclusion:String(v?.conclusion||'').slice(0,400),percent:v?.percent,evidence:(v?.evidence||[]).slice(0,2),counter_evidence:(v?.counter_evidence||[]).slice(0,1)}]))}));
  const evidencePool=chunks.flatMap(x=>Object.values(x.relationship||{}).flatMap(s=>Array.isArray(s?.evidence)?s.evidence:[])).filter(e=>e?.quote).slice(0,100);
  const finalPrompt=`You are the FINAL RELATIONSHIP MODE synthesis stage. Produce a distinct, evidence-backed relationship analysis for the user's objective. Every one of the ${allMessages.length} stored messages was assigned to an AI batch; do not claim otherwise. Do not invent evidence.\n\n${common}\n\nTOTAL MESSAGES: ${allMessages.length}\nBATCHES COMPLETED: ${chunks.length}/${batches.length}\nBATCH SUMMARIES:\n${JSON.stringify(compact)}\n\nDETERMINISTIC RELATIONSHIP TONE DISTRIBUTION:\n${JSON.stringify(toneDist)}\n\nVERIFIED INDIRECT CUES:\n${JSON.stringify(indirect.slice(0,45))}\n\nEVIDENCE POOL:\n${JSON.stringify(evidencePool.slice(0,60))}\n\nReturn ONLY JSON:\n{"overall_conclusion":"","objective_assessment":"","objective_percent":0,"relationship_tones":{},"psychology":[{"principle":"","interpretation":"","observable_clue":"","quote":"","evidence_type":"direct|indirect","cue":"","percent":0}],"sections":{"objective_alignment":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"relationship_dynamic":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"attraction_interest":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"insecurity_vulnerability":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"flirting_affection":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"reciprocity_effort":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"barriers_risks":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]},"strategy":{"conclusion":"","percent":0,"evidence":[],"counter_evidence":[]}},"alternative_explanations":[{"explanation":"","quote":"","principle":"Attribution & alternative explanations","percent":0}],"analysis_scope":{"selected_conversations":${ids.length},"messages_selected":${allMessages.length},"messages_considered":${allMessages.length},"coverage_percent":100,"batches_completed":${chunks.length}}}`;
  let finalRaw='';try{finalRaw=await callOllama(finalPrompt,{json:true,temperature:.08,timeoutMs:OLLAMA_BATCH_RETRY_TIMEOUT_MS,signal,numPredict:1800});}catch(_){finalRaw='';}
  const finalData=cleanJson(finalRaw)||{};
  const merged=relationshipMergeSections(chunks,allMessages,evidencePool,indirect);
  const finalSections=finalData.sections&&typeof finalData.sections==='object'?finalData.sections:{};
  const sections={};for(const id of Object.keys(merged)){const src=finalSections[id]||{};const ev=relationshipEvidenceNormalize(src.evidence,quoteCtx,merged[id].evidence);sections[id]={conclusion:String(src.conclusion||merged[id].conclusion||'').slice(0,1800),percent:Math.min(95,Math.max(20,Number(src.percent)||merged[id].percent),),evidence:ev.length?ev:merged[id].evidence,counter_evidence:relationshipEvidenceNormalize(src.counter_evidence,quoteCtx,merged[id].counter_evidence)};}
  const tones=finalData.relationship_tones&&typeof finalData.relationship_tones==='object'?finalData.relationship_tones:toneDist;
  return {mode:'relationship',relationship_status:relationshipStatus,relationship_status_label:RELATIONSHIP_STATUSES.find(x=>x.id===relationshipStatus)?.label||'Talking / exploring',objective:String(objective).trim(),conversations:conversations.map(c=>({chat_id:c.chat_id,name:c.name,message_count:c.messages.length})),overall_conclusion:String(finalData.overall_conclusion||sections.relationship_dynamic.conclusion).slice(0,2000),objective_assessment:String(finalData.objective_assessment||sections.objective_alignment.conclusion).slice(0,1800),objective_percent:Math.min(95,Math.max(20,Number(finalData.objective_percent)||sections.objective_alignment.percent)),relationship_tones:tones,psychology:Array.isArray(finalData.psychology)?finalData.psychology.slice(0,20).map(x=>normalizeEvidenceItem(x,['interpretation','observable_clue','cue'],quoteCtx,{principle:'Relationship psychology'})):[],alternative_explanations:Array.isArray(finalData.alternative_explanations)?finalData.alternative_explanations.slice(0,5).map(x=>normalizeEvidenceItem(x,['explanation'],quoteCtx,{principle:'Attribution & alternative explanations'})):[],sections,analysis_scope:{selected_conversations:ids.length,messages_selected:allMessages.length,messages_considered:allMessages.length,coverage_percent:100,batches_completed:chunks.length,batches_total:batches.length},tone_taxonomy:RELATIONSHIP_TONES.map(([id,label])=>({id,label}))};
}
'''
s=s.replace('\nmodule.exports = {',insert+'\nmodule.exports = {')
s=s.replace('analyzeTextSelection, draftReply, prioritize, classifyChatContext,', 'analyzeTextSelection, analyzeRelationshipMode, draftReply, prioritize, classifyChatContext,')
s=s.replace('TONE_OPTIONS, OLLAMA_MODEL', 'TONE_OPTIONS, RELATIONSHIP_STATUSES, RELATIONSHIP_TONES, OLLAMA_MODEL')
p.write_text(s)
