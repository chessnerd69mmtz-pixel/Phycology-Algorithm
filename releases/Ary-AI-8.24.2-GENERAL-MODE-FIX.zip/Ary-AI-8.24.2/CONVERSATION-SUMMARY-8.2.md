# Conversation Summary 8.2

## AI Conversation Summary
- Added a dedicated Conversation Summary action to the Full Conversation page.
- Supports **1 or 2 calendar days maximum** per summary.
- Supports up to **5,000 text messages**. If the selected two-day period contains more than 5,000 text messages, the 5,000 most recent text messages in that period are summarized.
- Uses the existing local Ollama/Llama 3.2 pipeline, bounded chronological batches, cancellation, health checking, retry and overall safety timeout.
- Produces an executive summary plus day-by-day summaries, main topics, decisions, plans/commitments, open questions, notable events, communication dynamics, important quotes, uncertainties and possible next steps.
- Exact quotes are validated against the selected messages.
- Summary results are recorded in local analysis history and displayed as a dedicated Summary tab alongside the existing analysis views.
- The existing Deep Analysis, Relationship Mode, 20-tone analysis, Evidence Explorer, Baseline/Change Detection, Conversation Timeline, contact grid, WhatsApp naming, QR and saved-report functionality remain unchanged.
