@echo off
setlocal
cd /d "%~dp0"
call scripts\DEPENDENCY-BOOTSTRAP.cmd
if errorlevel 1 (echo. & echo Dependency installation failed. & pause & exit /b 1)
echo.
echo Dependencies are ready.
pause
